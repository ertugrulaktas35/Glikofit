-- ============================================================
-- 🩸 Akıllı Kan Şekeri Asistanı — Veritabanı Şeması
-- ============================================================
-- Supabase SQL Editor'e yapıştırıp çalıştırın.
-- Tablolar, Foreign Key'ler, RLS ve indeksler dahildir.
-- ============================================================


-- ══════════════════════════════════════════════════════════════
-- 1. USERS TABLOSU
-- ══════════════════════════════════════════════════════════════
-- auth.users ile 1:1 ilişkili. Kayıt olunca otomatik oluşacak.

CREATE TABLE IF NOT EXISTS public.users (
  id          UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email       TEXT NOT NULL,
  goal        TEXT DEFAULT '',                          -- Kullanıcı hedefi (örn: "Şekeri kontrol altında tutmak")
  is_premium  BOOLEAN NOT NULL DEFAULT FALSE,          -- Premium üyelik durumu
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Yeni kullanıcı auth'a kayıt olduğunda otomatik profil oluştur
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
BEGIN
  INSERT INTO public.users (id, email)
  VALUES (NEW.id, NEW.email);
  RETURN NEW;
END;
$$;

-- Trigger: auth.users'a yeni satır eklendiğinde tetiklenir
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();

COMMENT ON TABLE public.users IS 'Kullanıcı profilleri — auth.users ile 1:1 bağlantılı';


-- ══════════════════════════════════════════════════════════════
-- 2. FOODS TABLOSU
-- ══════════════════════════════════════════════════════════════
-- Besinler ve glisemik verileri. Herkes okuyabilir (Public Read).

CREATE TABLE IF NOT EXISTS public.foods (
  id              BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  name            TEXT NOT NULL,                        -- Besin adı (örn: "Beyaz Ekmek")
  category        TEXT NOT NULL DEFAULT 'Genel',        -- Kategori (örn: "Tahıllar", "Meyveler")
  gi_value        INT NOT NULL CHECK (gi_value >= 0 AND gi_value <= 100),  -- Glisemik İndeks (0-100)
  carbs_per_100g  REAL NOT NULL CHECK (carbs_per_100g >= 0),              -- 100g başına karbonhidrat (gram)
  color_code      TEXT NOT NULL CHECK (color_code IN ('GREEN', 'YELLOW', 'RED')),  -- Trafik lambası rengi
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Arama performansı için indeksler
CREATE INDEX IF NOT EXISTS idx_foods_name ON public.foods USING gin (to_tsvector('turkish', name));
CREATE INDEX IF NOT EXISTS idx_foods_category ON public.foods (category);
CREATE INDEX IF NOT EXISTS idx_foods_color_code ON public.foods (color_code);

COMMENT ON TABLE public.foods IS 'Besinler — Glisemik İndeks ve karbonhidrat verileri';


-- ══════════════════════════════════════════════════════════════
-- 3. CONSUMPTION_LOGS TABLOSU
-- ══════════════════════════════════════════════════════════════
-- Kullanıcıların günlük besin tüketim kayıtları.

CREATE TABLE IF NOT EXISTS public.consumption_logs (
  id              BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id         UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  food_id         BIGINT NOT NULL REFERENCES public.foods(id) ON DELETE RESTRICT,
  portion_grams   INT NOT NULL CHECK (portion_grams > 0),               -- Tüketilen porsiyon (gram)
  calculated_gl   REAL NOT NULL CHECK (calculated_gl >= 0),             -- Hesaplanan Glisemik Yük
  consumed_at     TIMESTAMPTZ NOT NULL DEFAULT now()                    -- Tüketim zamanı
);

-- Sorgu performansı için indeksler
CREATE INDEX IF NOT EXISTS idx_consumption_logs_user_id ON public.consumption_logs (user_id);
CREATE INDEX IF NOT EXISTS idx_consumption_logs_consumed_at ON public.consumption_logs (consumed_at DESC);
CREATE INDEX IF NOT EXISTS idx_consumption_logs_user_date ON public.consumption_logs (user_id, consumed_at DESC);

COMMENT ON TABLE public.consumption_logs IS 'Günlük besin tüketim kayıtları — kullanıcı bazlı';


-- ══════════════════════════════════════════════════════════════
-- 4. COACH_PAIRINGS TABLOSU
-- ══════════════════════════════════════════════════════════════
-- Akıllı Dengeleyici Koç eşleştirme verileri (Premium özellik).
-- Kırmızı besin kategorisine göre yeşil besin önerisi.

CREATE TABLE IF NOT EXISTS public.coach_pairings (
  id                  BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  high_risk_category  TEXT NOT NULL,    -- Riskli besin kategorisi (örn: "Şekerli İçecekler")
  balancer_category   TEXT NOT NULL,    -- Dengeleyici besin kategorisi (örn: "Kuruyemişler")
  advice_text         TEXT NOT NULL,    -- Koç tavsiye metni
  created_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_coach_high_risk ON public.coach_pairings (high_risk_category);

COMMENT ON TABLE public.coach_pairings IS 'Akıllı Koç eşleştirmeleri — riskli besine karşı dengeleyici öneri';


-- ══════════════════════════════════════════════════════════════
-- 5. ROW LEVEL SECURITY (RLS) — GÜVENLİK KURALLARI
-- ══════════════════════════════════════════════════════════════

-- ── 5.1  users — Sadece kendi verisini okuyup yazabilir ──────

ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

CREATE POLICY "users_select_own"
  ON public.users
  FOR SELECT
  USING (auth.uid() = id);

CREATE POLICY "users_update_own"
  ON public.users
  FOR UPDATE
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- INSERT trigger ile otomatik yapılıyor, kullanıcının INSERT'e ihtiyacı yok


-- ── 5.2  foods — Herkes okuyabilir (Public Read) ────────────

ALTER TABLE public.foods ENABLE ROW LEVEL SECURITY;

CREATE POLICY "foods_public_read"
  ON public.foods
  FOR SELECT
  USING (true);

-- INSERT/UPDATE/DELETE sadece Supabase Dashboard veya service_role key ile yapılır


-- ── 5.3  consumption_logs — Sadece kendi verisini CRUD ──────

ALTER TABLE public.consumption_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "consumption_logs_select_own"
  ON public.consumption_logs
  FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "consumption_logs_insert_own"
  ON public.consumption_logs
  FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "consumption_logs_update_own"
  ON public.consumption_logs
  FOR UPDATE
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "consumption_logs_delete_own"
  ON public.consumption_logs
  FOR DELETE
  USING (auth.uid() = user_id);


-- ── 5.4  coach_pairings — Herkes okuyabilir (Public Read) ───

ALTER TABLE public.coach_pairings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "coach_pairings_public_read"
  ON public.coach_pairings
  FOR SELECT
  USING (true);


-- ══════════════════════════════════════════════════════════════
-- 6. SEED DATA — ÖRNEK BESİN VERİLERİ
-- ══════════════════════════════════════════════════════════════
-- Uygulamanın çalışması için başlangıç veri seti.

INSERT INTO public.foods (name, category, gi_value, carbs_per_100g, color_code) VALUES
  -- 🟢 YEŞİL — Güvenli Besinler (GI ≤ 55)
  ('Brokoli',             'Sebzeler',       15,  7.0,   'GREEN'),
  ('Ispanak',             'Sebzeler',       15,  3.6,   'GREEN'),
  ('Domates',             'Sebzeler',       15,  3.9,   'GREEN'),
  ('Salatalık',           'Sebzeler',       15,  3.6,   'GREEN'),
  ('Karnabahar',          'Sebzeler',       15,  5.0,   'GREEN'),
  ('Kabak',               'Sebzeler',       15,  3.1,   'GREEN'),
  ('Yeşil Mercimek',      'Baklagiller',    30,  20.1,  'GREEN'),
  ('Kırmızı Mercimek',    'Baklagiller',    26,  17.5,  'GREEN'),
  ('Nohut',               'Baklagiller',    28,  27.4,  'GREEN'),
  ('Kuru Fasulye',        'Baklagiller',    29,  21.4,  'GREEN'),
  ('Elma',                'Meyveler',       36,  13.8,  'GREEN'),
  ('Armut',               'Meyveler',       38,  15.5,  'GREEN'),
  ('Portakal',            'Meyveler',       43,  11.8,  'GREEN'),
  ('Çilek',               'Meyveler',       40,  7.7,   'GREEN'),
  ('Kiraz',               'Meyveler',       22,  16.0,  'GREEN'),
  ('Erik',                'Meyveler',       39,  11.4,  'GREEN'),
  ('Greyfurt',            'Meyveler',       25,  10.7,  'GREEN'),
  ('Ceviz',               'Kuruyemişler',   15,  13.7,  'GREEN'),
  ('Badem',               'Kuruyemişler',   15,  21.6,  'GREEN'),
  ('Fındık',              'Kuruyemişler',   15,  16.7,  'GREEN'),
  ('Yulaf Ezmesi',        'Tahıllar',       55,  66.3,  'GREEN'),
  ('Tam Buğday Ekmek',    'Tahıllar',       54,  43.3,  'GREEN'),
  ('Bulgur',              'Tahıllar',       48,  75.9,  'GREEN'),
  ('Esmer Pirinç',        'Tahıllar',       50,  77.2,  'GREEN'),
  ('Tam Buğday Makarna',  'Tahıllar',       42,  75.0,  'GREEN'),
  ('Yoğurt (Sade)',       'Süt Ürünleri',   36,  4.7,   'GREEN'),
  ('Süt (Tam Yağlı)',     'Süt Ürünleri',   27,  4.8,   'GREEN'),
  ('Peynir (Beyaz)',      'Süt Ürünleri',   10,  1.3,   'GREEN'),
  ('Yumurta',             'Protein',        0,   1.1,   'GREEN'),
  ('Tavuk Göğsü',        'Protein',        0,   0.0,   'GREEN'),
  ('Balık (Somon)',       'Protein',        0,   0.0,   'GREEN'),
  ('Zeytinyağı',          'Yağlar',         0,   0.0,   'GREEN'),

  -- 🟡 SARI — Dikkat Gerektiren Besinler (GI 56-69)
  ('Muz',                 'Meyveler',       62,  22.8,  'YELLOW'),
  ('Üzüm',               'Meyveler',       59,  18.1,  'YELLOW'),
  ('Kayısı',              'Meyveler',       57,  11.1,  'YELLOW'),
  ('Ananas',              'Meyveler',       59,  13.1,  'YELLOW'),
  ('Kivi',                'Meyveler',       58,  14.7,  'YELLOW'),
  ('Mango',               'Meyveler',       56,  15.0,  'YELLOW'),
  ('Bal',                 'Tatlandırıcılar', 61, 82.4,  'YELLOW'),
  ('Beyaz Makarna',       'Tahıllar',       61,  75.0,  'YELLOW'),
  ('Basmati Pirinç',      'Tahıllar',       58,  77.1,  'YELLOW'),
  ('Patates (Haşlama)',   'Sebzeler',       56,  17.5,  'YELLOW'),
  ('Bezelye',             'Sebzeler',       68,  14.5,  'YELLOW'),
  ('Tatlı Patates',       'Sebzeler',       63,  20.1,  'YELLOW'),
  ('Çavdar Ekmek',        'Tahıllar',       65,  48.3,  'YELLOW'),
  ('Müsli',               'Tahıllar',       66,  66.2,  'YELLOW'),

  -- 🔴 KIRMIZI — Riskli Besinler (GI ≥ 70)
  ('Beyaz Ekmek',         'Tahıllar',       75,  49.0,  'RED'),
  ('Beyaz Pirinç',        'Tahıllar',       73,  80.0,  'RED'),
  ('Baget Ekmek',         'Tahıllar',       95,  51.0,  'RED'),
  ('Mısır Gevreği',       'Tahıllar',       81,  84.0,  'RED'),
  ('Pirinç Patlağı',      'Tahıllar',       87,  82.0,  'RED'),
  ('Karpuz',              'Meyveler',       76,  7.6,   'RED'),
  ('Hurma',               'Meyveler',       70,  75.0,  'RED'),
  ('Patates (Kızartma)',  'Fast Food',      75,  35.7,  'RED'),
  ('Patates Cipsi',       'Atıştırmalıklar', 73, 53.0,  'RED'),
  ('Beyaz Şeker',         'Tatlandırıcılar', 92, 100.0, 'RED'),
  ('Çikolatalı Gofret',   'Atıştırmalıklar', 77, 65.0, 'RED'),
  ('Simit',               'Tahıllar',       72,  56.0,  'RED'),
  ('Gazlı İçecek (Kola)', 'İçecekler',     78,  10.6,  'RED'),
  ('Meyve Suyu (Paket)',  'İçecekler',      70,  11.0,  'RED'),
  ('Pilav',               'Tahıllar',       73,  28.0,  'RED'),
  ('Bisküvi',             'Atıştırmalıklar', 79, 68.0,  'RED'),
  ('Poğaça',              'Hamur İşleri',   72,  45.0,  'RED'),
  ('Börek',               'Hamur İşleri',   70,  34.0,  'RED'),
  ('Pide',                'Hamur İşleri',   78,  52.0,  'RED'),
  ('Waffle',              'Hamur İşleri',   76,  48.0,  'RED')
ON CONFLICT DO NOTHING;


-- ── Koç Eşleştirme Seed Verileri ─────────────────────────────

INSERT INTO public.coach_pairings (high_risk_category, balancer_category, advice_text) VALUES
  ('Tahıllar',        'Protein',       'Beyaz ekmek veya pirinç tüketirken yanında yumurta, tavuk veya balık gibi protein ekleyin. Protein, karbonhidratın emilimini yavaşlatarak kan şekeri tepkisini azaltır.'),
  ('Tahıllar',        'Sebzeler',      'Pilav veya makarna yanına bol yeşil salata ekleyin. Lif içeriği yüksek sebzeler şeker emilimini yavaşlatır ve tokluk hissi verir.'),
  ('Tahıllar',        'Yağlar',        'Ekmek yerken üstüne zeytinyağı veya avokado sürün. Sağlıklı yağlar glisemik yanıtı düşürmeye yardımcı olur.'),
  ('Meyveler',        'Kuruyemişler',  'Yüksek şekerli meyveler yerken bir avuç badem veya ceviz ekleyin. Kuruyemişlerdeki yağ ve protein şeker emilimini yavaşlatır.'),
  ('Meyveler',        'Süt Ürünleri',  'Meyveleri sade yoğurt ile birlikte tüketin. Yoğurdun protein ve yağ içeriği kan şekeri tepkisini dengelemeye yardımcı olur.'),
  ('Hamur İşleri',    'Sebzeler',      'Börek veya poğaça ile birlikte mutlaka yeşil salata veya çiğ sebze tüketin. Lif alımını artırarak şeker emilimini yavaşlatabilirsiniz.'),
  ('Hamur İşleri',    'Protein',       'Hamur işlerinin yanında az yağlı peynir veya haşlanmış yumurta ekleyin. Protein dengesi glisemik yükü azaltır.'),
  ('Atıştırmalıklar', 'Kuruyemişler',  'Bisküvi veya çikolata yerine bir avuç karışık kuruyemiş tercih edin. Eğer tatlı kriziniz varsa, kuruyemişle birlikte küçük bir parça bitter çikolata deneyin.'),
  ('Atıştırmalıklar', 'Baklagiller',   'Cipsi atıştırmak yerine haşlanmış nohut veya humus deneyin. Baklagiller düşük GI değeri ile güvenli bir alternatiftir.'),
  ('İçecekler',       'Sebzeler',      'Gazlı içecek veya paket meyve suyu yerine taze sıkılmış limonata (şekersiz) veya bitki çayı tercih edin.'),
  ('Tatlandırıcılar', 'Baklagiller',   'Bal veya şeker kullanımını azaltın. Tatlı ihtiyacınızı karşılamak için tarçınlı yoğurt veya meyve püresi deneyin.'),
  ('Fast Food',       'Sebzeler',      'Kızarmış patates yerine haşlanmış veya fırınlanmış sebze tercih edin. Eğer patates yiyecekseniz, yanında bol salata ve protein olsun.'),
  ('Fast Food',       'Protein',       'Fast food tüketirken mutlaka yanına protein ekleyin. Tavuk ızgara veya yumurta gibi protein kaynakları kan şekeri dengesini korumaya yardımcı olur.')
ON CONFLICT DO NOTHING;


-- ══════════════════════════════════════════════════════════════
-- ✅ KURULUM TAMAMLANDI
-- ══════════════════════════════════════════════════════════════
-- Tablolar: users, foods, consumption_logs, coach_pairings
-- RLS: Aktif — kullanıcı izolasyonu sağlanmış
-- Seed: 62 besin + 13 koç eşleştirmesi yüklendi
-- Trigger: Yeni auth kullanıcısı → otomatik profil oluşturma
-- ══════════════════════════════════════════════════════════════
