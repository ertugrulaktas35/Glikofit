-- ============================================================
-- GlikoFit v3 — Egzersiz Takibi + Mikro Besin Sütunları
-- ============================================================
-- Supabase SQL Editor'e yapıştırıp çalıştırın.
-- ============================================================


-- ══════════════════════════════════════════════════════════════
-- 1. FOODS TABLOSU — MİKRO BESİN SÜTUNLARI
-- ══════════════════════════════════════════════════════════════

ALTER TABLE public.foods
  ADD COLUMN IF NOT EXISTS sodium_mg        REAL DEFAULT 0 CHECK (sodium_mg >= 0),
  ADD COLUMN IF NOT EXISTS potassium_mg     REAL DEFAULT 0 CHECK (potassium_mg >= 0),
  ADD COLUMN IF NOT EXISTS vitamin_c_mg     REAL DEFAULT 0 CHECK (vitamin_c_mg >= 0),
  ADD COLUMN IF NOT EXISTS iron_mg          REAL DEFAULT 0 CHECK (iron_mg >= 0),
  ADD COLUMN IF NOT EXISTS cholesterol_mg   REAL DEFAULT 0 CHECK (cholesterol_mg >= 0),
  ADD COLUMN IF NOT EXISTS saturated_fat_g  REAL DEFAULT 0 CHECK (saturated_fat_g >= 0),
  ADD COLUMN IF NOT EXISTS sugar_g          REAL DEFAULT 0 CHECK (sugar_g >= 0),
  ADD COLUMN IF NOT EXISTS fatsecret_id     TEXT,       -- FatSecret food_id cache
  ADD COLUMN IF NOT EXISTS serving_description TEXT;    -- Örn: "1 kase (240ml)"

COMMENT ON COLUMN public.foods.fatsecret_id IS 'FatSecret food_id - makroları otomatik güncellemek için';


-- ══════════════════════════════════════════════════════════════
-- 2. EXERCISE_LOGS TABLOSU
-- ══════════════════════════════════════════════════════════════
-- Kullanıcının egzersiz kayıtları. Kalori yakımı hesabı için.

CREATE TABLE IF NOT EXISTS public.exercise_logs (
  id                BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id           UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,

  -- Egzersiz Bilgisi
  exercise_name     TEXT NOT NULL,
  exercise_category TEXT NOT NULL DEFAULT 'Genel',
  fatsecret_exercise_id BIGINT,                          -- FatSecret egzersiz ID'si

  -- Süre ve Yoğunluk
  duration_minutes  INT NOT NULL CHECK (duration_minutes > 0),
  intensity         TEXT DEFAULT 'orta'
    CHECK (intensity IN ('hafif', 'orta', 'yogun', 'cok_yogun')),

  -- Kalori Yakımı
  calories_burned   INT NOT NULL CHECK (calories_burned >= 0),

  -- Meta
  met_value         REAL,                               -- Metabolic Equivalent of Task
  log_date          DATE NOT NULL DEFAULT CURRENT_DATE,
  logged_at         TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_exercise_user_date
  ON public.exercise_logs (user_id, log_date DESC);

ALTER TABLE public.exercise_logs ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "exercise_select_own" ON public.exercise_logs;
CREATE POLICY "exercise_select_own" ON public.exercise_logs
  FOR SELECT USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "exercise_insert_own" ON public.exercise_logs;
CREATE POLICY "exercise_insert_own" ON public.exercise_logs
  FOR INSERT WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "exercise_update_own" ON public.exercise_logs;
CREATE POLICY "exercise_update_own" ON public.exercise_logs
  FOR UPDATE USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "exercise_delete_own" ON public.exercise_logs;
CREATE POLICY "exercise_delete_own" ON public.exercise_logs
  FOR DELETE USING (auth.uid() = user_id);

-- Diyetisyen egzersiz erişimi
DROP POLICY IF EXISTS "exercise_dietitian_read" ON public.exercise_logs;
CREATE POLICY "exercise_dietitian_read" ON public.exercise_logs
  FOR SELECT USING (
    auth.uid() = user_id
    OR public.is_my_dietitian(user_id)
  );


-- ══════════════════════════════════════════════════════════════
-- 3. BARKOD ÖNBELLEK TABLOSU
-- ══════════════════════════════════════════════════════════════
-- Taranmış barkodların tekrar aranmaması için cache.

CREATE TABLE IF NOT EXISTS public.barcode_cache (
  id              BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  barcode         TEXT NOT NULL UNIQUE,                  -- UPC/EAN barkod
  food_id         BIGINT REFERENCES public.foods(id),    -- Yerel DB'deki karşılık
  fatsecret_id    TEXT,                                  -- FatSecret food_id
  food_name       TEXT,
  brand           TEXT,
  cached_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_barcode ON public.barcode_cache (barcode);

ALTER TABLE public.barcode_cache ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "barcode_public_read" ON public.barcode_cache;
CREATE POLICY "barcode_public_read" ON public.barcode_cache
  FOR SELECT USING (true);

DROP POLICY IF EXISTS "barcode_insert_auth" ON public.barcode_cache;
CREATE POLICY "barcode_insert_auth" ON public.barcode_cache
  FOR INSERT WITH CHECK (auth.uid() IS NOT NULL);


-- ══════════════════════════════════════════════════════════════
-- 4. GÜNLÜK ÖZET VIEW (Egzersiz dahil net kalori)
-- ══════════════════════════════════════════════════════════════

CREATE OR REPLACE VIEW public.daily_nutrition_exercise_summary AS
SELECT
  c.user_id,
  c.consumed_at::DATE                                AS log_date,
  ROUND(SUM(f.calories_per_100g * c.portion_grams / 100)::NUMERIC, 0) AS total_calories_in,
  ROUND(SUM(f.carbs_per_100g * c.portion_grams / 100)::NUMERIC, 1)    AS total_carbs,
  ROUND(SUM(f.protein_per_100g * c.portion_grams / 100)::NUMERIC, 1)  AS total_protein,
  ROUND(SUM(f.fat_per_100g * c.portion_grams / 100)::NUMERIC, 1)      AS total_fat,
  COALESCE(e.total_calories_burned, 0)               AS total_calories_burned,
  ROUND(
    (SUM(f.calories_per_100g * c.portion_grams / 100)
     - COALESCE(e.total_calories_burned, 0))::NUMERIC,
  0)                                                 AS net_calories
FROM public.consumption_logs c
JOIN public.foods f ON c.food_id = f.id
LEFT JOIN (
  SELECT user_id, log_date, SUM(calories_burned) AS total_calories_burned
  FROM public.exercise_logs
  GROUP BY user_id, log_date
) e ON c.user_id = e.user_id AND c.consumed_at::DATE = e.log_date
GROUP BY c.user_id, c.consumed_at::DATE, e.total_calories_burned;


-- ══════════════════════════════════════════════════════════════
-- 5. REALTIME PUBLICATION GÜNCELLEMESİ
-- ══════════════════════════════════════════════════════════════

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_publication WHERE pubname = 'supabase_realtime') THEN
    ALTER PUBLICATION supabase_realtime
      ADD TABLE exercise_logs;
  END IF;
EXCEPTION WHEN OTHERS THEN
  RAISE NOTICE 'Realtime publication güncellemesi atlandı: %', SQLERRM;
END;
$$;


-- ══════════════════════════════════════════════════════════════
-- ✅ V3 MİGRASYON TAMAMLANDI
-- ══════════════════════════════════════════════════════════════
-- Yeni Tablolar: exercise_logs, barcode_cache
-- Yeni Sütunlar: foods.sodium_mg, potassium_mg, vitamin_c_mg,
--                iron_mg, cholesterol_mg, saturated_fat_g,
--                sugar_g, fatsecret_id, serving_description
-- View: daily_nutrition_exercise_summary
-- ══════════════════════════════════════════════════════════════
