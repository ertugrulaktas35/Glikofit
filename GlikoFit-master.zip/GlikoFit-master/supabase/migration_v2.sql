-- ============================================================
-- 🩸 GlikoFit v2 — Migration Script
-- ============================================================
-- Bu dosyayı Supabase SQL Editor'e yapıştırıp çalıştırın.
-- Mevcut yapıya yeni tablolar, sütunlar, fonksiyonlar ve
-- RLS politikaları ekler.
-- ============================================================


-- ══════════════════════════════════════════════════════════════
-- 0. EXTENSIONS
-- ══════════════════════════════════════════════════════════════

CREATE EXTENSION IF NOT EXISTS pg_trgm;


-- ══════════════════════════════════════════════════════════════
-- 1. FOODS TABLOSU — MAKRO SÜTUNLARI EKLENMESİ
-- ══════════════════════════════════════════════════════════════

ALTER TABLE public.foods
  ADD COLUMN IF NOT EXISTS protein_per_100g   REAL DEFAULT 0 CHECK (protein_per_100g >= 0),
  ADD COLUMN IF NOT EXISTS fat_per_100g       REAL DEFAULT 0 CHECK (fat_per_100g >= 0),
  ADD COLUMN IF NOT EXISTS calories_per_100g  REAL DEFAULT 0 CHECK (calories_per_100g >= 0),
  ADD COLUMN IF NOT EXISTS fiber_per_100g     REAL DEFAULT 0 CHECK (fiber_per_100g >= 0),
  ADD COLUMN IF NOT EXISTS source             TEXT DEFAULT 'manual'
    CHECK (source IN ('manual', 'fatsecret', 'gemini_vision', 'usda'));

COMMENT ON COLUMN public.foods.source IS 'Veri kaynağı: manual, fatsecret, gemini_vision, usda';

-- Trigram indeksi (fuzzy arama için)
CREATE INDEX IF NOT EXISTS idx_foods_name_trgm
  ON public.foods USING gin (name gin_trgm_ops);


-- ══════════════════════════════════════════════════════════════
-- 2. USERS TABLOSU — ROL ALANI
-- ══════════════════════════════════════════════════════════════

ALTER TABLE public.users
  ADD COLUMN IF NOT EXISTS role TEXT DEFAULT 'client'
    CHECK (role IN ('client', 'dietitian', 'admin'));


-- ══════════════════════════════════════════════════════════════
-- 3. USER_HEALTH_PROFILES TABLOSU
-- ══════════════════════════════════════════════════════════════
-- AsyncStorage'dan Supabase'e taşınan sağlık profili.

CREATE TABLE IF NOT EXISTS public.user_health_profiles (
  id              BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id         UUID NOT NULL UNIQUE REFERENCES public.users(id) ON DELETE CASCADE,

  -- Demografik
  full_name       TEXT NOT NULL,
  birth_year      INT NOT NULL CHECK (birth_year > 1900 AND birth_year <= EXTRACT(YEAR FROM now())),
  gender          TEXT NOT NULL CHECK (gender IN ('erkek', 'kadin')),
  height_cm       REAL NOT NULL CHECK (height_cm > 0 AND height_cm < 300),
  weight_kg       REAL NOT NULL CHECK (weight_kg > 0 AND weight_kg < 500),

  -- Klinik
  diabetes_type   TEXT NOT NULL DEFAULT 'yok'
    CHECK (diabetes_type IN ('tip1', 'tip2', 'prediyabet', 'gestasyonel', 'yok')),
  hba1c           REAL CHECK (hba1c IS NULL OR (hba1c >= 3.0 AND hba1c <= 20.0)),
  fasting_glucose INT CHECK (fasting_glucose IS NULL OR (fasting_glucose >= 30 AND fasting_glucose <= 600)),
  activity_level  TEXT NOT NULL DEFAULT 'sedanter'
    CHECK (activity_level IN ('sedanter', 'hafif_aktif', 'aktif', 'cok_aktif')),

  -- Hesaplanmış
  bmi             REAL GENERATED ALWAYS AS (weight_kg / POWER(height_cm / 100.0, 2)) STORED,

  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_uhp_user_id ON public.user_health_profiles (user_id);

ALTER TABLE public.user_health_profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "uhp_select_own" ON public.user_health_profiles
  FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "uhp_insert_own" ON public.user_health_profiles
  FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "uhp_update_own" ON public.user_health_profiles
  FOR UPDATE USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);


-- ══════════════════════════════════════════════════════════════
-- 4. MOOD_LOGS TABLOSU
-- ══════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS public.mood_logs (
  id                  BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id             UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  consumption_log_id  BIGINT REFERENCES public.consumption_logs(id) ON DELETE SET NULL,

  mood_score          INT NOT NULL CHECK (mood_score >= 1 AND mood_score <= 10),
  stress_level        INT CHECK (stress_level >= 1 AND stress_level <= 10),
  energy_level        INT CHECK (energy_level >= 1 AND energy_level <= 10),

  mood_tags           TEXT[] DEFAULT '{}',
  notes               TEXT,
  recorded_at         TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_mood_user_date
  ON public.mood_logs (user_id, recorded_at DESC);
CREATE INDEX IF NOT EXISTS idx_mood_consumption
  ON public.mood_logs (consumption_log_id)
  WHERE consumption_log_id IS NOT NULL;

ALTER TABLE public.mood_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "mood_select_own" ON public.mood_logs
  FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "mood_insert_own" ON public.mood_logs
  FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "mood_update_own" ON public.mood_logs
  FOR UPDATE USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "mood_delete_own" ON public.mood_logs
  FOR DELETE USING (auth.uid() = user_id);


-- ══════════════════════════════════════════════════════════════
-- 5. SLEEP_LOGS TABLOSU
-- ══════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS public.sleep_logs (
  id              BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id         UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,

  sleep_date      DATE NOT NULL,
  bed_time        TIMESTAMPTZ NOT NULL,
  wake_time       TIMESTAMPTZ NOT NULL,
  duration_minutes INT GENERATED ALWAYS AS (
    EXTRACT(EPOCH FROM (wake_time - bed_time)) / 60
  ) STORED,

  quality_score   INT CHECK (quality_score >= 1 AND quality_score <= 10),
  interruptions   INT DEFAULT 0 CHECK (interruptions >= 0),

  notes           TEXT,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),

  UNIQUE (user_id, sleep_date)
);

CREATE INDEX IF NOT EXISTS idx_sleep_user_date
  ON public.sleep_logs (user_id, sleep_date DESC);

ALTER TABLE public.sleep_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "sleep_select_own" ON public.sleep_logs
  FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "sleep_insert_own" ON public.sleep_logs
  FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "sleep_update_own" ON public.sleep_logs
  FOR UPDATE USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "sleep_delete_own" ON public.sleep_logs
  FOR DELETE USING (auth.uid() = user_id);


-- ══════════════════════════════════════════════════════════════
-- 6. WATER_LOGS TABLOSU
-- ══════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS public.water_logs (
  id              BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id         UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,

  amount_ml       INT NOT NULL CHECK (amount_ml > 0 AND amount_ml <= 5000),
  log_date        DATE NOT NULL DEFAULT CURRENT_DATE,
  logged_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_water_user_date
  ON public.water_logs (user_id, log_date DESC);

ALTER TABLE public.water_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "water_select_own" ON public.water_logs
  FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "water_insert_own" ON public.water_logs
  FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "water_delete_own" ON public.water_logs
  FOR DELETE USING (auth.uid() = user_id);


-- ══════════════════════════════════════════════════════════════
-- 7. CAFFEINE_LOGS TABLOSU
-- ══════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS public.caffeine_logs (
  id              BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id         UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,

  beverage_type   TEXT NOT NULL
    CHECK (beverage_type IN (
      'turk_kahvesi', 'filtre_kahve', 'espresso',
      'siyah_cay', 'yesil_cay', 'enerji_icecegi', 'kola', 'diger'
    )),
  caffeine_mg     INT NOT NULL CHECK (caffeine_mg >= 0 AND caffeine_mg <= 1000),
  volume_ml       INT CHECK (volume_ml > 0),

  log_date        DATE NOT NULL DEFAULT CURRENT_DATE,
  logged_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);

COMMENT ON TABLE public.caffeine_logs IS
  'Kafein referansları: Türk Kahvesi ~50mg/fincan, Filtre ~95mg, '
  'Espresso ~63mg, Siyah Çay ~47mg, Yeşil Çay ~28mg, '
  'Enerji İçeceği ~80mg/250ml, Kola ~34mg/330ml';

CREATE INDEX IF NOT EXISTS idx_caffeine_user_date
  ON public.caffeine_logs (user_id, log_date DESC);

ALTER TABLE public.caffeine_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "caffeine_select_own" ON public.caffeine_logs
  FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "caffeine_insert_own" ON public.caffeine_logs
  FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "caffeine_delete_own" ON public.caffeine_logs
  FOR DELETE USING (auth.uid() = user_id);


-- ══════════════════════════════════════════════════════════════
-- 8. PHOTO_ANALYSES TABLOSU
-- ══════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS public.photo_analyses (
  id              BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id         UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,

  image_url       TEXT NOT NULL,
  image_hash      TEXT,

  detected_items  JSONB NOT NULL DEFAULT '[]',
  total_calories  REAL DEFAULT 0,
  total_carbs     REAL DEFAULT 0,
  total_protein   REAL DEFAULT 0,
  total_fat       REAL DEFAULT 0,
  total_gi_load   REAL DEFAULT 0,

  processing_time_ms INT,
  model_version   TEXT DEFAULT 'gemini-1.5-flash',
  status          TEXT NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending', 'processing', 'completed', 'failed', 'reviewed')),
  error_message   TEXT,

  reviewed_by     UUID REFERENCES public.users(id),
  review_notes    TEXT,

  analyzed_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_photo_user_date
  ON public.photo_analyses (user_id, analyzed_at DESC);
CREATE INDEX IF NOT EXISTS idx_photo_status
  ON public.photo_analyses (status);

ALTER TABLE public.photo_analyses ENABLE ROW LEVEL SECURITY;

CREATE POLICY "photo_select_own" ON public.photo_analyses
  FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "photo_insert_own" ON public.photo_analyses
  FOR INSERT WITH CHECK (auth.uid() = user_id);


-- ══════════════════════════════════════════════════════════════
-- 9. DIETITIAN_ASSIGNMENTS TABLOSU
-- ══════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS public.dietitian_assignments (
  id              BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  dietitian_id    UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  client_id       UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,

  status          TEXT NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending', 'active', 'paused', 'terminated')),

  assigned_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  activated_at    TIMESTAMPTZ,

  UNIQUE (dietitian_id, client_id)
);

CREATE INDEX IF NOT EXISTS idx_da_dietitian ON public.dietitian_assignments (dietitian_id);
CREATE INDEX IF NOT EXISTS idx_da_client ON public.dietitian_assignments (client_id);

ALTER TABLE public.dietitian_assignments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "da_select_own" ON public.dietitian_assignments
  FOR SELECT USING (
    auth.uid() = dietitian_id OR auth.uid() = client_id
  );

CREATE POLICY "da_insert_dietitian" ON public.dietitian_assignments
  FOR INSERT WITH CHECK (auth.uid() = dietitian_id);


-- ══════════════════════════════════════════════════════════════
-- 10. DİYETİSYEN CROSS-TABLE ERİŞİM FONKSİYONU
-- ══════════════════════════════════════════════════════════════

CREATE OR REPLACE FUNCTION public.is_my_dietitian(target_user_id UUID)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = ''
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.dietitian_assignments
    WHERE dietitian_id = auth.uid()
      AND client_id = target_user_id
      AND status = 'active'
  );
$$;

-- Diyetisyen erişim politikaları
CREATE POLICY "consumption_logs_dietitian_read" ON public.consumption_logs
  FOR SELECT USING (
    auth.uid() = user_id
    OR public.is_my_dietitian(user_id)
  );

CREATE POLICY "mood_dietitian_read" ON public.mood_logs
  FOR SELECT USING (
    auth.uid() = user_id
    OR public.is_my_dietitian(user_id)
  );

CREATE POLICY "sleep_dietitian_read" ON public.sleep_logs
  FOR SELECT USING (
    auth.uid() = user_id
    OR public.is_my_dietitian(user_id)
  );

CREATE POLICY "water_dietitian_read" ON public.water_logs
  FOR SELECT USING (
    auth.uid() = user_id
    OR public.is_my_dietitian(user_id)
  );

CREATE POLICY "caffeine_dietitian_read" ON public.caffeine_logs
  FOR SELECT USING (
    auth.uid() = user_id
    OR public.is_my_dietitian(user_id)
  );

CREATE POLICY "photo_dietitian_read" ON public.photo_analyses
  FOR SELECT USING (
    auth.uid() = user_id
    OR public.is_my_dietitian(user_id)
  );

CREATE POLICY "uhp_dietitian_read" ON public.user_health_profiles
  FOR SELECT USING (
    auth.uid() = user_id
    OR public.is_my_dietitian(user_id)
  );


-- ══════════════════════════════════════════════════════════════
-- 11. FUZZY FOOD SEARCH FONKSİYONU
-- ══════════════════════════════════════════════════════════════

CREATE OR REPLACE FUNCTION public.fuzzy_food_search(
  search_term TEXT,
  similarity_threshold REAL DEFAULT 0.3,
  max_results INT DEFAULT 5
)
RETURNS TABLE (
  id              BIGINT,
  name            TEXT,
  category        TEXT,
  gi_value        INT,
  carbs_per_100g  REAL,
  protein_per_100g REAL,
  fat_per_100g    REAL,
  calories_per_100g REAL,
  color_code      TEXT,
  similarity      REAL
)
LANGUAGE sql
STABLE
AS $$
  SELECT
    f.id,
    f.name,
    f.category,
    f.gi_value,
    f.carbs_per_100g,
    f.protein_per_100g,
    f.fat_per_100g,
    f.calories_per_100g,
    f.color_code,
    similarity(f.name, search_term) AS similarity
  FROM public.foods f
  WHERE similarity(f.name, search_term) >= similarity_threshold
  ORDER BY similarity DESC
  LIMIT max_results;
$$;


-- ══════════════════════════════════════════════════════════════
-- 12. GI TAHMİN FONKSİYONU (Makro tabanlı)
-- ══════════════════════════════════════════════════════════════

CREATE OR REPLACE FUNCTION public.estimate_gi_from_macros(
  carbs REAL,
  fiber REAL DEFAULT 0,
  fat   REAL DEFAULT 0,
  protein REAL DEFAULT 0
)
RETURNS INT
LANGUAGE plpgsql
IMMUTABLE
AS $$
DECLARE
  estimated_gi INT;
  carb_density REAL;
BEGIN
  carb_density := COALESCE(carbs, 0);

  CASE
    WHEN carb_density < 5  THEN estimated_gi := 15;
    WHEN carb_density < 15 THEN estimated_gi := 35;
    WHEN carb_density < 30 THEN estimated_gi := 50;
    WHEN carb_density < 50 THEN estimated_gi := 60;
    WHEN carb_density < 70 THEN estimated_gi := 70;
    ELSE estimated_gi := 80;
  END CASE;

  IF COALESCE(fiber, 0) > 3 THEN
    estimated_gi := estimated_gi - LEAST(15, FLOOR(fiber * 2));
  END IF;

  IF COALESCE(fat, 0) > 5 THEN
    estimated_gi := estimated_gi - LEAST(10, FLOOR(fat * 0.5));
  END IF;

  IF COALESCE(protein, 0) > 10 THEN
    estimated_gi := estimated_gi - LEAST(8, FLOOR(protein * 0.3));
  END IF;

  RETURN GREATEST(0, LEAST(100, estimated_gi));
END;
$$;


-- ══════════════════════════════════════════════════════════════
-- 13. KORELASYON VE ÖZET VIEW'LARI
-- ══════════════════════════════════════════════════════════════

-- Günlük su özeti
CREATE OR REPLACE VIEW public.daily_water_summary AS
SELECT
  user_id,
  log_date,
  SUM(amount_ml) AS total_ml,
  COUNT(*)       AS entry_count
FROM public.water_logs
GROUP BY user_id, log_date;

-- Günlük kafein özeti
CREATE OR REPLACE VIEW public.daily_caffeine_summary AS
SELECT
  user_id,
  log_date,
  SUM(caffeine_mg) AS total_caffeine_mg,
  COUNT(*)          AS entry_count,
  CASE
    WHEN SUM(caffeine_mg) > 400 THEN 'UYARI'
    WHEN SUM(caffeine_mg) > 300 THEN 'DİKKAT'
    ELSE 'NORMAL'
  END AS daily_status
FROM public.caffeine_logs
GROUP BY user_id, log_date;

-- Günlük duygu durumu özeti
CREATE OR REPLACE VIEW public.daily_mood_summary AS
SELECT
  user_id,
  recorded_at::DATE       AS log_date,
  ROUND(AVG(mood_score)::NUMERIC, 1)    AS avg_mood,
  ROUND(AVG(stress_level)::NUMERIC, 1)  AS avg_stress,
  ROUND(AVG(energy_level)::NUMERIC, 1)  AS avg_energy,
  COUNT(*)                               AS entry_count
FROM public.mood_logs
GROUP BY user_id, recorded_at::DATE;

-- Mood-Glucose korelasyon view'ı
CREATE OR REPLACE VIEW public.mood_glucose_correlation AS
SELECT
  m.user_id,
  m.recorded_at::DATE                    AS log_date,
  m.mood_score,
  m.stress_level,
  m.energy_level,
  m.mood_tags,
  cl.consumed_at,
  cl.calculated_gl,
  f.gi_value,
  f.name                                 AS food_name,
  f.color_code,
  CASE
    WHEN m.stress_level IS NOT NULL AND f.gi_value IS NOT NULL THEN
      ROUND(
        (COALESCE(m.stress_level, 5) * 0.4 + (f.gi_value / 10.0) * 0.6)::NUMERIC,
        1
      )
    ELSE NULL
  END AS cortisol_risk_score,
  EXTRACT(EPOCH FROM (m.recorded_at - cl.consumed_at)) / 60 AS minutes_after_meal
FROM public.mood_logs m
LEFT JOIN public.consumption_logs cl
  ON m.consumption_log_id = cl.id
LEFT JOIN public.foods f
  ON cl.food_id = f.id;


-- ══════════════════════════════════════════════════════════════
-- 14. REALTIME PUBLICATION
-- ══════════════════════════════════════════════════════════════
-- Not: Bu satır Supabase Dashboard üzerinden de yapılabilir.
-- Eğer supabase_realtime publication yoksa hata verebilir,
-- o durumda Dashboard > Database > Replication kısmından etkinleştirin.

DO $$
BEGIN
  -- Mevcut publication varsa tabloları ekle
  IF EXISTS (SELECT 1 FROM pg_publication WHERE pubname = 'supabase_realtime') THEN
    ALTER PUBLICATION supabase_realtime
      ADD TABLE consumption_logs, mood_logs, photo_analyses,
                sleep_logs, water_logs, caffeine_logs;
  END IF;
EXCEPTION WHEN OTHERS THEN
  RAISE NOTICE 'Realtime publication güncellemesi atlandı: %', SQLERRM;
END;
$$;


-- ══════════════════════════════════════════════════════════════
-- ✅ V2 MİGRASYON TAMAMLANDI
-- ══════════════════════════════════════════════════════════════
-- Yeni Tablolar: user_health_profiles, mood_logs, sleep_logs,
--                water_logs, caffeine_logs, photo_analyses,
--                dietitian_assignments
-- Yeni Sütunlar: foods.protein/fat/calories/fiber/source,
--                users.role
-- Fonksiyonlar:  fuzzy_food_search, estimate_gi_from_macros,
--                is_my_dietitian
-- View'lar:      daily_water_summary, daily_caffeine_summary,
--                daily_mood_summary, mood_glucose_correlation
-- ══════════════════════════════════════════════════════════════
