-- ============================================================
-- 🥗 GlikoFit — Mevcut Besinlere Makro Veri Güncelleme
-- ============================================================
-- Bu SQL'i çalıştırınca 62 besinin tamamı için
-- protein, yağ, kalori ve lif değerleri otomatik dolar.
-- Veri kaynağı: USDA FoodData Central + genel beslenme tabloları
-- ============================================================
-- Supabase SQL Editor'de çalıştırın.
-- ============================================================

-- ══════════════════════════════════════════════════════════════
-- SEBZELER
-- ══════════════════════════════════════════════════════════════
UPDATE public.foods SET protein_per_100g=2.8,  fat_per_100g=0.4,  calories_per_100g=34,   fiber_per_100g=2.6,  source='usda' WHERE name='Brokoli';
UPDATE public.foods SET protein_per_100g=2.9,  fat_per_100g=0.4,  calories_per_100g=23,   fiber_per_100g=2.2,  source='usda' WHERE name='Ispanak';
UPDATE public.foods SET protein_per_100g=0.9,  fat_per_100g=0.2,  calories_per_100g=18,   fiber_per_100g=1.2,  source='usda' WHERE name='Domates';
UPDATE public.foods SET protein_per_100g=0.7,  fat_per_100g=0.1,  calories_per_100g=15,   fiber_per_100g=0.5,  source='usda' WHERE name='Salatalık';
UPDATE public.foods SET protein_per_100g=1.9,  fat_per_100g=0.3,  calories_per_100g=25,   fiber_per_100g=2.0,  source='usda' WHERE name='Karnabahar';
UPDATE public.foods SET protein_per_100g=1.2,  fat_per_100g=0.3,  calories_per_100g=17,   fiber_per_100g=1.0,  source='usda' WHERE name='Kabak';
UPDATE public.foods SET protein_per_100g=5.0,  fat_per_100g=0.4,  calories_per_100g=116,  fiber_per_100g=7.9,  source='usda' WHERE name='Yeşil Mercimek';
UPDATE public.foods SET protein_per_100g=8.1,  fat_per_100g=0.4,  calories_per_100g=116,  fiber_per_100g=8.0,  source='usda' WHERE name='Kırmızı Mercimek';
UPDATE public.foods SET protein_per_100g=8.9,  fat_per_100g=2.6,  calories_per_100g=164,  fiber_per_100g=7.6,  source='usda' WHERE name='Nohut';
UPDATE public.foods SET protein_per_100g=8.7,  fat_per_100g=0.5,  calories_per_100g=127,  fiber_per_100g=6.4,  source='usda' WHERE name='Kuru Fasulye';
UPDATE public.foods SET protein_per_100g=5.4,  fat_per_100g=0.4,  calories_per_100g=81,   fiber_per_100g=7.5,  source='usda' WHERE name='Bezelye';
UPDATE public.foods SET protein_per_100g=1.6,  fat_per_100g=0.1,  calories_per_100g=86,   fiber_per_100g=3.0,  source='usda' WHERE name='Patates (Haşlama)';
UPDATE public.foods SET protein_per_100g=1.6,  fat_per_100g=0.1,  calories_per_100g=90,   fiber_per_100g=3.0,  source='usda' WHERE name='Tatlı Patates';
UPDATE public.foods SET protein_per_100g=1.9,  fat_per_100g=14.7, calories_per_100g=365,  fiber_per_100g=3.5,  source='usda' WHERE name='Patates (Kızartma)';

-- ══════════════════════════════════════════════════════════════
-- MEYVELER
-- ══════════════════════════════════════════════════════════════
UPDATE public.foods SET protein_per_100g=0.3,  fat_per_100g=0.2,  calories_per_100g=52,   fiber_per_100g=2.4,  source='usda' WHERE name='Elma';
UPDATE public.foods SET protein_per_100g=0.4,  fat_per_100g=0.1,  calories_per_100g=57,   fiber_per_100g=3.1,  source='usda' WHERE name='Armut';
UPDATE public.foods SET protein_per_100g=0.9,  fat_per_100g=0.1,  calories_per_100g=47,   fiber_per_100g=2.4,  source='usda' WHERE name='Portakal';
UPDATE public.foods SET protein_per_100g=0.7,  fat_per_100g=0.3,  calories_per_100g=32,   fiber_per_100g=2.0,  source='usda' WHERE name='Çilek';
UPDATE public.foods SET protein_per_100g=1.1,  fat_per_100g=0.2,  calories_per_100g=63,   fiber_per_100g=2.1,  source='usda' WHERE name='Kiraz';
UPDATE public.foods SET protein_per_100g=0.7,  fat_per_100g=0.3,  calories_per_100g=46,   fiber_per_100g=1.4,  source='usda' WHERE name='Erik';
UPDATE public.foods SET protein_per_100g=0.8,  fat_per_100g=0.1,  calories_per_100g=42,   fiber_per_100g=1.6,  source='usda' WHERE name='Greyfurt';
UPDATE public.foods SET protein_per_100g=1.1,  fat_per_100g=0.3,  calories_per_100g=89,   fiber_per_100g=2.6,  source='usda' WHERE name='Muz';
UPDATE public.foods SET protein_per_100g=0.7,  fat_per_100g=0.2,  calories_per_100g=69,   fiber_per_100g=0.9,  source='usda' WHERE name='Üzüm';
UPDATE public.foods SET protein_per_100g=1.4,  fat_per_100g=0.4,  calories_per_100g=48,   fiber_per_100g=2.0,  source='usda' WHERE name='Kayısı';
UPDATE public.foods SET protein_per_100g=0.5,  fat_per_100g=0.1,  calories_per_100g=50,   fiber_per_100g=1.4,  source='usda' WHERE name='Ananas';
UPDATE public.foods SET protein_per_100g=1.1,  fat_per_100g=0.5,  calories_per_100g=61,   fiber_per_100g=3.0,  source='usda' WHERE name='Kivi';
UPDATE public.foods SET protein_per_100g=0.8,  fat_per_100g=0.4,  calories_per_100g=60,   fiber_per_100g=1.6,  source='usda' WHERE name='Mango';
UPDATE public.foods SET protein_per_100g=0.6,  fat_per_100g=0.2,  calories_per_100g=30,   fiber_per_100g=0.4,  source='usda' WHERE name='Karpuz';
UPDATE public.foods SET protein_per_100g=2.5,  fat_per_100g=0.4,  calories_per_100g=277,  fiber_per_100g=8.0,  source='usda' WHERE name='Hurma';

-- ══════════════════════════════════════════════════════════════
-- KURUYEMIŞLER
-- ══════════════════════════════════════════════════════════════
UPDATE public.foods SET protein_per_100g=15.2, fat_per_100g=65.2, calories_per_100g=654,  fiber_per_100g=6.7,  source='usda' WHERE name='Ceviz';
UPDATE public.foods SET protein_per_100g=21.2, fat_per_100g=49.9, calories_per_100g=579,  fiber_per_100g=12.5, source='usda' WHERE name='Badem';
UPDATE public.foods SET protein_per_100g=15.0, fat_per_100g=60.8, calories_per_100g=628,  fiber_per_100g=9.7,  source='usda' WHERE name='Fındık';

-- ══════════════════════════════════════════════════════════════
-- TAHILLAR
-- ══════════════════════════════════════════════════════════════
UPDATE public.foods SET protein_per_100g=16.9, fat_per_100g=6.9,  calories_per_100g=389,  fiber_per_100g=10.6, source='usda' WHERE name='Yulaf Ezmesi';
UPDATE public.foods SET protein_per_100g=12.0, fat_per_100g=2.5,  calories_per_100g=247,  fiber_per_100g=6.8,  source='usda' WHERE name='Tam Buğday Ekmek';
UPDATE public.foods SET protein_per_100g=12.3, fat_per_100g=1.3,  calories_per_100g=342,  fiber_per_100g=4.5,  source='usda' WHERE name='Bulgur';
UPDATE public.foods SET protein_per_100g=7.9,  fat_per_100g=1.9,  calories_per_100g=362,  fiber_per_100g=3.5,  source='usda' WHERE name='Esmer Pirinç';
UPDATE public.foods SET protein_per_100g=13.0, fat_per_100g=1.9,  calories_per_100g=352,  fiber_per_100g=8.7,  source='usda' WHERE name='Tam Buğday Makarna';
UPDATE public.foods SET protein_per_100g=8.1,  fat_per_100g=1.2,  calories_per_100g=264,  fiber_per_100g=2.8,  source='usda' WHERE name='Beyaz Ekmek';
UPDATE public.foods SET protein_per_100g=8.7,  fat_per_100g=1.3,  calories_per_100g=365,  fiber_per_100g=0.6,  source='usda' WHERE name='Beyaz Pirinç';
UPDATE public.foods SET protein_per_100g=9.0,  fat_per_100g=2.0,  calories_per_100g=270,  fiber_per_100g=2.7,  source='usda' WHERE name='Baget Ekmek';
UPDATE public.foods SET protein_per_100g=7.5,  fat_per_100g=0.9,  calories_per_100g=379,  fiber_per_100g=3.6,  source='usda' WHERE name='Mısır Gevreği';
UPDATE public.foods SET protein_per_100g=6.5,  fat_per_100g=1.2,  calories_per_100g=401,  fiber_per_100g=0.8,  source='usda' WHERE name='Pirinç Patlağı';
UPDATE public.foods SET protein_per_100g=5.1,  fat_per_100g=1.2,  calories_per_100g=254,  fiber_per_100g=2.0,  source='usda' WHERE name='Müsli';
UPDATE public.foods SET protein_per_100g=8.4,  fat_per_100g=1.3,  calories_per_100g=258,  fiber_per_100g=6.2,  source='usda' WHERE name='Çavdar Ekmek';
UPDATE public.foods SET protein_per_100g=5.9,  fat_per_100g=0.3,  calories_per_100g=126,  fiber_per_100g=0.5,  source='usda' WHERE name='Pilav';
UPDATE public.foods SET protein_per_100g=12.0, fat_per_100g=2.0,  calories_per_100g=275,  fiber_per_100g=2.5,  source='usda' WHERE name='Simit';
UPDATE public.foods SET protein_per_100g=5.0,  fat_per_100g=1.5,  calories_per_100g=250,  fiber_per_100g=1.8,  source='usda' WHERE name='Beyaz Makarna';
UPDATE public.foods SET protein_per_100g=7.0,  fat_per_100g=1.0,  calories_per_100g=340,  fiber_per_100g=1.2,  source='usda' WHERE name='Basmati Pirinç';

-- ══════════════════════════════════════════════════════════════
-- SÜT ÜRÜNLERİ
-- ══════════════════════════════════════════════════════════════
UPDATE public.foods SET protein_per_100g=3.5,  fat_per_100g=3.3,  calories_per_100g=59,   fiber_per_100g=0.0,  source='usda' WHERE name='Yoğurt (Sade)';
UPDATE public.foods SET protein_per_100g=3.2,  fat_per_100g=3.7,  calories_per_100g=61,   fiber_per_100g=0.0,  source='usda' WHERE name='Süt (Tam Yağlı)';
UPDATE public.foods SET protein_per_100g=18.0, fat_per_100g=20.0, calories_per_100g=264,  fiber_per_100g=0.0,  source='usda' WHERE name='Peynir (Beyaz)';

-- ══════════════════════════════════════════════════════════════
-- PROTEİN KAYNAKLARI
-- ══════════════════════════════════════════════════════════════
UPDATE public.foods SET protein_per_100g=12.6, fat_per_100g=10.6, calories_per_100g=155,  fiber_per_100g=0.0,  source='usda' WHERE name='Yumurta';
UPDATE public.foods SET protein_per_100g=31.0, fat_per_100g=3.6,  calories_per_100g=165,  fiber_per_100g=0.0,  source='usda' WHERE name='Tavuk Göğsü';
UPDATE public.foods SET protein_per_100g=25.4, fat_per_100g=13.4, calories_per_100g=208,  fiber_per_100g=0.0,  source='usda' WHERE name='Balık (Somon)';

-- ══════════════════════════════════════════════════════════════
-- YAĞLAR
-- ══════════════════════════════════════════════════════════════
UPDATE public.foods SET protein_per_100g=0.0,  fat_per_100g=100.0,calories_per_100g=884,  fiber_per_100g=0.0,  source='usda' WHERE name='Zeytinyağı';

-- ══════════════════════════════════════════════════════════════
-- TATLANDIRICILER
-- ══════════════════════════════════════════════════════════════
UPDATE public.foods SET protein_per_100g=0.3,  fat_per_100g=0.0,  calories_per_100g=304,  fiber_per_100g=0.2,  source='usda' WHERE name='Bal';
UPDATE public.foods SET protein_per_100g=0.0,  fat_per_100g=0.0,  calories_per_100g=387,  fiber_per_100g=0.0,  source='usda' WHERE name='Beyaz Şeker';

-- ══════════════════════════════════════════════════════════════
-- ATIŞTIRMALİKLAR & FAST FOOD
-- ══════════════════════════════════════════════════════════════
UPDATE public.foods SET protein_per_100g=6.0,  fat_per_100g=28.2, calories_per_100g=536,  fiber_per_100g=4.4,  source='usda' WHERE name='Patates Cipsi';
UPDATE public.foods SET protein_per_100g=4.5,  fat_per_100g=21.0, calories_per_100g=490,  fiber_per_100g=1.5,  source='usda' WHERE name='Çikolatalı Gofret';
UPDATE public.foods SET protein_per_100g=6.0,  fat_per_100g=15.0, calories_per_100g=440,  fiber_per_100g=1.5,  source='usda' WHERE name='Bisküvi';

-- ══════════════════════════════════════════════════════════════
-- HAMUR İŞLERİ
-- ══════════════════════════════════════════════════════════════
UPDATE public.foods SET protein_per_100g=7.0,  fat_per_100g=12.0, calories_per_100g=340,  fiber_per_100g=1.2,  source='usda' WHERE name='Poğaça';
UPDATE public.foods SET protein_per_100g=9.0,  fat_per_100g=14.5, calories_per_100g=340,  fiber_per_100g=1.5,  source='usda' WHERE name='Börek';
UPDATE public.foods SET protein_per_100g=10.0, fat_per_100g=3.5,  calories_per_100g=273,  fiber_per_100g=1.6,  source='usda' WHERE name='Pide';
UPDATE public.foods SET protein_per_100g=7.0,  fat_per_100g=12.0, calories_per_100g=310,  fiber_per_100g=1.0,  source='usda' WHERE name='Waffle';

-- ══════════════════════════════════════════════════════════════
-- İÇECEKLER
-- ══════════════════════════════════════════════════════════════
UPDATE public.foods SET protein_per_100g=0.0,  fat_per_100g=0.0,  calories_per_100g=42,   fiber_per_100g=0.0,  source='usda' WHERE name='Gazlı İçecek (Kola)';
UPDATE public.foods SET protein_per_100g=0.7,  fat_per_100g=0.1,  calories_per_100g=45,   fiber_per_100g=0.2,  source='usda' WHERE name='Meyve Suyu (Paket)';

-- ══════════════════════════════════════════════════════════════
-- DOĞRULAMA — Kaç besin güncellendi?
-- ══════════════════════════════════════════════════════════════
SELECT
  COUNT(*) FILTER (WHERE source = 'usda')  AS usda_guncellenen,
  COUNT(*) FILTER (WHERE source = 'manual') AS manuel_kalan,
  COUNT(*)                                   AS toplam
FROM public.foods;
