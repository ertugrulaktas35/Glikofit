// ── Türkçe → İngilizce Besin Adı Çevirisi ────────────────────
// FatSecret API İngilizce ile en iyi sonuç veriyor.
const TR_TO_EN: Record<string, string> = {
  // Sebzeler
  'Brokoli': 'Broccoli', 'Ispanak': 'Spinach', 'Domates': 'Tomato',
  'Salatalık': 'Cucumber', 'Karnabahar': 'Cauliflower', 'Kabak': 'Zucchini',
  'Havuç': 'Carrot', 'Biber': 'Bell pepper', 'Patlıcan': 'Eggplant',
  'Soğan': 'Onion', 'Sarımsak': 'Garlic', 'Kereviz': 'Celery',
  'Marul': 'Lettuce', 'Lahana': 'Cabbage', 'Enginar': 'Artichoke',
  'Kuşkonmaz': 'Asparagus', 'Mantar': 'Mushroom', 'Pancar': 'Beet',
  'Turp': 'Radish', 'Balkabağı': 'Pumpkin', 'Patates (Haşlama)': 'Boiled potato',
  'Tatlı Patates': 'Sweet potato', 'Patates (Kızartma)': 'French fries',
  // Meyveler
  'Elma': 'Apple', 'Armut': 'Pear', 'Portakal': 'Orange',
  'Çilek': 'Strawberry', 'Kiraz': 'Cherry', 'Erik': 'Plum',
  'Greyfurt': 'Grapefruit', 'Muz': 'Banana', 'Üzüm': 'Grapes',
  'Kayısı': 'Apricot', 'Ananas': 'Pineapple', 'Kivi': 'Kiwi',
  'Mango': 'Mango', 'Karpuz': 'Watermelon', 'Kavun': 'Cantaloupe',
  'Hurma': 'Dates', 'Nar': 'Pomegranate', 'Mandalina': 'Mandarin orange',
  'İncir (Taze)': 'Fresh fig', 'Kuru Üzüm': 'Raisins',
  'Kayısı (Taze)': 'Fresh apricot', 'Gün Kurusu Kayısı': 'Dried apricot',
  // Tahıllar
  'Yulaf Ezmesi': 'Oatmeal', 'Tam Buğday Ekmek': 'Whole wheat bread',
  'Bulgur': 'Bulgur wheat', 'Esmer Pirinç': 'Brown rice',
  'Tam Buğday Makarna': 'Whole wheat pasta', 'Beyaz Ekmek': 'White bread',
  'Beyaz Pirinç': 'White rice', 'Baget Ekmek': 'Baguette',
  'Mısır Gevreği': 'Corn flakes', 'Pirinç Patlağı': 'Rice cakes',
  'Müsli': 'Muesli', 'Çavdar Ekmek': 'Rye bread', 'Pilav': 'Rice pilaf',
  'Simit': 'Turkish bagel', 'Beyaz Makarna': 'White pasta',
  'Basmati Pirinç': 'Basmati rice', 'Kinoa': 'Quinoa',
  // Bakliyat
  'Yeşil Mercimek': 'Green lentils', 'Kırmızı Mercimek': 'Red lentils',
  'Nohut': 'Chickpeas', 'Kuru Fasulye': 'White beans', 'Bezelye': 'Peas',
  'Barbunya': 'Pinto beans', 'Siyah Fasulye': 'Black beans',
  // Kuruyemiş
  'Ceviz': 'Walnuts', 'Badem': 'Almonds', 'Fındık': 'Hazelnuts',
  'Kavrulmuş Fındık': 'Roasted hazelnuts', 'Çiğ Badem': 'Raw almonds',
  'Tuzlu Yer Fıstığı': 'Salted peanuts', 'Antep Fıstığı': 'Pistachios',
  'Kabak Çekirdeği': 'Pumpkin seeds', 'Ay Çekirdeği': 'Sunflower seeds',
  'Sarı Leblebi': 'Roasted chickpeas', 'Beyaz Leblebi': 'White roasted chickpeas',
  'Kaju': 'Cashews',
  // Süt ürünleri
  'Yoğurt (Sade)': 'Plain yogurt', 'Süt (Tam Yağlı)': 'Whole milk',
  'Peynir (Beyaz)': 'White cheese', 'Süt (Yarım Yağlı)': 'Low fat milk',
  'Süt (Yağsız)': 'Skim milk', 'Süzme Yoğurt': 'Strained yogurt',
  'Meyveli Yoğurt': 'Fruit yogurt', 'Kaşar Peyniri': 'Yellow cheese',
  'Eski Kaşar': 'Aged yellow cheese', 'Tulum Peyniri': 'Tulum cheese',
  'Ezine Peyniri': 'Feta cheese', 'Lor Peyniri': 'Ricotta cheese',
  'Çökelek': 'Cottage cheese', 'Kelle Peyniri': 'Sheep head cheese',
  'Mihaliç Peyniri': 'Hard cheese', 'Çeçil Peyniri': 'String cheese',
  'Tel Peynir': 'String cheese', 'Örgü Peyniri': 'Braided cheese',
  'Gravyer Peyniri': 'Gruyere cheese', 'Labne Peyniri': 'Labneh',
  'Krem Peynir': 'Cream cheese', 'Dil Peyniri': 'Kaseri cheese',
  'Hellim Peyniri (Çiğ)': 'Halloumi cheese raw',
  'Tuzlu Yoğurt': 'Salted yogurt', 'Çiğ Süt': 'Raw milk',
  'Süt Tozu': 'Milk powder', 'Kaymak': 'Clotted cream',
  'Krem Şanti (Hazır)': 'Whipped cream',
  'Ayran': 'Ayran yogurt drink', 'Kefir': 'Kefir',
  // Protein
  'Yumurta': 'Egg', 'Tavuk Göğsü': 'Chicken breast',
  'Balık (Somon)': 'Salmon fish', 'Dana Kıyma': 'Ground beef',
  'Kuzu Eti': 'Lamb meat', 'Hindi Göğsü': 'Turkey breast',
  'Ton Balığı (Konserve)': 'Canned tuna', 'Yengeç Surimi': 'Crab surimi',
  'Sucuk': 'Turkish sausage', 'Sosis': 'Sausage', 'Salam': 'Salami',
  'Pastırma': 'Pastrami', 'Füme Hindi': 'Smoked turkey', 'Dana Kavurma': 'Beef kavurma',
  // Yağlar
  'Zeytinyağı': 'Olive oil', 'Tereyağı': 'Butter',
  'Ayçiçek Yağı': 'Sunflower oil', 'Mısır Özü Yağı': 'Corn oil',
  'Kanola Yağı': 'Canola oil', 'Fındık Yağı': 'Hazelnut oil',
  'Margarin': 'Margarine', 'Kuyruk Yağı': 'Tail fat',
  'Hindistan Cevizi Yağı': 'Coconut oil', 'Susam Yağı': 'Sesame oil',
  'Keten Tohumu Yağı': 'Flaxseed oil',
  // Tatlandırıcılar
  'Bal': 'Honey', 'Beyaz Şeker': 'White sugar',
  'Esmer Şeker': 'Brown sugar', 'Pekmez': 'Grape molasses',
  // Atıştırmalıklar
  'Patates Cipsi': 'Potato chips', 'Çikolatalı Gofret': 'Chocolate wafer',
  'Bisküvi': 'Biscuit cookies', 'Çikolata (Sütlü)': 'Milk chocolate',
  'Çikolata (Bitter)': 'Dark chocolate', 'Lokum': 'Turkish delight',
  'Helva': 'Halva sesame', 'Tahin': 'Tahini',
  // Hamur işleri
  'Poğaça': 'Turkish pastry roll', 'Börek': 'Turkish borek pastry',
  'Pide': 'Turkish pide bread', 'Waffle': 'Waffle',
  'Sade Poğaça': 'Plain pastry roll', 'Zeytinli Poğaça': 'Olive pastry',
  'Kaşarlı Poğaça': 'Cheese pastry', 'Dereotlu Poğaça': 'Dill pastry',
  'Avcı Böreği': 'Turkish hunter pastry', 'İçli Börek (Peynirli)': 'Cheese borek',
  'Puf Böreği': 'Puff pastry borek', 'Kürt Böreği': 'Kurdish borek',
  'Karaköy Poğacası': 'Karakoy pastry', 'Alman Pastası': 'German cake',
  'Ay Çöreği': 'Crescent roll', 'Tahinli Çörek': 'Tahini roll',
  'Halka Şekeri': 'Ring cookie', 'Kandil Simidi': 'Kandil bagel',
  'Macun Şekeri': 'Hard candy',
  // İçecekler
  'Gazlı İçecek (Kola)': 'Cola soft drink', 'Meyve Suyu (Paket)': 'Packaged fruit juice',
  'Çay (Şekersiz)': 'Tea unsweetened', 'Çay (Şekerli)': 'Tea sweetened',
  'Türk Kahvesi (Sade)': 'Turkish coffee plain', 'Türk Kahvesi (Şekerli)': 'Turkish coffee sweet',
  'Filtre Kahve (Sade)': 'Filter coffee black', 'Limonata': 'Lemonade',
  'Maden Suyu (Sade)': 'Sparkling water', 'Şalgam Suyu': 'Turnip juice',
  'Soğuk Çay (Şeftali)': 'Peach ice tea', 'Soya Sütü (Şekersiz)': 'Soy milk unsweetened',
  'Badem Sütü (Şekersiz)': 'Almond milk unsweetened', 'Yulaf Sütü': 'Oat milk',
  'Enerji İçeceği': 'Energy drink', 'Meyveli Soda': 'Fruit soda',
  'Hardaliye': 'Grape drink', 'Reyhan Şerbeti': 'Basil sherbet',
  'Nane Limon (Şekersiz)': 'Mint lemon drink', 'Ihlamur (Şekersiz)': 'Linden tea',
  'Kuşburnu Çayı (Şekersiz)': 'Rosehip tea', 'Adaçayı (Şekersiz)': 'Sage tea',
  'Kızılcık Şerbeti': 'Cranberry sherbet', 'Demirhindi Şerbeti': 'Tamarind sherbet',
  'Karadut Şurubu': 'Blackberry syrup',
};

function translateToEn(name: string): string {
  // Tam eşleşme
  if (TR_TO_EN[name]) return TR_TO_EN[name];
  // Parantez içi kaldırarak ara
  const clean = name.replace(/\s*\(.*?\)/g, '').trim();
  if (TR_TO_EN[clean]) return TR_TO_EN[clean];
  // Olduğu gibi dene (zaten İngilizce olabilir)
  return name;
}

async function searchFatSecret(query: string): Promise<any> {
  const token = await getToken();
  // region/language parametresi olmadan İngilizce arama
  const url = `https://platform.fatsecret.com/rest/server.api?method=foods.search&search_expression=${encodeURIComponent(query)}&format=json&max_results=3`;
  const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });

  return res.json();
}

async function getFoodDetail(foodId: string): Promise<any> {
  const token = await getToken();
  const url = `https://platform.fatsecret.com/rest/server.api?method=food.get.v2&food_id=${foodId}&format=json`;
  const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
  return res.json();
}

function normalize100g(serving: any): Record<string, number> {
  const n = (k: string) => parseFloat(serving?.[k] ?? '0') || 0;
  const amt = parseFloat(serving?.metric_serving_amount ?? '100') || 100;
  const f = 100 / amt;
  return {
    calories_per_100g: Math.round(n('calories') * f * 10) / 10,
    protein_per_100g: Math.round(n('protein') * f * 10) / 10,
    fat_per_100g: Math.round(n('fat') * f * 10) / 10,
    fiber_per_100g: Math.round(n('fiber') * f * 10) / 10,
    sodium_mg: Math.round(n('sodium') * f),
    potassium_mg: Math.round(n('potassium') * f),
    vitamin_c_mg: Math.round(n('vitamin_c') * f * 10) / 10,
    iron_mg: Math.round(n('iron') * f * 10) / 10,
    cholesterol_mg: Math.round(n('cholesterol') * f),
    saturated_fat_g: Math.round(n('saturated_fat') * f * 10) / 10,
    sugar_g: Math.round(n('sugar') * f * 10) / 10,
  };
}

serve(async (req: Request) => {
  const cors = handleCors(req);
  if (cors) return cors;

  // ── Admin Şifre Kontrolü ──────────────────────────────────
  // Body'den gizli şifreyi kontrol et
  let body: any = {};
  try {
    body = await req.json();
  } catch {
    // body boş ise devam et
  }

  const ADMIN_SECRET = Deno.env.get('POPULATE_SECRET') ?? 'glikofit-admin-2024';
  if (body?.secret !== ADMIN_SECRET) {
    return new Response(
      JSON.stringify({ error: 'Yetkisiz: secret gerekli' }),
      { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
    );
  }

  // Service Role client — DB yazma yetkisi için
  const supabaseAdmin = createClient(
    Deno.env.get('SUPABASE_URL')!,
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
  );

  // Manuel kayıtları al
  const { data: foods, error } = await supabaseAdmin
    .from('foods')
    .select('id, name')
    .eq('source', 'manual');

  if (error || !foods) {
    return new Response(JSON.stringify({ error: 'Besinler alınamadı' }), { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
  }

  const results: { name: string; status: string; food_id?: string }[] = [];

  for (const food of foods) {
    try {
      // FatSecret'ta ara
      const searchData = await searchFatSecret(food.name);
      const list = searchData?.foods?.food ?? [];
      const arr = Array.isArray(list) ? list : [list];

      if (arr.length === 0 || !arr[0]) {
        results.push({ name: food.name, status: 'not_found' });
        continue;
      }

      const bestFsId = arr[0].food_id;

      // Detay çek
      const detailData = await getFoodDetail(bestFsId);
      const f = detailData?.food;
      if (!f) { results.push({ name: food.name, status: 'detail_failed' }); continue; }

      const servings = f.servings?.serving;
      const arr2 = Array.isArray(servings) ? servings : [servings];
      const s100 = arr2.find((s: any) => s?.metric_serving_amount === '100.000') ?? arr2.find((s: any) => s?.metric_serving_amount) ?? arr2[0];

      const macros = normalize100g(s100);

      await supabaseAdmin.from('foods').update({
        ...macros,
        fatsecret_id: String(bestFsId),
        serving_description: s100?.serving_description,
        source: 'fatsecret',
      }).eq('id', food.id);

      results.push({ name: food.name, status: 'updated', food_id: String(bestFsId) });

      // Rate limit
      await new Promise((r) => setTimeout(r, 400));
    } catch (err: any) {
      results.push({ name: food.name, status: `error: ${err.message}` });
    }
  }

  const updated = results.filter((r) => r.status === 'updated').length;
  const failed = results.filter((r) => r.status !== 'updated').length;

  return new Response(
    JSON.stringify({ summary: { total: foods.length, updated, failed }, details: results }),
    { headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
  );
});
