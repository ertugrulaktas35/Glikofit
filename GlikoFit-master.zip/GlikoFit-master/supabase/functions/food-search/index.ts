// supabase/functions/food-search/index.ts
// ============================================================
// 🔍 Besin Arama — Edge Function
// ============================================================
// FatSecret API key'lerini güvenli tutar.
// İstemci bu fonksiyon üzerinden besin araması yapar.
// ============================================================

import { serve } from 'https://deno.land/std@0.177.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { corsHeaders, handleCors } from '../_shared/cors.ts';

const FATSECRET_CLIENT_ID = Deno.env.get('FATSECRET_CLIENT_ID')!;
const FATSECRET_CLIENT_SECRET = Deno.env.get('FATSECRET_CLIENT_SECRET')!;

// ── FatSecret Token Cache ────────────────────────────────────

let cachedToken: string | null = null;
let tokenExpiration = 0;

async function getFatSecretToken(): Promise<string> {
  if (cachedToken && Date.now() < tokenExpiration) {
    return cachedToken;
  }

  const credentials = btoa(`${FATSECRET_CLIENT_ID}:${FATSECRET_CLIENT_SECRET}`);

  const response = await fetch('https://oauth.fatsecret.com/connect/token', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
      Authorization: `Basic ${credentials}`,
    },
    body: 'grant_type=client_credentials&scope=basic',
  });

  if (!response.ok) {
    throw new Error('FatSecret token alınamadı');
  }

  const data = await response.json();
  cachedToken = data.access_token;
  tokenExpiration = Date.now() + data.expires_in * 1000 - 60000;

  return cachedToken!;
}

// ── Ana Handler ──────────────────────────────────────────────

serve(async (req: Request) => {
  const corsResponse = handleCors(req);
  if (corsResponse) return corsResponse;

  try {
    // Auth doğrulama
    const authHeader = req.headers.get('Authorization')!;
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_ANON_KEY')!,
      { global: { headers: { Authorization: authHeader } } },
    );
    const { data: { user }, error: authError } = await supabase.auth.getUser();

    if (authError || !user) {
      return new Response(
        JSON.stringify({ error: 'Yetkisiz erişim' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
      );
    }

    const { query, max_results = 5 } = await req.json();

    if (!query || typeof query !== 'string') {
      return new Response(
        JSON.stringify({ error: 'query parametresi gerekli' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
      );
    }

    // FatSecret API arama
    const token = await getFatSecretToken();
    const searchUrl = `https://platform.fatsecret.com/rest/server.api?method=foods.search&search_expression=${encodeURIComponent(query)}&format=json&region=TR&language=tr&max_results=${max_results}`;

    const res = await fetch(searchUrl, {
      headers: { Authorization: `Bearer ${token}` },
    });

    if (!res.ok) {
      throw new Error('FatSecret API isteği başarısız');
    }

    const data = await res.json();
    const foodList = data?.foods?.food;
    if (!foodList) {
      return new Response(JSON.stringify({ results: [] }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const foodsArray = Array.isArray(foodList) ? foodList : [foodList];

    // Her besin için detay çek + yerel DB ile GI zenginleştirme
    const results = [];

    for (const f of foodsArray) {
      let carbs = 0;
      let protein = 0;
      let fat = 0;
      let calories = 0;

      // food_description parse
      if (f.food_description) {
        const carbMatch = f.food_description.match(/Carbs:\s*([\d.]+)g/);
        const protMatch = f.food_description.match(/Prot:\s*([\d.]+)g/);
        const fatMatch = f.food_description.match(/Fat:\s*([\d.]+)g/);
        const calMatch = f.food_description.match(/Calories:\s*([\d.]+)/);

        if (carbMatch) carbs = parseFloat(carbMatch[1]);
        if (protMatch) protein = parseFloat(protMatch[1]);
        if (fatMatch) fat = parseFloat(fatMatch[1]);
        if (calMatch) calories = parseFloat(calMatch[1]);
      }

      // Yerel DB'den GI ara
      let giValue: number | null = null;
      let giSource: string = 'estimated';

      const { data: localFood } = await supabase.rpc('fuzzy_food_search', {
        search_term: f.food_name,
        similarity_threshold: 0.3,
        max_results: 1,
      });

      if (localFood?.[0]) {
        giValue = localFood[0].gi_value;
        giSource = 'local_db';
        // DB verisi varsa makroları güncelle
        if (localFood[0].carbs_per_100g > 0) {
          carbs = localFood[0].carbs_per_100g;
        }
      } else {
        // GI tahmini: estimate_gi_from_macros fonksiyonu
        const { data: giEstimate } = await supabase.rpc('estimate_gi_from_macros', {
          carbs,
          fiber: 0,
          fat,
          protein,
        });
        giValue = giEstimate ?? 50;
        giSource = 'macro_estimate';
      }

      results.push({
        food_id: f.food_id,
        food_name: f.food_name,
        carbs_per_100g: carbs,
        protein_per_100g: protein,
        fat_per_100g: fat,
        calories_per_100g: calories,
        gi_value: giValue,
        gi_source: giSource,
        color_code:
          giValue !== null && giValue <= 55 ? 'GREEN'
          : giValue !== null && giValue <= 69 ? 'YELLOW'
          : 'RED',
      });
    }

    return new Response(JSON.stringify({ results }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (err: any) {
    console.error('food-search error:', err);
    return new Response(
      JSON.stringify({ error: err.message || 'Arama hatası' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
    );
  }
});
