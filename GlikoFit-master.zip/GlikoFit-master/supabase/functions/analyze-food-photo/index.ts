// supabase/functions/analyze-food-photo/index.ts
// ============================================================
// 📸 Fotoğraftan Besin Analizi — Edge Function
// ============================================================
// Gemini Vision API ile tabak fotoğrafını analiz eder.
// API key'ler server-side'da güvenli tutulur.
// ============================================================

import { serve } from 'https://deno.land/std@0.177.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { corsHeaders, handleCors } from '../_shared/cors.ts';

const GEMINI_API_KEY = Deno.env.get('GEMINI_API_KEY')!;

const ANALYZE_PROMPT = `
Bu tabak fotoğrafını analiz et. Her yiyeceği tanı ve tahmini porsiyon miktarını gram cinsinden belirt.

Her yiyecek için şu değerleri hesapla (100g bazında):
- Kalori (kcal)
- Karbonhidrat (g)
- Protein (g)
- Yağ (g)
- Lif (g)
- Tahmini Glisemik İndeks (GI)

Yanıt olarak SADECE JSON döndür, başka metin yazma:
{
  "items": [
    {
      "name": "Besin adı (Türkçe)",
      "estimated_grams": 150,
      "confidence": 0.92,
      "macros": {
        "calories": 195,
        "carbs": 42,
        "protein": 3.5,
        "fat": 0.5,
        "fiber": 0.4
      },
      "gi_value": 73
    }
  ]
}
`;

serve(async (req: Request) => {
  // CORS
  const corsResponse = handleCors(req);
  if (corsResponse) return corsResponse;

  const startTime = Date.now();

  try {
    // 1. Auth doğrulama
    const authHeader = req.headers.get('Authorization')!;
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_ANON_KEY')!,
      { global: { headers: { Authorization: authHeader } } },
    );
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser();

    if (authError || !user) {
      return new Response(
        JSON.stringify({ error: 'Yetkisiz erişim' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
      );
    }

    // 2. Body parse
    const { image_base64 } = await req.json();
    if (!image_base64) {
      return new Response(
        JSON.stringify({ error: 'image_base64 gerekli' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
      );
    }

    // 3. Fotoğrafı Storage'a yükle
    const imagePath = `food-photos/${user.id}/${Date.now()}.jpg`;
    const imageBuffer = Uint8Array.from(atob(image_base64), (c) => c.charCodeAt(0));

    await supabase.storage
      .from('photos')
      .upload(imagePath, imageBuffer, { contentType: 'image/jpeg' });

    // 4. Gemini Vision API
    const geminiRes = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${GEMINI_API_KEY}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [
            {
              parts: [
                { text: ANALYZE_PROMPT },
                { inlineData: { mimeType: 'image/jpeg', data: image_base64 } },
              ],
            },
          ],
          generationConfig: { temperature: 0.2 },
        }),
      },
    );

    const geminiData = await geminiRes.json();
    const rawText = geminiData?.candidates?.[0]?.content?.parts?.[0]?.text;

    if (!rawText) {
      throw new Error('Gemini yanıt döndürmedi');
    }

    // 5. JSON parse
    const jsonStart = rawText.indexOf('{');
    const jsonEnd = rawText.lastIndexOf('}');
    const cleanJson = rawText.substring(jsonStart, jsonEnd + 1);
    const parsed = JSON.parse(cleanJson);

    const detectedItems = (parsed.items || []).map((item: any) => ({
      name: item.name || 'Bilinmeyen',
      estimated_grams: item.estimated_grams || 100,
      confidence: item.confidence || 0.5,
      macros: {
        calories: item.macros?.calories || 0,
        carbs: item.macros?.carbs || 0,
        protein: item.macros?.protein || 0,
        fat: item.macros?.fat || 0,
        fiber: item.macros?.fiber || 0,
      },
      gi_value: item.gi_value || null,
      gi_source: 'estimated',
    }));

    // 6. GI Zenginleştirme
    for (const item of detectedItems) {
      const { data: localFood } = await supabase.rpc('fuzzy_food_search', {
        search_term: item.name,
        similarity_threshold: 0.3,
        max_results: 1,
      });

      if (localFood?.[0]) {
        item.gi_value = localFood[0].gi_value;
        item.gi_source = 'local_db';
        item.macros.carbs = localFood[0].carbs_per_100g ?? item.macros.carbs;
        item.macros.protein = localFood[0].protein_per_100g ?? item.macros.protein;
        item.macros.fat = localFood[0].fat_per_100g ?? item.macros.fat;
        item.macros.calories = localFood[0].calories_per_100g ?? item.macros.calories;
      }
    }

    // 7. Toplamları hesapla
    let totalCalories = 0;
    let totalCarbs = 0;
    let totalProtein = 0;
    let totalFat = 0;
    let totalGiLoad = 0;

    for (const item of detectedItems) {
      const factor = item.estimated_grams / 100;
      totalCalories += item.macros.calories * factor;
      totalCarbs += item.macros.carbs * factor;
      totalProtein += item.macros.protein * factor;
      totalFat += item.macros.fat * factor;
      if (item.gi_value) {
        totalGiLoad += (item.gi_value * item.macros.carbs * factor) / 100;
      }
    }

    // 8. DB'ye kaydet
    const processingTime = Date.now() - startTime;

    const { data: analysis, error: insertError } = await supabase
      .from('photo_analyses')
      .insert({
        user_id: user.id,
        image_url: imagePath,
        detected_items: detectedItems,
        total_calories: Math.round(totalCalories),
        total_carbs: Math.round(totalCarbs * 10) / 10,
        total_protein: Math.round(totalProtein * 10) / 10,
        total_fat: Math.round(totalFat * 10) / 10,
        total_gi_load: Math.round(totalGiLoad * 10) / 10,
        processing_time_ms: processingTime,
        status: 'completed',
      })
      .select()
      .single();

    if (insertError) {
      throw insertError;
    }

    return new Response(JSON.stringify(analysis), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (err: any) {
    console.error('analyze-food-photo error:', err);
    return new Response(
      JSON.stringify({ error: err.message || 'Analiz hatası' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
    );
  }
});
