// supabase/functions/smart-coach/index.ts
// ============================================================
// 🧠 Akıllı Koç — Edge Function
// ============================================================
// Gemini API key'i güvenli tutar. İstemci bu fonksiyon
// üzerinden AI koç tavsiyesi alır.
// ============================================================

import { serve } from 'https://deno.land/std@0.177.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { corsHeaders, handleCors } from '../_shared/cors.ts';

const GEMINI_API_KEY = Deno.env.get('GEMINI_API_KEY')!;
const API_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${GEMINI_API_KEY}`;

serve(async (req: Request) => {
  const corsResponse = handleCors(req);
  if (corsResponse) return corsResponse;

  try {
    // Auth doğrulama
    const authHeader = req.headers.get('Authorization')!;
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_ANON_KEY')!,
      { global: { headers: { Authorization: authHeader } } },
    );
    const { data: { user }, error: authError } = await supabase.auth.getUser();

    if (authError || !user) {
      return new Response(
        JSON.stringify({ error: 'Yetkisiz erişim' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
      );
    }

    // Body: food bilgisi + porsiyon + profil
    const { food, portion, userProfile } = await req.json();

    if (!food || !portion) {
      return new Response(
        JSON.stringify({ error: 'food ve portion gerekli' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
      );
    }

    // Kişisel bağlam oluştur
    let personalContext = '';
    if (userProfile) {
      const bmi = userProfile.weight_kg / Math.pow(userProfile.height_cm / 100, 2);
      const age = new Date().getFullYear() - userProfile.birth_year;

      personalContext = `
KULLANICININ KİŞİSEL PROFİLİ:
- Yaş: ${age}, Cinsiyet: ${userProfile.gender === 'erkek' ? 'Erkek' : 'Kadın'}
- Boy: ${userProfile.height_cm}cm, Kilo: ${userProfile.weight_kg}kg
- VKİ: ${bmi.toFixed(1)}
- Diyabet Durumu: ${userProfile.diabetes_type}
${userProfile.hba1c ? `- Son HbA1c: %${userProfile.hba1c}` : ''}
${userProfile.fasting_glucose ? `- Açlık Kan Şekeri: ${userProfile.fasting_glucose} mg/dL` : ''}
- Aktivite: ${userProfile.activity_level}

Bu kişinin durumuna ÖZEL tavsiye ver.
`;
    }

    const prompt = `
Sen "GlikoFit" uygulamasının uzman diyetisyeni ve kişisel koçusun. Sıcakkanlı, empatik ve bilgi dolu bir yaklaşımın var.
${personalContext}
Kullanıcı şu yiyeceği kaydetti:
- Besin: ${food.name}
- Kategori: ${food.category}
- Glisemik İndeks: ${food.gi_value}
- 100g Karbonhidrat: ${food.carbs_per_100g}g
- Yenilen Porsiyon: ${portion} gram

GÖREV: Bu besini hayatından çıkarmasını söyleme. Kan şekerini akıllıca dengeleyebileceği çok spesifik, kişiye özel ve kısa bir tavsiye ver (en fazla 2-3 cümle). Yanına ekleyebileceği dengeleyici bir besin öner.

JSON formatında hiçbir dış metin bırakmadan SADECE şu yapıyı döndür:
{
  "high_risk_category": "${food.category}",
  "balancer_category": "Örn: Ceviz, Ayran, Yoğurt",
  "advice_text": "Kişiye özel, empatik ve pratik tavsiye metni."
}
`;

    // Gemini API çağrısı
    const response = await fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: { temperature: 0.7 },
      }),
    });

    const data = await response.json();
    const rawText = data?.candidates?.[0]?.content?.parts?.[0]?.text;

    if (!rawText) {
      return new Response(
        JSON.stringify({ error: 'Gemini yanıt döndürmedi' }),
        { status: 502, headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
      );
    }

    const jsonStart = rawText.indexOf('{');
    const jsonEnd = rawText.lastIndexOf('}');
    const cleanJson = rawText.substring(jsonStart, jsonEnd + 1);
    const parsed = JSON.parse(cleanJson);

    const result = {
      id: Math.floor(Math.random() * 100000),
      high_risk_category: parsed.high_risk_category || food.category,
      balancer_category: parsed.balancer_category || 'Protein/Yağ',
      advice_text: parsed.advice_text || 'Bu porsiyonun yanına protein veya sağlıklı yağ eklemeyi unutma.',
      created_at: new Date().toISOString(),
    };

    return new Response(JSON.stringify(result), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (err: any) {
    console.error('smart-coach error:', err);
    return new Response(
      JSON.stringify({ error: err.message || 'Koç hatası' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
    );
  }
});
