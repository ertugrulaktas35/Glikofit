// ============================================================
// 🧠 Duygu Durumu — Kan Şekeri Korelasyon Analizi
// ============================================================
// Mood kayıtları ile öğün verileri arasındaki zamanlama ve
// değer korelasyonlarını tespit eder.
// ============================================================

import type { MoodLog, ConsumptionLogWithFood } from '../types/database';

// ── Sonuç Tipleri ────────────────────────────────────────────

export type InsightPattern =
  | 'stress_spike'    // Yüksek stres + Yüksek GI
  | 'mood_dip'        // Düşük mod + Yüksek GL
  | 'energy_crash'    // Yüksek GL sonrası enerji düşüşü
  | 'balanced';       // İyi denge

export interface MoodGlucoseInsight {
  pattern: InsightPattern;
  description: string;
  recommendation: string;
  confidence: number;          // 0-1
  relatedMealNames: string[];
  moodEntry: MoodLog;
}

// ── Kortizol-GI Risk Skoru ───────────────────────────────────

/**
 * Stres seviyesi ve GI değerinden bileşik risk skoru hesaplar.
 * Yüksek stres + Yüksek GI = Yüksek kortizol + glukoz tepkisi riski.
 *
 * @returns 0-10 arası risk skoru
 */
export function calculateCortisolRiskScore(
  stressLevel: number,     // 1-10
  giValue: number,          // 0-100
): number {
  const normalizedStress = stressLevel / 10;  // 0-1
  const normalizedGI = giValue / 100;          // 0-1

  // Ağırlıklı ortalama: %40 stres, %60 GI
  const rawScore = normalizedStress * 0.4 + normalizedGI * 0.6;

  return Math.round(rawScore * 100) / 10; // 0-10 arası, 1 ondalık
}

// ── Ana Analiz Fonksiyonu ────────────────────────────────────

/**
 * Mood kayıtlarını consumption_logs ile zamanlama bazlı eşleştirip
 * anlamlı pattern'lar çıkarır.
 *
 * @param moodEntries - Kullanıcının mood kayıtları
 * @param consumptionEntries - Öğün kayıtları (food ile join'li)
 * @param timeWindowMinutes - Zaman penceresi (varsayılan 120dk = 2 saat)
 */
export function analyzeMoodGlucosePattern(
  moodEntries: MoodLog[],
  consumptionEntries: ConsumptionLogWithFood[],
  timeWindowMinutes: number = 120,
): MoodGlucoseInsight[] {
  const insights: MoodGlucoseInsight[] = [];

  for (const mood of moodEntries) {
    const moodTime = new Date(mood.recorded_at).getTime();

    //  Mood kaydından önceki timeWindowMinutes içindeki öğünleri bul
    const relatedMeals = consumptionEntries.filter((cl) => {
      const mealTime = new Date(cl.consumed_at).getTime();
      const diffMs = moodTime - mealTime;
      return diffMs > 0 && diffMs <= timeWindowMinutes * 60 * 1000;
    });

    if (relatedMeals.length === 0) continue;

    const avgGI =
      relatedMeals.reduce((sum, m) => sum + m.food.gi_value, 0) /
      relatedMeals.length;
    const totalGL = relatedMeals.reduce((sum, m) => sum + m.calculated_gl, 0);
    const mealNames = relatedMeals.map((m) => m.food.name);

    // ── Pattern: Stres Spike ──────────────────────────────
    if (
      mood.stress_level !== null &&
      mood.stress_level >= 7 &&
      avgGI >= 70
    ) {
      insights.push({
        pattern: 'stress_spike',
        description: `Yüksek stres (${mood.stress_level}/10) + Yüksek GI (${Math.round(avgGI)}) tespit edildi`,
        recommendation:
          'Stresli dönemlerde düşük GI besinleri tercih et. Kortizol zaten kan şekerini yükseltiyor.',
        confidence: 0.85,
        relatedMealNames: mealNames,
        moodEntry: mood,
      });
    }

    // ── Pattern: Enerji Düşüşü ────────────────────────────
    if (
      mood.energy_level !== null &&
      mood.energy_level <= 3 &&
      totalGL >= 20
    ) {
      insights.push({
        pattern: 'energy_crash',
        description: `Yüksek GL (${Math.round(totalGL)}) öğün sonrası enerji düşüşü (${mood.energy_level}/10)`,
        recommendation:
          'Yüksek karbonhidratlı öğünlerin ardından 15dk yürüyüş yap. Bu insülin duyarlılığını artırır.',
        confidence: 0.78,
        relatedMealNames: mealNames,
        moodEntry: mood,
      });
    }

    // ── Pattern: Mood Dip ─────────────────────────────────
    if (mood.mood_score <= 3 && totalGL >= 15) {
      insights.push({
        pattern: 'mood_dip',
        description: `Düşük ruh hali (${mood.mood_score}/10) yüksek GL (${Math.round(totalGL)}) öğün sonrasında`,
        recommendation:
          'Kan şekeri dalgalanmaları ruh halini etkiler. Protein + lif ağırlıklı öğünler daha stabil enerji sağlar.',
        confidence: 0.72,
        relatedMealNames: mealNames,
        moodEntry: mood,
      });
    }
  }

  return insights;
}

// ── Günlük Özet ──────────────────────────────────────────────

export interface DailyMoodSummary {
  avgMood: number;
  avgStress: number;
  avgEnergy: number;
  dominantTags: string[];
  entryCount: number;
}

/**
 * Belirli bir güne ait mood kayıtlarının özetini çıkarır.
 */
export function getDailyMoodSummary(entries: MoodLog[]): DailyMoodSummary {
  if (entries.length === 0) {
    return {
      avgMood: 0,
      avgStress: 0,
      avgEnergy: 0,
      dominantTags: [],
      entryCount: 0,
    };
  }

  const avgMood =
    entries.reduce((sum, e) => sum + e.mood_score, 0) / entries.length;
  const avgStress =
    entries.reduce((sum, e) => sum + (e.stress_level ?? 5), 0) / entries.length;
  const avgEnergy =
    entries.reduce((sum, e) => sum + (e.energy_level ?? 5), 0) / entries.length;

  // En sık kullanılan tag'leri bul
  const tagCounts: Record<string, number> = {};
  for (const entry of entries) {
    for (const tag of entry.mood_tags) {
      tagCounts[tag] = (tagCounts[tag] || 0) + 1;
    }
  }
  const dominantTags = Object.entries(tagCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 3)
    .map(([tag]) => tag);

  return {
    avgMood: Math.round(avgMood * 10) / 10,
    avgStress: Math.round(avgStress * 10) / 10,
    avgEnergy: Math.round(avgEnergy * 10) / 10,
    dominantTags,
    entryCount: entries.length,
  };
}

// ── Mood Tag Etiketleri ──────────────────────────────────────

export const MOOD_TAG_LABELS: Record<string, { label: string; emoji: string }> = {
  mutlu:       { label: 'Mutlu',        emoji: '😊' },
  kaygili:     { label: 'Kaygılı',      emoji: '😰' },
  stresli:     { label: 'Stresli',      emoji: '😤' },
  sakin:       { label: 'Sakin',        emoji: '😌' },
  sinirli:     { label: 'Sinirli',      emoji: '😡' },
  enerjik:     { label: 'Enerjik',      emoji: '⚡' },
  yorgun:      { label: 'Yorgun',       emoji: '😴' },
  odaklanmis:  { label: 'Odaklanmış',   emoji: '🎯' },
};
