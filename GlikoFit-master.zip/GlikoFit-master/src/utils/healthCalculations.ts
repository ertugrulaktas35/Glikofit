// ============================================================
// 🏥 Sağlık Hesaplamaları — BMI, Karbonhidrat Limiti, GL Eşikleri
// ============================================================

export type DiabetesType = 'tip1' | 'tip2' | 'prediyabet' | 'gestasyonel' | 'yok';
export type ActivityLevel = 'sedanter' | 'hafif_aktif' | 'aktif' | 'cok_aktif';
export type Gender = 'erkek' | 'kadin';

export interface UserHealthProfile {
  fullName: string;
  birthYear: number;
  gender: Gender;
  heightCm: number;
  weightKg: number;
  diabetesType: DiabetesType;
  hba1c: number | null;       // Son HbA1c yüzdesi (Ör: 6.5)
  fastingGlucose: number | null; // Açlık kan şekeri mg/dL
  activityLevel: ActivityLevel;
}

// ── BMI Hesaplaması ─────────────────────────────────────────

export function calculateBMI(weightKg: number, heightCm: number): number {
  if (heightCm <= 0 || weightKg <= 0) return 0;
  const heightM = heightCm / 100;
  return Math.round((weightKg / (heightM * heightM)) * 10) / 10;
}

export type BmiCategory = 'zayif' | 'normal' | 'fazla_kilolu' | 'obez';

export function getBmiCategory(bmi: number): { category: BmiCategory; label: string; color: string; emoji: string } {
  if (bmi < 18.5) return { category: 'zayif', label: 'Zayıf', color: '#3B82F6', emoji: '💙' };
  if (bmi < 25) return { category: 'normal', label: 'Normal', color: '#10B981', emoji: '💚' };
  if (bmi < 30) return { category: 'fazla_kilolu', label: 'Fazla Kilolu', color: '#F59E0B', emoji: '🟡' };
  return { category: 'obez', label: 'Obez', color: '#EF4444', emoji: '🔴' };
}

// ── Yaş Hesaplaması ─────────────────────────────────────────

export function calculateAge(birthYear: number): number {
  const currentYear = new Date().getFullYear();
  return currentYear - birthYear;
}

// ── Günlük Karbonhidrat Limiti ──────────────────────────────
/**
 * Diyabet tipi, BMI ve aktivite seviyesine göre
 * tahmini günlük karbonhidrat limiti (gram) hesaplar.
 *
 * Kaynaklar:
 * - ADA (American Diabetes Association) önerileri
 * - Dünya Sağlık Örgütü diyabet yönetim kılavuzları
 */
export function calculateDailyCarbLimit(profile: UserHealthProfile): number {
  const bmi = calculateBMI(profile.weightKg, profile.heightCm);

  // Bazal karbonhidrat miktarı (gram)
  let baseCarb = 200; // Sağlıklı yetişkin için varsayılan

  // Diyabet tipine göre azaltma
  switch (profile.diabetesType) {
    case 'tip1':
      baseCarb = 180;
      break;
    case 'tip2':
      baseCarb = 150;
      break;
    case 'prediyabet':
      baseCarb = 170;
      break;
    case 'gestasyonel':
      baseCarb = 160;
      break;
    case 'yok':
      baseCarb = 250;
      break;
  }

  // BMI düzeltmesi
  if (bmi >= 30) {
    baseCarb *= 0.80; // Obez — %20 azaltma
  } else if (bmi >= 25) {
    baseCarb *= 0.90; // Fazla kilolu — %10 azaltma
  } else if (bmi < 18.5) {
    baseCarb *= 1.10; // Zayıf — %10 artırma
  }

  // Aktivite seviyesi düzeltmesi
  switch (profile.activityLevel) {
    case 'sedanter':
      baseCarb *= 0.85;
      break;
    case 'hafif_aktif':
      baseCarb *= 0.95;
      break;
    case 'aktif':
      baseCarb *= 1.05;
      break;
    case 'cok_aktif':
      baseCarb *= 1.15;
      break;
  }

  // HbA1c yüksekse ek sıkılaştırma
  if (profile.hba1c && profile.hba1c > 7.0) {
    baseCarb *= 0.90; // %10 ek azaltma
  }

  return Math.round(baseCarb);
}

// ── Kişiselleştirilmiş GL Eşikleri ─────────────────────────
/**
 * Kişinin diyabet tipi ve HbA1c'sine göre GL eşiklerini sıkılaştırır.
 * Varsayılan: Yeşil ≤10, Sarı 10-20, Kırmızı ≥20
 * Tip 2 + yüksek HbA1c: Yeşil ≤7, Sarı 7-14, Kırmızı ≥14
 */
export function getPersonalizedGlThresholds(
  diabetesType: DiabetesType,
  hba1c: number | null
): { yellowThreshold: number; redThreshold: number } {
  let yellowThreshold = 10;
  let redThreshold = 20;

  switch (diabetesType) {
    case 'tip1':
      yellowThreshold = 8;
      redThreshold = 16;
      break;
    case 'tip2':
      yellowThreshold = 8;
      redThreshold = 15;
      break;
    case 'prediyabet':
      yellowThreshold = 9;
      redThreshold = 18;
      break;
    case 'gestasyonel':
      yellowThreshold = 7;
      redThreshold = 14;
      break;
    case 'yok':
      // Varsayılan eşikler
      break;
  }

  // HbA1c > 7.5 ise eşikleri daha da sıkılaştır
  if (hba1c && hba1c > 7.5) {
    yellowThreshold = Math.max(5, yellowThreshold - 2);
    redThreshold = Math.max(10, redThreshold - 3);
  }

  return { yellowThreshold, redThreshold };
}

// ── Besin Uygunluk Skoru ────────────────────────────────────
/**
 * Bir besinin kullanıcıya uygunluk durumunu belirler.
 * true = önerilir, false = dikkatli tüketilmeli
 */
export function isFoodRecommended(
  giValue: number,
  diabetesType: DiabetesType,
  hba1c: number | null,
): boolean {
  if (diabetesType === 'yok') return true;

  // GI < 55 genelde güvenli
  if (giValue <= 55) return true;

  // GI 55-69 arası — diyabet tipine göre
  if (giValue <= 69) {
    if (diabetesType === 'tip2' && hba1c && hba1c > 7.0) return false;
    if (diabetesType === 'gestasyonel') return false;
    return true;
  }

  // GI ≥ 70 — tüm diyabet tipleri için riskli
  return false;
}

// ── Diyabet Tip Etiketleri ──────────────────────────────────

export const DIABETES_TYPE_LABELS: Record<DiabetesType, string> = {
  tip1: 'Tip 1 Diyabet',
  tip2: 'Tip 2 Diyabet',
  prediyabet: 'Pre-diyabet',
  gestasyonel: 'Gestasyonel Diyabet',
  yok: 'Diyabet Yok',
};

export const ACTIVITY_LEVEL_LABELS: Record<ActivityLevel, string> = {
  sedanter: 'Sedanter (Masa başı)',
  hafif_aktif: 'Hafif Aktif',
  aktif: 'Aktif',
  cok_aktif: 'Çok Aktif (Sporcu)',
};

export const GENDER_LABELS: Record<Gender, string> = {
  erkek: 'Erkek',
  kadin: 'Kadın',
};
