const imageCache = new Map<string, string | null>();

export const getFoodImage = async (name: string): Promise<string | null> => {
  if (!name) return null;
  const lowerName = name.trim().toLowerCase();
  
  if (imageCache.has(lowerName)) {
    return imageCache.get(lowerName) || null;
  }
  
  try {
    const apiKey = process.env.EXPO_PUBLIC_PIXABAY_API_KEY;
    if (!apiKey) {
      console.warn("Pixabay API key is missing");
      return null;
    }
    
    // Pixabay endpoint
    const url = `https://pixabay.com/api/?key=${apiKey}&q=${encodeURIComponent(name)}&image_type=photo&category=food&lang=tr`;
    
    const response = await fetch(url);
    const data = await response.json();
    
    if (data.hits && data.hits.length > 0) {
      const imgUrl = data.hits[0].largeImageURL || data.hits[0].webformatURL;
      imageCache.set(lowerName, imgUrl);
      return imgUrl;
    }
    
    imageCache.set(lowerName, null);
    return null;
  } catch (error) {
    console.error("Error fetching image from Pixabay:", error);
    imageCache.set(lowerName, null);
    return null;
  }
};
