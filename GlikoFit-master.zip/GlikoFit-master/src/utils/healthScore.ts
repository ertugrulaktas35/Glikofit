// ============================================================
// 🏆 Sağlık Puanı (Health Score) Algoritması — GlikoFit v2
// ============================================================
// Beslenme, duygu durumu, uyku, hidrasyon ve kafein
// metriklerini birleştirerek günlük 0-100 arası skor üretir.
// ============================================================

import type { DiabetesType } from './healthCalculations';

// ── Metrik Girdileri ─────────────────────────────────────────

export interface DailyMetrics {
  // Beslenme (consumption_logs + foods)
  avgGI: number;              // 0-100
  totalGL: number;            // 0-∞
  carbRatio: number;          // Günlük karb limitine oran (0-2+)
  redFoodCount: number;       // Kırmızı besin sayısı
  greenFoodRatio: number;     // Yeşil besin yüzdesi (0-1)

  // Duygu durumu (mood_logs)
  avgMood: number;            // 1-10
  avgStress: number;          // 1-10
  avgEnergy: number;          // 1-10

  // Uyku (sleep_logs)
  sleepDurationMinutes: number;
  sleepQuality: number;       // 1-10

  // Su (water_logs)
  waterMl: number;
  waterTarget: number;        // weight_kg * 30

  // Kafein (caffeine_logs)
  caffeineMg: number;

  // Profil
  diabetesType: DiabetesType;
  bmi: number;
}

// ── Sonuç Yapısı ─────────────────────────────────────────────

export type HealthGrade = 'A' | 'B' | 'C' | 'D' | 'F';

export interface HealthScoreBreakdown {
  nutrition: number;          // 0-100, ağırlık: %40
  mood: number;               // 0-100, ağırlık: %15
  sleep: number;              // 0-100, ağırlık: %20
  hydration: number;          // 0-100, ağırlık: %15
  caffeine: number;           // 0-100, ağırlık: %10
}

export interface HealthScoreResult {
  totalScore: number;         // 0-100
  grade: HealthGrade;
  breakdown: HealthScoreBreakdown;
  insights: string[];         // Kısa iyileştirme önerileri
}

// ── Ağırlık Sabitleri ────────────────────────────────────────

const WEIGHTS = {
  nutrition: 0.40,
  mood:      0.15,
  sleep:     0.20,
  hydration: 0.15,
  caffeine:  0.10,
} as const;

// ── Yardımcı ─────────────────────────────────────────────────

function clamp(val: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, val));
}

// ── Grade Belirleme ──────────────────────────────────────────

export function getGrade(score: number): HealthGrade {
  if (score >= 85) return 'A';
  if (score >= 70) return 'B';
  if (score >= 55) return 'C';
  if (score >= 40) return 'D';
  return 'F';
}

export function getGradeColor(grade: HealthGrade): string {
  const colors: Record<HealthGrade, string> = {
    A: '#10B981', // Yeşil
    B: '#34D399', // Açık yeşil
    C: '#F59E0B', // Turuncu
    D: '#EF4444', // Kırmızı
    F: '#991B1B', // Koyu kırmızı
  };
  return colors[grade];
}

export function getGradeEmoji(grade: HealthGrade): string {
  const emojis: Record<HealthGrade, string> = {
    A: '🌟',
    B: '💪',
    C: '⚡',
    D: '⚠️',
    F: '🆘',
  };
  return emojis[grade];
}

// ══════════════════════════════════════════════════════════════
// ANA HESAPLAMA FONKSİYONU
// ══════════════════════════════════════════════════════════════

export function calculateHealthScore(metrics: DailyMetrics): HealthScoreResult {
  const insights: string[] = [];

  // ═══════════════════════════════════════════════════════
  // A) BESLENME PUANI (Ağırlık: %40)
  // ═══════════════════════════════════════════════════════

  let nutritionScore = 100;

  // GI ortalaması penaltisi
  if (metrics.avgGI <= 55) {
    // Tam puan — düşük GI
  } else if (metrics.avgGI <= 70) {
    nutritionScore -= (metrics.avgGI - 55) * 1.5; // max -22.5
  } else {
    nutritionScore -= 22.5 + (metrics.avgGI - 70) * 2; // max -82.5
  }

  // Karb limiti aşımı
  if (metrics.carbRatio > 1.0) {
    nutritionScore -= Math.min(30, (metrics.carbRatio - 1.0) * 40);
  }

  // Kırmızı besin penaltisi
  nutritionScore -= metrics.redFoodCount * 5;

  // Yeşil besin bonusu
  nutritionScore += metrics.greenFoodRatio * 15;

  nutritionScore = clamp(nutritionScore, 0, 100);

  if (nutritionScore < 50) {
    insights.push('Bugün yüksek GI\'li besinleri fazla tükettin. Yarın yeşil besinlere ağırlık ver.');
  }

  // ═══════════════════════════════════════════════════════
  // B) DUYGU DURUMU PUANI (Ağırlık: %15)
  // ═══════════════════════════════════════════════════════

  let moodScore = 0;

  // mood_score 1-10 → max 50 puan
  moodScore += (metrics.avgMood / 10) * 50;

  // Düşük stres bonusu (10 = max stres)
  moodScore += ((10 - metrics.avgStress) / 10) * 25;

  // Enerji seviyesi
  moodScore += (metrics.avgEnergy / 10) * 25;

  moodScore = clamp(moodScore, 0, 100);

  if (moodScore < 50) {
    insights.push('Stres seviyeni düşürmek için 10dk nefes egzersizi veya kısa bir yürüyüş dene.');
  }

  // ═══════════════════════════════════════════════════════
  // C) UYKU PUANI (Ağırlık: %20)
  // ═══════════════════════════════════════════════════════

  let sleepScore = 0;
  const sleepHours = metrics.sleepDurationMinutes / 60;

  // Süre puanı (max 60)
  if (sleepHours >= 7 && sleepHours <= 9) {
    sleepScore = 60;
  } else if (sleepHours >= 6 && sleepHours < 7) {
    sleepScore = 40;
  } else if (sleepHours >= 5 && sleepHours < 6) {
    sleepScore = 20;
  } else if (sleepHours > 9 && sleepHours <= 10) {
    sleepScore = 45;
  } else {
    sleepScore = 10;
  }

  // Kalite skoru (1-10) → max 40 puan
  sleepScore += (metrics.sleepQuality / 10) * 40;

  sleepScore = clamp(sleepScore, 0, 100);

  if (sleepScore < 50) {
    insights.push('Yetersiz uyku insülin direncini artırır. 7-9 saat uyumayı hedefle.');
  }

  // ═══════════════════════════════════════════════════════
  // D) HİDRASYON PUANI (Ağırlık: %15)
  // ═══════════════════════════════════════════════════════

  let hydrationScore = 0;
  const waterRatio = metrics.waterTarget > 0
    ? metrics.waterMl / metrics.waterTarget
    : 0;

  if (waterRatio >= 1.0) {
    hydrationScore = 100;
  } else if (waterRatio >= 0.75) {
    hydrationScore = 75;
  } else if (waterRatio >= 0.5) {
    hydrationScore = 50;
  } else if (waterRatio >= 0.25) {
    hydrationScore = 25;
  } else {
    hydrationScore = 10;
  }

  if (hydrationScore < 50) {
    insights.push(
      `Su hedefinin %${Math.round(waterRatio * 100)}'ine ulaştın. Daha fazla su iç.`
    );
  }

  // ═══════════════════════════════════════════════════════
  // E) KAFEİN PUANI (Ağırlık: %10)
  // ═══════════════════════════════════════════════════════

  let caffeineScore = 100;

  if (metrics.caffeineMg > 400) {
    caffeineScore = 20;
  } else if (metrics.caffeineMg > 300) {
    caffeineScore = 50;
  } else if (metrics.caffeineMg > 200) {
    caffeineScore = 80;
  }

  // Diyabet tipine göre sıkılaştırma
  if (['tip1', 'tip2', 'gestasyonel'].includes(metrics.diabetesType)) {
    if (metrics.caffeineMg > 200) {
      caffeineScore -= 20;
    }
  }

  caffeineScore = clamp(caffeineScore, 0, 100);

  if (caffeineScore < 50) {
    insights.push('Kafein miktarın yüksek. Öğleden sonra kafeinli içeceklerden kaçın.');
  }

  // ═══════════════════════════════════════════════════════
  // TOPLAM
  // ═══════════════════════════════════════════════════════

  const totalScore = Math.round(
    nutritionScore  * WEIGHTS.nutrition +
    moodScore       * WEIGHTS.mood +
    sleepScore      * WEIGHTS.sleep +
    hydrationScore  * WEIGHTS.hydration +
    caffeineScore   * WEIGHTS.caffeine
  );

  const grade = getGrade(totalScore);

  return {
    totalScore,
    grade,
    breakdown: {
      nutrition: Math.round(nutritionScore),
      mood: Math.round(moodScore),
      sleep: Math.round(sleepScore),
      hydration: Math.round(hydrationScore),
      caffeine: Math.round(caffeineScore),
    },
    insights,
  };
}

// ══════════════════════════════════════════════════════════════
// VARSAYILAN METRİKLER
// ══════════════════════════════════════════════════════════════
// Veri yokken kullanılacak nötr değerler (skor: ~70)

export const DEFAULT_METRICS: DailyMetrics = {
  avgGI: 50,
  totalGL: 0,
  carbRatio: 0,
  redFoodCount: 0,
  greenFoodRatio: 0.5,
  avgMood: 7,
  avgStress: 4,
  avgEnergy: 6,
  sleepDurationMinutes: 420,
  sleepQuality: 7,
  waterMl: 0,
  waterTarget: 2400,
  caffeineMg: 0,
  diabetesType: 'yok',
  bmi: 22,
};
