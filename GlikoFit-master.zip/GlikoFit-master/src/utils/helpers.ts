// ============================================================
// 🔧 Yardımcı Fonksiyonlar
// ============================================================

import { TrafficLight } from '../store/useAppStore';

/**
 * Glisemik İndeks değerine göre trafik lambası rengi belirler.
 * @param gi - Glisemik İndeks değeri (0-100+)
 * @returns TrafficLight rengi
 *
 * GI Sınıflandırması:
 * - Düşük (Yeşil/Güvenli): 0 - 55
 * - Orta (Sarı/Dikkat):    56 - 69
 * - Yüksek (Kırmızı/Riskli): 70+
 */
export function getTrafficLightFromGI(gi: number): TrafficLight {
  if (gi <= 55) return 'green';
  if (gi <= 69) return 'yellow';
  return 'red';
}

/**
 * Glisemik Yük seviyesini belirler.
 * @param gl - Glisemik Yük değeri
 * @returns TrafficLight rengi
 *
 * GL Sınıflandırması:
 * - Düşük (Yeşil): 0 - 10
 * - Orta (Sarı):   11 - 19
 * - Yüksek (Kırmızı): 20+
 */
export function getTrafficLightFromGL(gl: number): TrafficLight {
  if (gl <= 10) return 'green';
  if (gl <= 19) return 'yellow';
  return 'red';
}

/**
 * Glisemik Yük hesaplar.
 * Formül: GL = (GI × Karbonhidrat gram) / 100
 * Burada karbonhidrat gram = (carbsPer100g / 100) × portionGrams
 */
export function calculateGlycemicLoad(
  glycemicIndex: number,
  carbsPer100g: number,
  portionGrams: number
): number {
  const carbsInPortion = (carbsPer100g / 100) * portionGrams;
  const gl = (glycemicIndex * carbsInPortion) / 100;
  return Math.round(gl * 10) / 10;
}

/**
 * Sayıyı belirli ondalık basamağa yuvarlar.
 */
export function roundTo(value: number, decimals: number = 1): number {
  const multiplier = Math.pow(10, decimals);
  return Math.round(value * multiplier) / multiplier;
}

/**
 * Tarih formatlama — Türkçe
 */
export function formatDate(date: Date): string {
  return date.toLocaleDateString('tr-TR', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });
}

/**
 * Saat formatlama — Türkçe
 */
export function formatTime(date: Date): string {
  return date.toLocaleTimeString('tr-TR', {
    hour: '2-digit',
    minute: '2-digit',
  });
}
