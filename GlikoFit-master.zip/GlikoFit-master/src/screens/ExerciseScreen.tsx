import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity,
  TextInput, ScrollView, ActivityIndicator, Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { supabase } from '../lib/supabase';
import {
  getExercises, calculateCaloriesBurned,
  type FsExercise, type ExerciseCategoryGroup,
} from '../lib/fatsecret';
import { useUserStore } from '../store/useUserStore';
import { useHealthStore } from '../store/useHealthStore';
import type { ExerciseLogInsert } from '../types/database';

// ══════════════════════════════════════════════════════════════
//  🏃 Egzersiz Takip Ekranı
// ══════════════════════════════════════════════════════════════

type ViewMode = 'list' | 'log' | 'history';

export default function ExerciseScreen() {
  const insets  = useSafeAreaInsets();
  const nav     = useNavigation<any>();
  const { profile } = useUserStore();
  const { addExercise, todayExerciseLogs, totalCaloriesBurned } = useHealthStore();

  const [mode, setMode]           = useState<ViewMode>('list');
  const [groups, setGroups]       = useState<ExerciseCategoryGroup[]>([]);
  const [selCategory, setSelCat]  = useState<string | null>(null);
  const [selExercise, setSelEx]   = useState<FsExercise | null>(null);
  const [duration, setDuration]   = useState('30');
  const [isSaving, setIsSaving]   = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [searchText, setSearchText] = useState('');

  const weightKg = profile?.weightKg ?? 70;

  // Egzersiz listesini yükle
  useEffect(() => {
    setIsLoading(true);
    getExercises().then((g) => { setGroups(g); setIsLoading(false); });
  }, []);

  const filteredGroups = useCallback(() => {
    if (!searchText.trim()) return selCategory
      ? groups.filter((g) => g.category === selCategory)
      : groups;

    const q = searchText.toLowerCase();
    return groups
      .map((g) => ({
        ...g,
        exercises: g.exercises.filter((e) =>
          e.exercise_name.toLowerCase().includes(q),
        ),
      }))
      .filter((g) => g.exercises.length > 0);
  }, [groups, selCategory, searchText]);

  const handleSelectExercise = (ex: FsExercise) => {
    setSelEx(ex);
    setMode('log');
  };

  const handleLog = async () => {
    if (!selExercise || !profile) return;

    const dMin = parseInt(duration);
    if (isNaN(dMin) || dMin <= 0) {
      Alert.alert('Hata', 'Lütfen geçerli bir süre girin.');
      return;
    }

    const calories = calculateCaloriesBurned(
      selExercise.calories_per_min,
      dMin,
      weightKg,
    );

    setIsSaving(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Oturum yok');

      const entry: ExerciseLogInsert = {
        user_id:          user.id,
        exercise_name:    selExercise.exercise_name,
        exercise_category: selExercise.category,
        fatsecret_exercise_id: selExercise.exercise_id,
        duration_minutes: dMin,
        calories_burned:  calories,
        met_value:        selExercise.met_value,
      };

      await addExercise(user.id, entry);

      Alert.alert(
        '✅ Egzersiz Kaydedildi!',
        `${selExercise.exercise_name}\n${dMin} dakika · ${calories} kcal yakıldı`,
        [{ text: 'Harika!', onPress: () => setMode('list') }],
      );
    } catch (err: any) {
      Alert.alert('Hata', err.message);
    } finally {
      setIsSaving(false);
    }
  };

  const getIntensityLabel = (met: number) => {
    if (met < 3) return { label: 'Hafif', color: '#10B981' };
    if (met < 5) return { label: 'Orta', color: '#F59E0B' };
    if (met < 8) return { label: 'Yoğun', color: '#EF4444' };
    return { label: 'Çok Yoğun', color: '#7C3AED' };
  };

  // ── Egzersiz Kayıt Formu ───────────────────────────────────
  if (mode === 'log' && selExercise) {
    const dur = parseInt(duration) || 0;
    const calories = calculateCaloriesBurned(selExercise.calories_per_min, dur, weightKg);
    const intensity = getIntensityLabel(selExercise.met_value);

    return (
      <View style={{ flex:1, backgroundColor:'#F4F4F4' }}>
        <LinearGradient
          colors={['#064E3B','#10B981']}
          style={{ paddingTop: insets.top + 20, paddingBottom: 32, paddingHorizontal: 24 }}
        >
          <TouchableOpacity onPress={() => setMode('list')} style={styles.backBtn}>
            <Ionicons name="arrow-back" size={22} color="#fff" />
          </TouchableOpacity>
          <Text style={styles.logTitle}>{selExercise.exercise_name}</Text>
          <View style={[styles.intensityBadge, { backgroundColor: intensity.color + '22' }]}>
            <Text style={[styles.intensityText, { color: intensity.color }]}>{intensity.label}</Text>
          </View>
        </LinearGradient>

        <ScrollView
          contentContainerStyle={{ padding: 24 }}
          showsVerticalScrollIndicator={false}
        >
          {/* Süre Girişi */}
          <View style={styles.logCard}>
            <Text style={styles.logCardTitle}>⏱️ Süre</Text>
            <View style={styles.durationRow}>
              {[10, 20, 30, 45, 60, 90].map((d) => (
                <TouchableOpacity
                  key={d}
                  onPress={() => setDuration(String(d))}
                  style={[styles.durationChip, duration === String(d) && styles.durationChipActive]}
                >
                  <Text style={[styles.durationChipText, duration === String(d) && styles.durationChipTextActive]}>
                    {d} dk
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
            <View style={styles.durationInput}>
              <TextInput
                style={styles.durationInputField}
                value={duration}
                onChangeText={setDuration}
                keyboardType="number-pad"
                placeholder="Dakika girin"
                placeholderTextColor="#9CA3AF"
              />
              <Text style={styles.durationUnit}>dakika</Text>
            </View>
          </View>

          {/* Kalori Tahmini */}
          <View style={styles.calorieCard}>
            <View style={styles.calorieLeft}>
              <Text style={styles.calorieLabel}>Tahmini Kalori Yakımı</Text>
              <Text style={styles.calorieValue}>{calories} kcal</Text>
              <Text style={styles.calorieNote}>{weightKg}kg · {dur} dakika</Text>
            </View>
            <View style={styles.calorieIcon}>
              <Text style={{ fontSize:44 }}>🔥</Text>
            </View>
          </View>

          {/* MET ve İpuçları */}
          <View style={styles.logCard}>
            <Text style={styles.logCardTitle}>📊 Egzersiz Bilgisi</Text>
            <View style={styles.infoRow}>
              <Text style={styles.infoKey}>MET Değeri</Text>
              <Text style={styles.infoVal}>{selExercise.met_value.toFixed(1)}</Text>
            </View>
            <View style={styles.infoRow}>
              <Text style={styles.infoKey}>Yoğunluk</Text>
              <Text style={[styles.infoVal, { color: intensity.color }]}>{intensity.label}</Text>
            </View>
            <View style={styles.infoRow}>
              <Text style={styles.infoKey}>Kategori</Text>
              <Text style={styles.infoVal}>{selExercise.category}</Text>
            </View>
            <View style={styles.infoRow}>
              <Text style={styles.infoKey}>dk başına</Text>
              <Text style={styles.infoVal}>{(selExercise.calories_per_min * (weightKg/65)).toFixed(1)} kcal</Text>
            </View>
          </View>

          {/* Kaydet Butonu */}
          <TouchableOpacity
            style={[styles.saveBtn, isSaving && styles.saveBtnDisabled]}
            onPress={handleLog}
            disabled={isSaving}
          >
            {isSaving ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <>
                <Ionicons name="checkmark-circle-outline" size={22} color="#fff" />
                <Text style={styles.saveBtnText}>Egzersizi Kaydet</Text>
              </>
            )}
          </TouchableOpacity>
        </ScrollView>
      </View>
    );
  }

  // ── Ana Liste ──────────────────────────────────────────────
  return (
    <View style={{ flex:1, backgroundColor:'#F4F4F4' }}>
      {/* Header */}
      <LinearGradient
        colors={['#064E3B','#10B981']}
        style={{ paddingTop: insets.top + 20, paddingBottom: 24, paddingHorizontal: 24 }}
      >
        <View style={styles.headerRow}>
          <TouchableOpacity onPress={() => nav.goBack()}>
            <Ionicons name="arrow-back" size={24} color="#fff" />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>🏃 Egzersiz</Text>
          <View style={{ width:24 }} />
        </View>

        {/* Günlük Özet */}
        {totalCaloriesBurned > 0 && (
          <View style={styles.daySummary}>
            <View style={styles.daySummaryItem}>
              <Text style={styles.daySumLabel}>Bugün Yakılan</Text>
              <Text style={styles.daySumValue}>{totalCaloriesBurned} kcal</Text>
            </View>
            <View style={styles.daySumDivider} />
            <View style={styles.daySummaryItem}>
              <Text style={styles.daySumLabel}>Egzersiz Sayısı</Text>
              <Text style={styles.daySumValue}>{todayExerciseLogs.length}</Text>
            </View>
          </View>
        )}

        {/* Arama */}
        <View style={styles.searchBar}>
          <Ionicons name="search" size={20} color="#9CA3AF" />
          <TextInput
            style={styles.searchInput}
            placeholder="Egzersiz ara..."
            placeholderTextColor="#9CA3AF"
            value={searchText}
            onChangeText={setSearchText}
          />
        </View>
      </LinearGradient>

      {/* Kategori Filtresi */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={{ paddingHorizontal:20, paddingVertical:14, gap:8 }}
      >
        <TouchableOpacity
          onPress={() => setSelCat(null)}
          style={[styles.catChip, !selCategory && styles.catChipActive]}
        >
          <Text style={[styles.catChipText, !selCategory && styles.catChipTextActive]}>Tümü</Text>
        </TouchableOpacity>
        {groups.map((g) => (
          <TouchableOpacity
            key={g.category}
            onPress={() => setSelCat(selCategory === g.category ? null : g.category)}
            style={[styles.catChip, selCategory === g.category && styles.catChipActive]}
          >
            <Text style={[styles.catChipText, selCategory === g.category && styles.catChipTextActive]}>
              {g.category}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Liste */}
      {isLoading ? (
        <View style={styles.centered}>
          <ActivityIndicator size="large" color="#10B981" />
          <Text style={styles.loadingText}>Egzersizler yükleniyor...</Text>
        </View>
      ) : (
        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 40 }}>
          {filteredGroups().map((group) => (
            <View key={group.category}>
              <Text style={styles.groupTitle}>{group.category}</Text>
              {group.exercises.map((ex) => {
                const cal60 = Math.round(ex.calories_per_min * 60 * (weightKg / 65));
                const intensity = getIntensityLabel(ex.met_value);
                return (
                  <TouchableOpacity
                    key={ex.exercise_id}
                    style={styles.exItem}
                    onPress={() => handleSelectExercise(ex)}
                    activeOpacity={0.7}
                  >
                    <View style={styles.exLeft}>
                      <Text style={styles.exName}>{ex.exercise_name}</Text>
                      <View style={styles.exMeta}>
                        <View style={[styles.exIntensity, { backgroundColor: intensity.color + '22' }]}>
                          <Text style={[styles.exIntensityText, { color: intensity.color }]}>{intensity.label}</Text>
                        </View>
                        <Text style={styles.exCalText}>~{cal60} kcal/saat</Text>
                      </View>
                    </View>
                    <View style={styles.exRight}>
                      <Text style={styles.exMet}>MET {ex.met_value.toFixed(1)}</Text>
                      <Ionicons name="chevron-forward" size={18} color="#9CA3AF" />
                    </View>
                  </TouchableOpacity>
                );
              })}
            </View>
          ))}
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  centered:      { flex:1, alignItems:'center', justifyContent:'center', paddingTop:60 },
  loadingText:   { marginTop:12, fontSize:16, color:'#6B7280', fontWeight:'600' },
  headerRow:     { flexDirection:'row', alignItems:'center', justifyContent:'space-between', marginBottom:16 },
  headerTitle:   { fontSize:22, fontWeight:'900', color:'#fff' },
  searchBar:     { flexDirection:'row', alignItems:'center', backgroundColor:'rgba(255,255,255,0.15)', borderRadius:16, paddingHorizontal:14, height:46, gap:10 },
  searchInput:   { flex:1, fontSize:15, color:'#fff' },

  daySummary:    { flexDirection:'row', backgroundColor:'rgba(0,0,0,0.2)', borderRadius:16, padding:16, marginBottom:16 },
  daySummaryItem:{ flex:1, alignItems:'center' },
  daySumLabel:   { fontSize:11, color:'rgba(255,255,255,0.7)', fontWeight:'600', marginBottom:4 },
  daySumValue:   { fontSize:22, fontWeight:'900', color:'#fff' },
  daySumDivider: { width:1, backgroundColor:'rgba(255,255,255,0.2)' },

  catChip:     { paddingHorizontal:16, paddingVertical:8, borderRadius:14, backgroundColor:'#fff', borderWidth:1, borderColor:'#E5E7EB' },
  catChipActive:{ backgroundColor:'#10B981', borderColor:'#10B981' },
  catChipText:  { fontSize:13, fontWeight:'700', color:'#6B7280' },
  catChipTextActive:{ color:'#fff' },

  groupTitle:    { fontSize:14, fontWeight:'800', color:'#6B7280', textTransform:'uppercase', letterSpacing:0.8, paddingHorizontal:20, paddingTop:16, paddingBottom:8 },
  exItem:        { flexDirection:'row', alignItems:'center', backgroundColor:'#fff', marginHorizontal:16, marginBottom:8, borderRadius:18, paddingVertical:14, paddingHorizontal:16, shadowColor:'#000', shadowOffset:{width:0,height:2}, shadowOpacity:0.04, shadowRadius:6, elevation:2 },
  exLeft:        { flex:1 },
  exName:        { fontSize:16, fontWeight:'800', color:'#1A1A1A', marginBottom:6 },
  exMeta:        { flexDirection:'row', alignItems:'center', gap:8 },
  exIntensity:   { paddingHorizontal:10, paddingVertical:4, borderRadius:10 },
  exIntensityText:{ fontSize:11, fontWeight:'700' },
  exCalText:     { fontSize:12, color:'#9CA3AF', fontWeight:'600' },
  exRight:       { alignItems:'flex-end', gap:4 },
  exMet:         { fontSize:12, fontWeight:'700', color:'#9CA3AF' },

  // Log Formu
  backBtn:       { width:40, height:40, borderRadius:20, backgroundColor:'rgba(255,255,255,0.15)', alignItems:'center', justifyContent:'center', marginBottom:16 },
  logTitle:      { fontSize:26, fontWeight:'900', color:'#fff', marginBottom:8 },
  intensityBadge:{ alignSelf:'flex-start', paddingHorizontal:14, paddingVertical:6, borderRadius:12 },
  intensityText: { fontSize:13, fontWeight:'800' },

  logCard:       { backgroundColor:'#fff', borderRadius:20, padding:18, marginBottom:16 },
  logCardTitle:  { fontSize:16, fontWeight:'800', color:'#1A1A1A', marginBottom:14 },

  durationRow:   { flexDirection:'row', flexWrap:'wrap', gap:8, marginBottom:14 },
  durationChip:  { paddingHorizontal:16, paddingVertical:10, borderRadius:14, backgroundColor:'#F3F4F6' },
  durationChipActive:{ backgroundColor:'#10B981' },
  durationChipText:{ fontSize:14, fontWeight:'700', color:'#6B7280' },
  durationChipTextActive:{ color:'#fff' },
  durationInput: { flexDirection:'row', alignItems:'center', backgroundColor:'#F3F4F6', borderRadius:14, paddingHorizontal:16, height:50 },
  durationInputField:{ flex:1, fontSize:18, fontWeight:'800', color:'#1A1A1A' },
  durationUnit:  { fontSize:14, color:'#9CA3AF', fontWeight:'600' },

  calorieCard:   { backgroundColor:'#064E3B', borderRadius:20, padding:20, marginBottom:16, flexDirection:'row', alignItems:'center' },
  calorieLeft:   { flex:1 },
  calorieLabel:  { fontSize:13, color:'rgba(255,255,255,0.7)', fontWeight:'600', marginBottom:6 },
  calorieValue:  { fontSize:40, fontWeight:'900', color:'#fff' },
  calorieNote:   { fontSize:12, color:'rgba(255,255,255,0.5)', marginTop:4 },
  calorieIcon:   { marginLeft:16 },

  infoRow:       { flexDirection:'row', justifyContent:'space-between', alignItems:'center', paddingVertical:10, borderBottomWidth:1, borderBottomColor:'#F3F4F6' },
  infoKey:       { fontSize:14, color:'#6B7280', fontWeight:'600' },
  infoVal:       { fontSize:14, fontWeight:'800', color:'#1A1A1A' },

  saveBtn:       { flexDirection:'row', alignItems:'center', justifyContent:'center', gap:10, backgroundColor:'#10B981', borderRadius:18, paddingVertical:18 },
  saveBtnDisabled:{ opacity:0.6 },
  saveBtnText:   { fontSize:17, fontWeight:'900', color:'#fff' },
});
