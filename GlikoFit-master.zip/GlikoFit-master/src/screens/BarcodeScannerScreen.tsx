import React, { useState, useEffect, useRef } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, ActivityIndicator,
  Alert, Vibration, Platform, Linking,
} from 'react-native';
import { CameraView, Camera, type BarcodeScanningResult } from 'expo-camera';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { findFoodByBarcode } from '../lib/fatsecret';
import type { FsFood } from '../lib/fatsecret';

// ══════════════════════════════════════════════════════════════
//  📦 Barkod Tarayıcı Ekranı
// ══════════════════════════════════════════════════════════════

export default function BarcodeScannerScreen() {
  const insets   = useSafeAreaInsets();
  const nav      = useNavigation<any>();

  const [hasPermission, setHasPermission] = useState<boolean | null>(null);
  const [isAnalyzing, setIsAnalyzing]     = useState(false);
  const [scannedFood, setScannedFood]     = useState<FsFood | null>(null);
  const [torchOn, setTorchOn]             = useState(false);
  const lastScan = useRef<string>('');

  // Kamera izni
  useEffect(() => {
    Camera.requestCameraPermissionsAsync().then(({ status }) => {
      setHasPermission(status === 'granted');
    });
  }, []);

  const handleBarcodeScanned = async ({ type, data }: BarcodeScanningResult) => {
    if (isAnalyzing || data === lastScan.current) return;
    lastScan.current = data;
    setIsAnalyzing(true);

    Vibration.vibrate(80);

    try {
      const result = await findFoodByBarcode(data);

      if (result.food) {
        setScannedFood(result.food);
      } else {
        Alert.alert(
          'Besin Bulunamadı',
          `Barkod: ${data}\n\nBu ürün veritabanında kayıtlı değil.`,
          [
            { text: 'Tekrar Tara', onPress: () => { lastScan.current = ''; } },
            { text: 'Geri', onPress: () => nav.goBack() },
          ],
        );
        lastScan.current = '';
      }
    } catch {
      Alert.alert('Hata', 'Barkod okunamadı, tekrar deneyin.');
      lastScan.current = '';
    } finally {
      setIsAnalyzing(false);
    }
  };

  const getGiColor = (gi: number | null) => {
    if (!gi) return '#F59E0B';
    if (gi <= 55) return '#10B981';
    if (gi <= 69) return '#F59E0B';
    return '#EF4444';
  };

  // ── İzin Yok ──────────────────────────────────────────────
  if (hasPermission === false) {
    return (
      <View style={styles.centered}>
        <Ionicons name="camera-off-outline" size={64} color="#9CA3AF" />
        <Text style={styles.permText}>Kamera erişimi gerekli</Text>
        <Text style={styles.permSub}>Barkod tarayıcı için kamera iznine ihtiyaç var.</Text>
        <TouchableOpacity
          onPress={() => Linking.openSettings()}
          style={{ marginTop: 20, backgroundColor: '#10B981', paddingHorizontal: 28, paddingVertical: 14, borderRadius: 16 }}
        >
          <Text style={{ color: '#FFF', fontWeight: '800', fontSize: 15 }}>Ayarları Aç</Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => nav.goBack()}
          style={{ marginTop: 12, paddingHorizontal: 20, paddingVertical: 10 }}
        >
          <Text style={{ color: '#9CA3AF', fontWeight: '600', fontSize: 14 }}>Geri Dön</Text>
        </TouchableOpacity>
      </View>
    );
  }

  if (hasPermission === null) {
    return <View style={styles.centered}><ActivityIndicator size="large" color="#10B981" /></View>;
  }

  // ── Taranan Ürün Kartı ─────────────────────────────────────
  if (scannedFood) {
    const gi = scannedFood.gi_value;
    const giColor = getGiColor(gi);

    return (
      <View style={{ flex: 1, backgroundColor: '#0A0A0A' }}>
        <LinearGradient
          colors={['#064E3B', '#0A0A0A']}
          style={{ paddingTop: insets.top + 16, paddingHorizontal: 24, paddingBottom: 24 }}
        >
          <TouchableOpacity onPress={() => nav.goBack()} style={styles.backBtn}>
            <Ionicons name="arrow-back" size={22} color="#fff" />
          </TouchableOpacity>

          <View style={styles.successBadge}>
            <Ionicons name="checkmark-circle" size={20} color="#10B981" />
            <Text style={styles.successText}>Ürün Tanındı!</Text>
          </View>

          <Text style={styles.productName}>{scannedFood.food_name}</Text>
          {scannedFood.brand_name && (
            <Text style={styles.brandName}>{scannedFood.brand_name}</Text>
          )}
        </LinearGradient>

        <View style={styles.macroCard}>
          {/* GI Badge */}
          <View style={[styles.giBadge, { borderColor: giColor + '44', backgroundColor: giColor + '1A' }]}>
            <Text style={[styles.giVal, { color: giColor }]}>
              {gi !== null ? `GI: ${gi}` : 'GI Bilinmiyor'}
            </Text>
            <View style={[styles.giDot, { backgroundColor: giColor }]} />
          </View>

          {/* Makro Grid */}
          <View style={styles.macroGrid}>
            {[
              { label: 'Kalori',     val: `${scannedFood.nutrition.calories}`, unit: 'kcal', icon: '🔥' },
              { label: 'Karbonhidrat', val: `${scannedFood.nutrition.carbs}`,  unit: 'g',    icon: '🌾' },
              { label: 'Protein',    val: `${scannedFood.nutrition.protein}`,   unit: 'g',    icon: '💪' },
              { label: 'Yağ',        val: `${scannedFood.nutrition.fat}`,       unit: 'g',    icon: '🥑' },
              { label: 'Lif',        val: `${scannedFood.nutrition.fiber}`,     unit: 'g',    icon: '🌿' },
              { label: 'Şeker',      val: `${scannedFood.nutrition.sugar}`,     unit: 'g',    icon: '🍬' },
            ].map((m) => (
              <View key={m.label} style={styles.macroItem}>
                <Text style={styles.macroEmoji}>{m.icon}</Text>
                <Text style={styles.macroValue}>{m.val}<Text style={styles.macroUnit}>{m.unit}</Text></Text>
                <Text style={styles.macroLabel}>{m.label}</Text>
              </View>
            ))}
          </View>

          {/* Mikro Besinler */}
          {(scannedFood.nutrition.sodium > 0 || scannedFood.nutrition.potassium > 0) && (
            <View style={styles.microRow}>
              {scannedFood.nutrition.sodium > 0 && (
                <View style={styles.microChip}>
                  <Text style={styles.microText}>🧂 Sodium {scannedFood.nutrition.sodium}mg</Text>
                </View>
              )}
              {scannedFood.nutrition.potassium > 0 && (
                <View style={styles.microChip}>
                  <Text style={styles.microText}>⚡ Potasyum {scannedFood.nutrition.potassium}mg</Text>
                </View>
              )}
              {scannedFood.nutrition.cholesterol > 0 && (
                <View style={styles.microChip}>
                  <Text style={styles.microText}>🫀 Kolesterol {scannedFood.nutrition.cholesterol}mg</Text>
                </View>
              )}
            </View>
          )}

          {/* Eylem Butonları */}
          <View style={styles.actionRow}>
            <TouchableOpacity
              style={styles.btnSecondary}
              onPress={() => { setScannedFood(null); lastScan.current = ''; }}
            >
              <Ionicons name="scan-outline" size={18} color="#10B981" />
              <Text style={styles.btnSecondaryText}>Yeni Tara</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.btnPrimary}
              onPress={() => nav.navigate('FoodDetail', {
                food: {
                  id:             parseInt(scannedFood.food_id) || 0,
                  name:           scannedFood.food_name,
                  category:       scannedFood.category ?? 'Genel',
                  gi_value:       scannedFood.gi_value ?? 50,
                  carbs_per_100g: scannedFood.nutrition.carbs,
                  protein_per_100g: scannedFood.nutrition.protein,
                  fat_per_100g:   scannedFood.nutrition.fat,
                  calories_per_100g: scannedFood.nutrition.calories,
                  fiber_per_100g: scannedFood.nutrition.fiber,
                  color_code:     scannedFood.color_code,
                  source:         'fatsecret',
                  created_at:     new Date().toISOString(),
                },
              })}
            >
              <Ionicons name="add-circle-outline" size={18} color="#fff" />
              <Text style={styles.btnPrimaryText}>Öğüne Ekle</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    );
  }

  // ── Kamera Görünümü ────────────────────────────────────────
  return (
    <View style={{ flex: 1, backgroundColor: '#000' }}>
      <CameraView
        style={StyleSheet.absoluteFill}
        facing="back"
        enableTorch={torchOn}
        barcodeScannerSettings={{
          barcodeTypes: ['ean13', 'ean8', 'upc_a', 'upc_e', 'code128', 'code39', 'qr'],
        }}
        onBarcodeScanned={isAnalyzing ? undefined : handleBarcodeScanned}
      />

      {/* Overlay */}
      <View style={StyleSheet.absoluteFill} pointerEvents="box-none">
        {/* Üst bar */}
        <LinearGradient
          colors={['rgba(0,0,0,0.8)', 'transparent']}
          style={{ paddingTop: insets.top + 12, paddingHorizontal: 20, paddingBottom: 40 }}
        >
          <View style={styles.topBar}>
            <TouchableOpacity onPress={() => nav.goBack()} style={styles.overlayBtn}>
              <Ionicons name="close" size={22} color="#fff" />
            </TouchableOpacity>
            <Text style={styles.overlayTitle}>Barkod Tara</Text>
            <TouchableOpacity
              onPress={() => setTorchOn(!torchOn)}
              style={[styles.overlayBtn, torchOn && { backgroundColor: '#F59E0B' }]}
            >
              <Ionicons name={torchOn ? 'flash' : 'flash-outline'} size={22} color="#fff" />
            </TouchableOpacity>
          </View>
        </LinearGradient>

        {/* Tarama Kutusu */}
        <View style={styles.scanFrame}>
          <View style={[styles.corner, styles.cornerTL]} />
          <View style={[styles.corner, styles.cornerTR]} />
          <View style={[styles.corner, styles.cornerBL]} />
          <View style={[styles.corner, styles.cornerBR]} />

          {isAnalyzing ? (
            <View style={styles.analyzingBox}>
              <ActivityIndicator size="large" color="#10B981" />
              <Text style={styles.analyzingText}>Ürün Aranıyor...</Text>
            </View>
          ) : (
            <View style={styles.scanLine} />
          )}
        </View>

        {/* Alt Bilgi */}
        <LinearGradient
          colors={['transparent', 'rgba(0,0,0,0.85)']}
          style={{ flex: 1, justifyContent: 'flex-end', paddingBottom: insets.bottom + 40, alignItems: 'center' }}
        >
          <View style={styles.hintBadge}>
            <Ionicons name="barcode-outline" size={18} color="#10B981" />
            <Text style={styles.hintText}>
              {isAnalyzing ? 'Analiz ediliyor...' : 'Barkodu çerçeveye hizalayın'}
            </Text>
          </View>
          <Text style={styles.hintSub}>EAN-13 · EAN-8 · UPC-A · UPC-E · Code128</Text>
        </LinearGradient>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  centered:        { flex:1, alignItems:'center', justifyContent:'center', backgroundColor:'#0A0A0A' },
  permText:        { fontSize:18, fontWeight:'700', color:'#F9FAFB', marginTop:16 },
  permSub:         { fontSize:14, color:'#9CA3AF', marginTop:8, textAlign:'center' },

  backBtn:         { width:40, height:40, borderRadius:20, backgroundColor:'rgba(255,255,255,0.1)', alignItems:'center', justifyContent:'center', marginBottom:16 },
  successBadge:    { flexDirection:'row', alignItems:'center', gap:6, marginBottom:10 },
  successText:     { fontSize:14, fontWeight:'700', color:'#10B981' },
  productName:     { fontSize:26, fontWeight:'900', color:'#F9FAFB', lineHeight:32 },
  brandName:       { fontSize:15, color:'#9CA3AF', marginTop:4, fontWeight:'600' },

  macroCard:       { flex:1, backgroundColor:'#111827', borderTopLeftRadius:32, borderTopRightRadius:32, marginTop:-16, paddingHorizontal:24, paddingTop:28 },
  giBadge:         { flexDirection:'row', alignItems:'center', justifyContent:'space-between', borderWidth:1, borderRadius:16, paddingHorizontal:18, paddingVertical:12, marginBottom:20 },
  giVal:           { fontSize:17, fontWeight:'800' },
  giDot:           { width:12, height:12, borderRadius:6 },

  macroGrid:       { flexDirection:'row', flexWrap:'wrap', gap:12, marginBottom:20 },
  macroItem:       { width:'30%', backgroundColor:'#1F2937', borderRadius:16, padding:14, alignItems:'center' },
  macroEmoji:      { fontSize:20, marginBottom:4 },
  macroValue:      { fontSize:20, fontWeight:'900', color:'#F9FAFB' },
  macroUnit:       { fontSize:12, fontWeight:'600', color:'#6B7280' },
  macroLabel:      { fontSize:11, color:'#9CA3AF', marginTop:2, fontWeight:'600' },

  microRow:        { flexDirection:'row', flexWrap:'wrap', gap:8, marginBottom:24 },
  microChip:       { backgroundColor:'#1F2937', borderRadius:12, paddingHorizontal:12, paddingVertical:6 },
  microText:       { fontSize:12, color:'#9CA3AF', fontWeight:'600' },

  actionRow:       { flexDirection:'row', gap:12 },
  btnSecondary:    { flex:1, flexDirection:'row', alignItems:'center', justifyContent:'center', gap:8, paddingVertical:16, borderRadius:18, borderWidth:2, borderColor:'#10B981' },
  btnSecondaryText:{ fontSize:15, fontWeight:'800', color:'#10B981' },
  btnPrimary:      { flex:2, flexDirection:'row', alignItems:'center', justifyContent:'center', gap:8, paddingVertical:16, borderRadius:18, backgroundColor:'#10B981' },
  btnPrimaryText:  { fontSize:15, fontWeight:'800', color:'#fff' },

  topBar:          { flexDirection:'row', alignItems:'center', justifyContent:'space-between' },
  overlayBtn:      { width:44, height:44, borderRadius:22, backgroundColor:'rgba(255,255,255,0.15)', alignItems:'center', justifyContent:'center' },
  overlayTitle:    { fontSize:18, fontWeight:'800', color:'#fff' },

  scanFrame: {
    width:280, height:240, alignSelf:'center',
    position:'relative', justifyContent:'center', alignItems:'center',
  },
  corner:          { position:'absolute', width:28, height:28, borderColor:'#10B981', borderWidth:4 },
  cornerTL:        { top:0, left:0, borderRightWidth:0, borderBottomWidth:0, borderTopLeftRadius:8 },
  cornerTR:        { top:0, right:0, borderLeftWidth:0, borderBottomWidth:0, borderTopRightRadius:8 },
  cornerBL:        { bottom:0, left:0, borderRightWidth:0, borderTopWidth:0, borderBottomLeftRadius:8 },
  cornerBR:        { bottom:0, right:0, borderLeftWidth:0, borderTopWidth:0, borderBottomRightRadius:8 },
  scanLine:        { width:'80%', height:2, backgroundColor:'#10B981', opacity:0.8 },
  analyzingBox:    { alignItems:'center', gap:8 },
  analyzingText:   { color:'#10B981', fontWeight:'700', fontSize:14 },

  hintBadge:       { flexDirection:'row', alignItems:'center', gap:8, backgroundColor:'rgba(16,185,129,0.15)', paddingHorizontal:20, paddingVertical:12, borderRadius:20, marginBottom:8 },
  hintText:        { color:'#F9FAFB', fontWeight:'700', fontSize:14 },
  hintSub:         { color:'rgba(255,255,255,0.4)', fontSize:12, fontWeight:'500' },
});
