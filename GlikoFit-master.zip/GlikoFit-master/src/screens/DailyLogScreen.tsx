import React from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAppStore } from '../store/useAppStore';
import type { MealType, MealCategory, DailyLogEntry } from '../store/useAppStore';

// ── Sabitler ──────────────────────────────────────────────────

const MEAL_META: Record<MealType, { label: string; icon: string; color: string }> = {
  kahvalti: { label: 'Kahvaltı',     icon: '🌅', color: '#F59E0B' },
  ogle:     { label: 'Öğle Yemeği', icon: '☀️', color: '#10B981' },
  aksam:    { label: 'Akşam Yemeği',icon: '🌙', color: '#6366F1' },
  ara:      { label: 'Ara Öğün',    icon: '🍎', color: '#EC4899' },
};

const CAT_META: Record<MealCategory, { label: string; icon: string }> = {
  tabak:  { label: 'Tabak',   icon: '🍽️' },
  icecek: { label: 'İçecek',  icon: '🥤' },
  meyve:  { label: 'Meyve',   icon: '🍎' },
  diger:  { label: 'Diğer',   icon: '🥨' },
};

const TRAFFIC: Record<string, { bg: string; text: string; dot: string; label: string }> = {
  green:  { bg: '#ECFDF5', text: '#065F46', dot: '#10B981', label: 'Güvenli' },
  yellow: { bg: '#FFFBEB', text: '#78350F', dot: '#F59E0B', label: 'Dikkat'  },
  red:    { bg: '#FEF2F2', text: '#7F1D1D', dot: '#EF4444', label: 'Riskli'  },
};

const MEAL_ORDER: MealType[] = ['kahvalti', 'ogle', 'aksam', 'ara'];

function glColor(gl: number): string {
  if (gl >= 20) return '#EF4444';
  if (gl >= 10) return '#F59E0B';
  return '#10B981';
}

// ── Bileşenler ────────────────────────────────────────────────

function MealSection({ mealType, items }: { mealType: MealType; items: DailyLogEntry[] }) {
  const meta   = MEAL_META[mealType];
  const totalGL = Math.round(items.reduce((s, e) => s + e.glycemicLoad, 0) * 10) / 10;
  const totalCal = 0; // carbs bilgisi olmadan hesaplanamıyor – GL yeterli

  return (
    <View style={styles.mealSection}>
      {/* Öğün başlığı */}
      <View style={[styles.mealHeader, { borderLeftColor: meta.color }]}>
        <Text style={{ fontSize: 20 }}>{meta.icon}</Text>
        <View style={{ flex: 1, marginLeft: 10 }}>
          <Text style={styles.mealHeaderTitle}>{meta.label}</Text>
          <Text style={styles.mealHeaderSub}>{items.length} besin</Text>
        </View>
        <View style={[styles.mealGlBadge, { backgroundColor: glColor(totalGL) + '18' }]}>
          <Text style={[styles.mealGlBadgeVal, { color: glColor(totalGL) }]}>{totalGL}</Text>
          <Text style={[styles.mealGlBadgeLbl, { color: glColor(totalGL) }]}>GL</Text>
        </View>
      </View>

      {/* Besin kartları */}
      {items.map(item => {
        const t       = TRAFFIC[item.trafficLight] ?? TRAFFIC.green;
        const catInfo = item.mealCategory ? CAT_META[item.mealCategory] : null;
        return (
          <View key={item.id} style={styles.foodCard}>
            <View style={[styles.foodCardAccent, { backgroundColor: t.dot }]} />
            <View style={{ flex: 1, paddingLeft: 12 }}>
              <Text style={styles.foodName} numberOfLines={1}>{item.foodName}</Text>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 6 }}>
                {catInfo && (
                  <View style={styles.catChip}>
                    <Text style={{ fontSize: 10 }}>{catInfo.icon}</Text>
                    <Text style={styles.catChipText}>{catInfo.label}</Text>
                  </View>
                )}
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
                  <Ionicons name="scale-outline" size={12} color="#94A3B8" />
                  <Text style={styles.foodMeta}>{item.portionText ?? `${item.portion}g`}</Text>
                </View>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
                  <Ionicons name="analytics-outline" size={12} color="#94A3B8" />
                  <Text style={styles.foodMeta}>
                    GL <Text style={{ fontWeight: '800', color: t.dot }}>{item.glycemicLoad}</Text>
                  </Text>
                </View>
              </View>
            </View>
            <View style={[styles.trafficBadge, { backgroundColor: t.bg }]}>
              <View style={[styles.trafficDot, { backgroundColor: t.dot }]} />
              <Text style={[styles.trafficLabel, { color: t.text }]}>{t.label}</Text>
            </View>
          </View>
        );
      })}
    </View>
  );
}

// ── Ana Ekran ─────────────────────────────────────────────────

export default function DailyLogScreen() {
  const insets = useSafeAreaInsets();
  const { dailyLog, clearDailyLog } = useAppStore();

  const totalGL  = Math.round(dailyLog.reduce((s, e) => s + e.glycemicLoad, 0) * 10) / 10;
  const greenCnt = dailyLog.filter(e => e.trafficLight === 'green').length;
  const redCnt   = dailyLog.filter(e => e.trafficLight === 'red').length;

  // Öğüne göre grupla
  const grouped: Partial<Record<MealType, DailyLogEntry[]>> = {};
  const noMeal: DailyLogEntry[] = [];

  dailyLog.forEach(entry => {
    if (entry.mealType) {
      if (!grouped[entry.mealType]) grouped[entry.mealType] = [];
      grouped[entry.mealType]!.push(entry);
    } else {
      noMeal.push(entry);
    }
  });

  const hasGrouped = Object.keys(grouped).length > 0;

  return (
    <View style={{ flex: 1, backgroundColor: '#F5F7FA' }}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 40 }}>
        {/* ── Header ── */}
        <LinearGradient
          colors={['#063830', '#0A5748', '#0D7A6B']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={{ paddingTop: insets.top + 16, paddingBottom: 28, paddingHorizontal: 22, borderBottomLeftRadius: 36, borderBottomRightRadius: 36, marginBottom: 20, shadowColor: '#052E28', shadowOffset: { width: 0, height: 10 }, shadowOpacity: 0.22, shadowRadius: 18, elevation: 12 }}
        >
          <View style={styles.deco1} pointerEvents="none" />

          <View style={{ flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between' }}>
            <View>
              <Text style={styles.headerEyebrow}>Bugünün Kaydı</Text>
              <Text style={styles.headerTitle}>Günlük 📋</Text>
            </View>
            {dailyLog.length > 0 && (
              <TouchableOpacity onPress={clearDailyLog} style={styles.clearBtn}>
                <Ionicons name="trash-outline" size={16} color="#FCA5A5" />
                <Text style={styles.clearBtnText}>Temizle</Text>
              </TouchableOpacity>
            )}
          </View>

          {/* Özet chipları */}
          {dailyLog.length > 0 && (
            <View style={{ flexDirection: 'row', gap: 10, marginTop: 20 }}>
              <View style={styles.statChip}>
                <Text style={[styles.statVal, { color: glColor(totalGL) }]}>{totalGL}</Text>
                <Text style={styles.statLbl}>Toplam GL</Text>
              </View>
              <View style={styles.statChip}>
                <Text style={[styles.statVal, { color: '#0F172A' }]}>{dailyLog.length}</Text>
                <Text style={styles.statLbl}>Kayıt</Text>
              </View>
              <View style={styles.statChip}>
                <Text style={[styles.statVal, { color: '#10B981' }]}>{greenCnt}</Text>
                <Text style={styles.statLbl}>Güvenli</Text>
              </View>
              {redCnt > 0 && (
                <View style={styles.statChip}>
                  <Text style={[styles.statVal, { color: '#EF4444' }]}>{redCnt}</Text>
                  <Text style={styles.statLbl}>Riskli</Text>
                </View>
              )}
            </View>
          )}
        </LinearGradient>

        {/* Boş durum */}
        {dailyLog.length === 0 && (
          <View style={{ alignItems: 'center', paddingTop: 60, paddingHorizontal: 40 }}>
            <View style={styles.emptyIcon}>
              <Ionicons name="journal-outline" size={36} color="#0D7A6B" />
            </View>
            <Text style={styles.emptyTitle}>Henüz kayıt yok</Text>
            <Text style={styles.emptyDesc}>
              Öğünler sayfasından besin ekleyerek{'\n'}günlüğünüze kayıt ekleyin
            </Text>
          </View>
        )}

        {/* Öğüne göre gruplanmış kayıtlar */}
        {MEAL_ORDER.map(mealType => {
          const items = grouped[mealType];
          if (!items || items.length === 0) return null;
          return <MealSection key={mealType} mealType={mealType} items={items} />;
        })}

        {/* Öğünsüz eski kayıtlar (geriye dönük uyumluluk) */}
        {noMeal.length > 0 && (
          <View style={styles.mealSection}>
            <View style={[styles.mealHeader, { borderLeftColor: '#64748B' }]}>
              <Text style={{ fontSize: 20 }}>🍴</Text>
              <View style={{ flex: 1, marginLeft: 10 }}>
                <Text style={styles.mealHeaderTitle}>Diğer Kayıtlar</Text>
                <Text style={styles.mealHeaderSub}>{noMeal.length} besin</Text>
              </View>
            </View>
            {noMeal.map(item => {
              const t = TRAFFIC[item.trafficLight] ?? TRAFFIC.green;
              return (
                <View key={item.id} style={styles.foodCard}>
                  <View style={[styles.foodCardAccent, { backgroundColor: t.dot }]} />
                  <View style={{ flex: 1, paddingLeft: 12 }}>
                    <Text style={styles.foodName} numberOfLines={1}>{item.foodName}</Text>
                    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 6 }}>
                      <Text style={styles.foodMeta}>{item.portionText ?? `${item.portion}g`}</Text>
                      <Text style={styles.foodMeta}>GL <Text style={{ fontWeight: '800', color: t.dot }}>{item.glycemicLoad}</Text></Text>
                    </View>
                  </View>
                  <View style={[styles.trafficBadge, { backgroundColor: t.bg }]}>
                    <View style={[styles.trafficDot, { backgroundColor: t.dot }]} />
                    <Text style={[styles.trafficLabel, { color: t.text }]}>{t.label}</Text>
                  </View>
                </View>
              );
            })}
          </View>
        )}

        {/* Günlük toplam analiz */}
        {dailyLog.length > 0 && (
          <View style={styles.analysisCard}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
              <Text style={styles.analysisTitle}>Günlük Analiz</Text>
              <Text style={[styles.analysisTotalGL, { color: glColor(totalGL) }]}>{totalGL} GL</Text>
            </View>

            {/* Öğün dağılımı */}
            {MEAL_ORDER.map(mt => {
              const items = grouped[mt];
              if (!items?.length) return null;
              const mGL = Math.round(items.reduce((s, e) => s + e.glycemicLoad, 0) * 10) / 10;
              const pct = totalGL > 0 ? Math.round((mGL / totalGL) * 100) : 0;
              const m   = MEAL_META[mt];
              return (
                <View key={mt} style={{ marginBottom: 10 }}>
                  <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 4 }}>
                    <Text style={{ fontSize: 13, fontWeight: '600', color: '#475569' }}>
                      {m.icon} {m.label}
                    </Text>
                    <Text style={{ fontSize: 13, fontWeight: '800', color: m.color }}>{mGL} GL</Text>
                  </View>
                  <View style={{ height: 6, backgroundColor: '#F1F5F9', borderRadius: 4, overflow: 'hidden' }}>
                    <View style={{ width: `${pct}%`, height: '100%', backgroundColor: m.color, borderRadius: 4 }} />
                  </View>
                </View>
              );
            })}

            <View style={{ height: 1, backgroundColor: '#E2E8F0', marginTop: 6, marginBottom: 14 }} />
            <Text style={{ fontSize: 13, color: '#64748B', textAlign: 'center', lineHeight: 20 }}>
              {totalGL < 10
                ? '✅ Mükemmel! Bugün GL hedefinin içindesiniz.'
                : totalGL < 20
                ? '⚡ Dikkat edin, GL birikmeye başladı.'
                : '⚠️ Yüksek GL günü. Yarın daha az karbonhidrat tüketmeyi planlayın.'}
            </Text>
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  deco1: {
    position: 'absolute', right: -20, top: -20,
    width: 160, height: 160, borderRadius: 80,
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
  headerEyebrow: { fontSize: 13, color: '#6EE7B7', fontWeight: '700', marginBottom: 4 },
  headerTitle:   { fontSize: 30, fontWeight: '900', color: '#FFFFFF' },
  clearBtn:      { flexDirection: 'row', alignItems: 'center', gap: 5, backgroundColor: 'rgba(239,68,68,0.18)', paddingHorizontal: 14, paddingVertical: 8, borderRadius: 12 },
  clearBtnText:  { fontSize: 13, fontWeight: '700', color: '#FCA5A5' },
  statChip:      { flex: 1, backgroundColor: '#FFFFFF', borderRadius: 14, paddingVertical: 12, alignItems: 'center' },
  statVal:       { fontSize: 22, fontWeight: '900', color: '#0F172A' },
  statLbl:       { fontSize: 10, fontWeight: '600', color: '#94A3B8', marginTop: 2 },

  emptyIcon:  { width: 80, height: 80, borderRadius: 40, backgroundColor: '#E8F5F3', alignItems: 'center', justifyContent: 'center', marginBottom: 18 },
  emptyTitle: { fontSize: 22, fontWeight: '800', color: '#0F172A', marginBottom: 8 },
  emptyDesc:  { fontSize: 15, color: '#64748B', textAlign: 'center', lineHeight: 24 },

  mealSection: { marginHorizontal: 16, marginBottom: 16 },
  mealHeader:  { flexDirection: 'row', alignItems: 'center', marginBottom: 10, paddingLeft: 12, borderLeftWidth: 4, borderRadius: 2 },
  mealHeaderTitle: { fontSize: 16, fontWeight: '800', color: '#0F172A' },
  mealHeaderSub:   { fontSize: 12, color: '#94A3B8', fontWeight: '500', marginTop: 1 },
  mealGlBadge:     { paddingHorizontal: 14, paddingVertical: 8, borderRadius: 12, alignItems: 'center' },
  mealGlBadgeVal:  { fontSize: 22, fontWeight: '900' },
  mealGlBadgeLbl:  { fontSize: 10, fontWeight: '700', marginTop: -2 },

  foodCard:       { backgroundColor: '#FFFFFF', borderRadius: 16, flexDirection: 'row', alignItems: 'stretch', paddingVertical: 14, paddingRight: 14, marginBottom: 8, shadowColor: '#0F172A', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.05, shadowRadius: 6, elevation: 2, overflow: 'hidden' },
  foodCardAccent: { width: 4, borderRadius: 2 },
  foodName:       { fontSize: 15, fontWeight: '800', color: '#0F172A' },
  foodMeta:       { fontSize: 12, color: '#64748B', fontWeight: '500' },
  catChip:        { flexDirection: 'row', alignItems: 'center', gap: 3, backgroundColor: '#F1F5F9', paddingHorizontal: 7, paddingVertical: 3, borderRadius: 7 },
  catChipText:    { fontSize: 10, fontWeight: '700', color: '#64748B' },
  trafficBadge:   { flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 10, paddingVertical: 5, borderRadius: 10, alignSelf: 'flex-start', margin: 14, marginLeft: 0 },
  trafficDot:     { width: 7, height: 7, borderRadius: 4 },
  trafficLabel:   { fontSize: 12, fontWeight: '800' },

  analysisCard: {
    marginHorizontal: 16, marginTop: 8, marginBottom: 20,
    backgroundColor: '#FFFFFF', borderRadius: 20, padding: 20,
    shadowColor: '#0F172A', shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05, shadowRadius: 8, elevation: 2,
  },
  analysisTitle:   { fontSize: 16, fontWeight: '800', color: '#0F172A' },
  analysisTotalGL: { fontSize: 28, fontWeight: '900' },
});
