import React from 'react';
import { View, Text, TouchableOpacity, ScrollView, Alert, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAppStore } from '../store/useAppStore';
import { useUserStore } from '../store/useUserStore';
import { useHealthStore } from '../store/useHealthStore';
import { GlTrendChart } from '../components/ui/GlTrendChart';
import { useNavigation } from '@react-navigation/native';
import { supabase } from '../lib/supabase';
import {
  calculateAge,
  getBmiCategory,
  DIABETES_TYPE_LABELS,
  ACTIVITY_LEVEL_LABELS,
  GENDER_LABELS,
} from '../utils/healthCalculations';
import { getGradeColor, getGradeEmoji } from '../utils/healthScore';

export default function ProfileScreen() {
  const insets = useSafeAreaInsets();
  const { isPremium } = useAppStore();
  const { profile, bmi, dailyCarbLimit, glThresholds, resetProfile } = useUserStore();
  const { healthScore } = useHealthStore();
  const navigation = useNavigation<any>();

  const bmiInfo = bmi > 0 ? getBmiCategory(bmi) : null;
  const age = profile ? calculateAge(profile.birthYear) : 0;

  const handleResetProfile = () => {
    Alert.alert(
      'Profili Sıfırla',
      'Profil bilgileriniz silinecek ve yeniden giriş ekranına yönlendirileceksiniz. Emin misiniz?',
      [
        { text: 'İptal', style: 'cancel' },
        {
          text: 'Sıfırla',
          style: 'destructive',
          onPress: () => resetProfile(),
        },
      ]
    );
  };

  const handleSignOut = () => {
    Alert.alert(
      'Çıkış Yap',
      'Hesabınızdan çıkış yapmak istediğinize emin misiniz?',
      [
        { text: 'İptal', style: 'cancel' },
        {
          text: 'Çıkış Yap',
          style: 'destructive',
          onPress: async () => {
            await supabase.auth.signOut();
          },
        },
      ]
    );
  };

  const menuItems = [
    { icon: 'settings-outline' as const, label: 'Ayarlar', route: 'Settings' },
    { icon: 'information-circle-outline' as const, label: 'Hakkında', route: 'About' },
  ];

  return (
    <ScrollView style={{ flex: 1, backgroundColor: '#F5F7FA' }} showsVerticalScrollIndicator={false}>
      <LinearGradient
        colors={['#063830', '#0A5748', '#0D7A6B']}
        start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
        style={{
          paddingTop: insets.top + 20, paddingBottom: 36,
          paddingHorizontal: 24,
          borderBottomLeftRadius: 36, borderBottomRightRadius: 36,
          alignItems: 'center',
          shadowColor: '#052E28', shadowOffset: { width: 0, height: 10 },
          shadowOpacity: 0.22, shadowRadius: 18, elevation: 12,
        }}
      >
        {/* Dekoratif halka */}
        <View style={{ position: 'absolute', right: -20, top: -20, width: 160, height: 160, borderRadius: 80, backgroundColor: 'rgba(255,255,255,0.05)' }} pointerEvents="none" />

        {/* Avatar */}
        <View style={{
          width: 88, height: 88, borderRadius: 44,
          backgroundColor: 'rgba(255,255,255,0.15)',
          borderWidth: 2, borderColor: 'rgba(255,255,255,0.25)',
          alignItems: 'center', justifyContent: 'center', marginBottom: 14,
        }}>
          <Ionicons name="person" size={40} color="#FFFFFF" />
        </View>
        <Text style={{ fontSize: 26, fontWeight: '900', color: '#FFFFFF', letterSpacing: -0.3 }}>
          {profile ? profile.fullName : 'Profil'}
        </Text>
        <Text style={{ fontSize: 14, color: '#A7F3D0', marginTop: 5, fontWeight: '600' }}>
          {profile ? `${age} yaş · ${GENDER_LABELS[profile.gender]}` : 'Hesap ayarlarınız'}
        </Text>
      </LinearGradient>

      <View style={{ paddingHorizontal: 20, paddingTop: 20, paddingBottom: 40 }}>

        {/* ── Sağlık Özet Kartı ─────────────────────────────── */}
        {profile && (
          <View style={{
            backgroundColor: '#FFFFFF',
            borderRadius: 24,
            padding: 24,
            marginBottom: 20,
            shadowColor: '#000',
            shadowOffset: { width: 0, height: 4 },
            shadowOpacity: 0.08,
            shadowRadius: 12,
            elevation: 4,
          }}>
            <Text style={{ fontSize: 18, fontWeight: '800', color: '#1A1A1A', marginBottom: 20 }}>
              🩺 Sağlık Profili
            </Text>

            {/* VKİ + Fiziksel */}
            <View style={{ flexDirection: 'row', marginBottom: 20 }}>
              <View style={{ flex: 1, alignItems: 'center', backgroundColor: (bmiInfo?.color || '#10B981') + '10', borderRadius: 16, padding: 16, marginRight: 10 }}>
                <Text style={{ fontSize: 36, fontWeight: '900', color: bmiInfo?.color || '#10B981' }}>{bmi}</Text>
                <Text style={{ fontSize: 13, fontWeight: '700', color: '#666', marginTop: 4 }}>VKİ</Text>
                {bmiInfo && (
                  <View style={{ backgroundColor: bmiInfo.color + '20', paddingHorizontal: 12, paddingVertical: 4, borderRadius: 12, marginTop: 6 }}>
                    <Text style={{ fontSize: 12, fontWeight: '700', color: bmiInfo.color }}>{bmiInfo.emoji} {bmiInfo.label}</Text>
                  </View>
                )}
              </View>
              <View style={{ flex: 1 }}>
                <View style={{ backgroundColor: '#F8F9FA', borderRadius: 14, padding: 14, marginBottom: 10 }}>
                  <Text style={{ fontSize: 12, fontWeight: '600', color: '#999' }}>Boy</Text>
                  <Text style={{ fontSize: 20, fontWeight: '800', color: '#333' }}>{profile.heightCm} cm</Text>
                </View>
                <View style={{ backgroundColor: '#F8F9FA', borderRadius: 14, padding: 14 }}>
                  <Text style={{ fontSize: 12, fontWeight: '600', color: '#999' }}>Kilo</Text>
                  <Text style={{ fontSize: 20, fontWeight: '800', color: '#333' }}>{profile.weightKg} kg</Text>
                </View>
              </View>
            </View>

            {/* Diyabet + GL Eşikleri */}
            <View style={{ backgroundColor: '#FEF3C720', borderRadius: 16, padding: 16, marginBottom: 16, borderWidth: 1.5, borderColor: '#FDE68A' }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 10 }}>
                <Text style={{ fontSize: 20, marginRight: 8 }}>
                  {profile.diabetesType === 'yok' ? '✅' : '💊'}
                </Text>
                <Text style={{ fontSize: 16, fontWeight: '800', color: '#1A1A1A' }}>
                  {DIABETES_TYPE_LABELS[profile.diabetesType]}
                </Text>
              </View>
              {profile.hba1c && (
                <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6 }}>
                  <Text style={{ fontSize: 14, color: '#666' }}>HbA1c</Text>
                  <Text style={{ fontSize: 14, fontWeight: '700', color: profile.hba1c > 7 ? '#DC2626' : '#059669' }}>%{profile.hba1c}</Text>
                </View>
              )}
              {profile.fastingGlucose && (
                <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6 }}>
                  <Text style={{ fontSize: 14, color: '#666' }}>Açlık Kan Şekeri</Text>
                  <Text style={{ fontSize: 14, fontWeight: '700', color: profile.fastingGlucose > 126 ? '#DC2626' : '#059669' }}>{profile.fastingGlucose} mg/dL</Text>
                </View>
              )}
              <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                <Text style={{ fontSize: 14, color: '#666' }}>Aktivite</Text>
                <Text style={{ fontSize: 14, fontWeight: '700', color: '#333' }}>{ACTIVITY_LEVEL_LABELS[profile.activityLevel]}</Text>
              </View>
            </View>

            {/* Kişisel Limitler */}
            <View style={{ flexDirection: 'row', gap: 10 }}>
              <View style={{ flex: 1, backgroundColor: '#ECFDF5', borderRadius: 14, padding: 14, alignItems: 'center' }}>
                <Text style={{ fontSize: 24, fontWeight: '900', color: '#059669' }}>{dailyCarbLimit}g</Text>
                <Text style={{ fontSize: 11, fontWeight: '600', color: '#059669', marginTop: 4, textAlign: 'center' }}>Günlük Karb Limiti</Text>
              </View>
              <View style={{ flex: 1, backgroundColor: '#FEF3C7', borderRadius: 14, padding: 14, alignItems: 'center' }}>
                <Text style={{ fontSize: 24, fontWeight: '900', color: '#92400E' }}>{glThresholds.yellowThreshold}</Text>
                <Text style={{ fontSize: 11, fontWeight: '600', color: '#92400E', marginTop: 4, textAlign: 'center' }}>GL Dikkat Eşiği</Text>
              </View>
              <View style={{ flex: 1, backgroundColor: '#FEE2E2', borderRadius: 14, padding: 14, alignItems: 'center' }}>
                <Text style={{ fontSize: 24, fontWeight: '900', color: '#DC2626' }}>{glThresholds.redThreshold}</Text>
                <Text style={{ fontSize: 11, fontWeight: '600', color: '#DC2626', marginTop: 4, textAlign: 'center' }}>GL Risk Eşiği</Text>
              </View>
            </View>
          </View>
        )}

        {/* ── Premium Kartı ────────────────────────────────── */}
        <TouchableOpacity
          activeOpacity={0.8}
          onPress={() => !isPremium && navigation.navigate('Premium')}
          style={{ borderRadius: 20, marginBottom: 20, overflow: 'hidden' }}
        >
          {isPremium ? (
            <View style={{ backgroundColor: '#D1FAE5', padding: 20, borderRadius: 20, borderWidth: 2, borderColor: '#10B981', flexDirection: 'row', alignItems: 'center' }}>
              <View style={{ width: 52, height: 52, borderRadius: 26, backgroundColor: '#10B981', alignItems: 'center', justifyContent: 'center', marginRight: 16 }}>
                <Ionicons name="diamond" size={26} color="#FFF" />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={{ fontSize: 18, fontWeight: '900', color: '#064E3B' }}>Premium Üye ✨</Text>
                <Text style={{ fontSize: 13, color: '#065F46', marginTop: 3 }}>Tüm özelliklere erişiminiz var</Text>
              </View>
            </View>
          ) : (
            <LinearGradient colors={['#0D1B3E', '#1E3A5F', '#0D7A6B']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={{ padding: 20, borderRadius: 20, flexDirection: 'row', alignItems: 'center' }}>
              <View style={{ width: 52, height: 52, borderRadius: 26, backgroundColor: 'rgba(245,158,11,0.2)', alignItems: 'center', justifyContent: 'center', marginRight: 16, borderWidth: 2, borderColor: '#F59E0B' }}>
                <Ionicons name="diamond" size={26} color="#F59E0B" />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={{ fontSize: 18, fontWeight: '900', color: '#FFF' }}>Premium'a Geçin</Text>
                <Text style={{ fontSize: 12, color: 'rgba(255,255,255,0.7)', marginTop: 3 }}>AI Koç · Fotoğraf Analizi · Sınırsız Kayıt</Text>
              </View>
              <View style={{ backgroundColor: '#F59E0B', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 12 }}>
                <Text style={{ fontSize: 11, fontWeight: '900', color: '#000' }}>BAŞLA</Text>
              </View>
            </LinearGradient>
          )}
        </TouchableOpacity>

        {/* ── Günlük Sağlık Skoru ───────────────────────────── */}
        {healthScore && (
          <View style={{
            backgroundColor: '#FFFFFF',
            borderRadius: 20,
            padding: 20,
            marginBottom: 20,
            shadowColor: '#000',
            shadowOffset: { width: 0, height: 3 },
            shadowOpacity: 0.06,
            shadowRadius: 8,
            elevation: 3,
          }}>
            <Text style={{ fontSize: 17, fontWeight: '800', color: '#1A1A1A', marginBottom: 16 }}>
              Günlük Sağlık Skoru
            </Text>
            <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 16 }}>
              <View style={{
                width: 72, height: 72, borderRadius: 36,
                backgroundColor: getGradeColor(healthScore.grade) + '15',
                alignItems: 'center', justifyContent: 'center',
                marginRight: 16,
                borderWidth: 3,
                borderColor: getGradeColor(healthScore.grade),
              }}>
                <Text style={{ fontSize: 26, fontWeight: '900', color: getGradeColor(healthScore.grade) }}>
                  {healthScore.grade}
                </Text>
              </View>
              <View style={{ flex: 1 }}>
                <Text style={{ fontSize: 32, fontWeight: '900', color: getGradeColor(healthScore.grade) }}>
                  {healthScore.totalScore}
                  <Text style={{ fontSize: 16, fontWeight: '600', color: '#A0A0A0' }}>/100</Text>
                </Text>
                <Text style={{ fontSize: 13, color: '#666', marginTop: 2 }}>
                  {getGradeEmoji(healthScore.grade)} {
                    healthScore.grade === 'A' ? 'Mükemmel gün!' :
                    healthScore.grade === 'B' ? 'Çok iyi devam et' :
                    healthScore.grade === 'C' ? 'İyileştirilebilir' :
                    healthScore.grade === 'D' ? 'Dikkat gerektiriyor' : 'Yarın daha iyi!'
                  }
                </Text>
              </View>
            </View>
            {/* Bileşen çubukları */}
            {([
              { label: 'Beslenme', val: healthScore.breakdown.nutrition, color: '#10B981' },
              { label: 'Uyku', val: healthScore.breakdown.sleep, color: '#8B5CF6' },
              { label: 'Ruh Hali', val: healthScore.breakdown.mood, color: '#F59E0B' },
              { label: 'Hidrasyon', val: healthScore.breakdown.hydration, color: '#0EA5E9' },
              { label: 'Kafein', val: healthScore.breakdown.caffeine, color: '#6B7280' },
            ] as const).map((item) => (
              <View key={item.label} style={{ marginBottom: 8 }}>
                <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 4 }}>
                  <Text style={{ fontSize: 12, fontWeight: '600', color: '#666' }}>{item.label}</Text>
                  <Text style={{ fontSize: 12, fontWeight: '700', color: item.color }}>{item.val}</Text>
                </View>
                <View style={{ height: 6, backgroundColor: '#F0F0F0', borderRadius: 3, overflow: 'hidden' }}>
                  <View style={{ width: `${item.val}%`, height: '100%', backgroundColor: item.color, borderRadius: 3 }} />
                </View>
              </View>
            ))}
            {healthScore.insights.length > 0 && (
              <View style={{ marginTop: 12, backgroundColor: '#FEF3C7', borderRadius: 12, padding: 12 }}>
                <Text style={{ fontSize: 13, color: '#92400E', fontWeight: '600', lineHeight: 20 }}>
                  {healthScore.insights[0]}
                </Text>
              </View>
            )}
          </View>
        )}

        <GlTrendChart />

        {/* ── Menü Listesi ─────────────────────────────────── */}
        <View style={{ backgroundColor: '#FFFFFF', borderRadius: 16, overflow: 'hidden', marginTop: 24 }}>
          {menuItems.map((item, idx) => (
            <TouchableOpacity
              key={item.label}
              activeOpacity={0.7}
              onPress={() => navigation.navigate(item.route)}
              style={{ flexDirection: 'row', alignItems: 'center', paddingHorizontal: 18, paddingVertical: 18, minHeight: 64, borderTopWidth: idx > 0 ? 1 : 0, borderTopColor: '#F0F0F0' }}
            >
              <View style={{ width: 44, height: 44, borderRadius: 14, backgroundColor: '#E0F2FE', alignItems: 'center', justifyContent: 'center', marginRight: 16 }}>
                <Ionicons name={item.icon} size={22} color="#0284C7" />
              </View>
              <Text style={{ fontSize: 17, fontWeight: '600', color: '#212121', flex: 1 }}>{item.label}</Text>
              <Ionicons name="chevron-forward" size={20} color="#D4D4D4" />
            </TouchableOpacity>
          ))}
        </View>

        {/* ── Profili Sıfırla ──────────────────────────────── */}
        {profile && (
          <TouchableOpacity
            activeOpacity={0.7}
            onPress={handleResetProfile}
            style={{
              marginTop: 24,
              backgroundColor: '#FEE2E2',
              borderRadius: 16,
              padding: 16,
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <Ionicons name="refresh-outline" size={20} color="#DC2626" style={{ marginRight: 8 }} />
            <Text style={{ fontSize: 15, fontWeight: '700', color: '#DC2626' }}>Profili Sıfırla & Yeniden Ayarla</Text>
          </TouchableOpacity>
        )}

        {/* ── Çıkış Yap ─────────────────────────────────── */}
        <TouchableOpacity
          activeOpacity={0.7}
          onPress={handleSignOut}
          style={{
            marginTop: 16,
            backgroundColor: '#FFFFFF',
            borderRadius: 16,
            padding: 16,
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'center',
            borderWidth: 1.5,
            borderColor: '#E8E8E8',
          }}
        >
          <Ionicons name="log-out-outline" size={20} color="#EF4444" style={{ marginRight: 8 }} />
          <Text style={{ fontSize: 15, fontWeight: '700', color: '#EF4444' }}>Çıkış Yap</Text>
        </TouchableOpacity>

        <Text style={{ textAlign: 'center', fontSize: 13, color: '#A0A0A0', marginTop: 24 }}>GlikoFit v1.1.0</Text>
      </View>
    </ScrollView>
  );
}