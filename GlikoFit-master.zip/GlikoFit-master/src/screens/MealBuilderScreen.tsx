import React, { useState, useEffect } from 'react';
import {
  View, Text, FlatList, TouchableOpacity, TextInput,
  ActivityIndicator, Alert, Modal, StyleSheet,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Slider from '@react-native-community/slider';
import { supabase } from '../lib/supabase';
import type { Food } from '../types/database';
import { useAppStore } from '../store/useAppStore';
import { getCarbsPer100g } from '../lib/fatsecret';
import { scheduleHighGLNotification } from '../services/notificationService';

interface MealItem {
  id: string;
  food: Food;
  portion: number;
  carbs100: number;
}

function glColor(gl: number): string {
  if (gl >= 20) return '#EF4444';
  if (gl >= 10) return '#F59E0B';
  return '#10B981';
}

export default function MealBuilderScreen({ navigation }: any) {
  const insets = useSafeAreaInsets();
  const { addToDailyLog } = useAppStore();

  const [mealItems, setMealItems]         = useState<MealItem[]>([]);
  const [searchQuery, setSearchQuery]     = useState('');
  const [searchResults, setSearchResults] = useState<Food[]>([]);
  const [isSearching, setIsSearching]     = useState(false);
  const [selectedFood, setSelectedFood]   = useState<Food | null>(null);
  const [portion, setPortion]             = useState(100);
  const [tempCarbs100, setTempCarbs100]   = useState<number | null>(null);
  const [fetchingCarbs, setFetchingCarbs] = useState(false);

  const totalGL = Math.round(
    mealItems.reduce((acc, item) => {
      const carbs = (item.carbs100 / 100) * item.portion;
      return acc + (item.food.gi_value * carbs) / 100;
    }, 0) * 10
  ) / 10;

  const currentGlColor = glColor(totalGL);

  // Arama debounce
  useEffect(() => {
    if (searchQuery.length < 2) { setSearchResults([]); return; }
    const timer = setTimeout(async () => {
      setIsSearching(true);
      const { data } = await supabase.from('foods').select('*').ilike('name', `%${searchQuery}%`).limit(6);
      setSearchResults(data || []);
      setIsSearching(false);
    }, 400);
    return () => clearTimeout(timer);
  }, [searchQuery]);

  const openModal = async (food: Food) => {
    setSelectedFood(food);
    setPortion(100);
    if (food.carbs_per_100g > 0) {
      setTempCarbs100(food.carbs_per_100g);
    } else {
      setFetchingCarbs(true);
      const c = await getCarbsPer100g(food.name);
      setTempCarbs100(c ?? 0);
      setFetchingCarbs(false);
    }
  };

  const confirmAdd = () => {
    if (!selectedFood || tempCarbs100 === null) return;
    setMealItems(prev => [...prev, {
      id: `${Date.now()}-${Math.random()}`,
      food: selectedFood, portion, carbs100: tempCarbs100,
    }]);
    setSelectedFood(null);
    setSearchQuery('');
    setSearchResults([]);
  };

  const removeItem = (id: string) => setMealItems(prev => prev.filter(i => i.id !== id));

  const handleSave = () => {
    if (mealItems.length === 0) return;
    mealItems.forEach(item => {
      const carbs = (item.carbs100 / 100) * item.portion;
      const gl    = Math.round((item.food.gi_value * carbs) / 100 * 10) / 10;
      const status: 'green' | 'yellow' | 'red' = gl >= 20 ? 'red' : gl >= 10 ? 'yellow' : 'green';
      addToDailyLog({
        foodId: item.food.id.toString(),
        foodName: item.food.name,
        portion: item.portion,
        portionText: `${item.portion}g`,
        glycemicLoad: gl,
        trafficLight: status,
      });
    });
    if (totalGL >= 20) scheduleHighGLNotification();
    Alert.alert('Başarılı', 'Tabağınızdaki besinler günlüğe eklendi!');
    setMealItems([]);
    navigation.navigate('DailyLog');
  };

  // Anlık GL (modal için)
  const modalGL = selectedFood && tempCarbs100 !== null
    ? Math.round((selectedFood.gi_value * (tempCarbs100 / 100) * portion) / 100 * 10) / 10
    : 0;
  const modalGlColor = glColor(modalGL);

  return (
    <View style={{ flex: 1, backgroundColor: '#F5F7FA' }}>
      <FlatList
        data={mealItems}
        keyExtractor={item => item.id}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: mealItems.length > 0 ? 220 : 120 }}
        keyboardShouldPersistTaps="handled"

        ListHeaderComponent={
          <View>
            {/* Header */}
            <LinearGradient
              colors={['#063830', '#0A5748', '#0D7A6B']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={[styles.header, { paddingTop: insets.top + 16 }]}
            >
              <View style={styles.deco} pointerEvents="none" />
              <Text style={styles.eyebrow}>Öğün Hazırlıyorsunuz</Text>
              <Text style={styles.title}>Tabağım 🍽️</Text>
              <Text style={styles.subtitle}>Birden fazla besin ekleyip toplam GL'yi görün</Text>

              {/* GL özet (ürün varsa) */}
              {mealItems.length > 0 && (
                <View style={[styles.glBadge, { borderColor: currentGlColor + '50' }]}>
                  <Text style={styles.glBadgeLabel}>Toplam GL</Text>
                  <Text style={[styles.glBadgeVal, { color: currentGlColor }]}>{totalGL}</Text>
                  <Text style={[styles.glBadgeStatus, { color: currentGlColor }]}>
                    {totalGL >= 20 ? 'Riskli' : totalGL >= 10 ? 'Dikkat' : 'Güvenli'}
                  </Text>
                </View>
              )}
            </LinearGradient>

            {/* Arama kutusu */}
            <View style={styles.searchWrap}>
              <View style={styles.searchBox}>
                <Ionicons name="search" size={20} color={searchQuery ? '#0D7A6B' : '#94A3B8'} style={{ marginRight: 10 }} />
                <TextInput
                  style={styles.searchInput}
                  placeholder="Tabağa besin ekle..."
                  placeholderTextColor="#94A3B8"
                  value={searchQuery}
                  onChangeText={setSearchQuery}
                  autoCapitalize="none"
                  autoCorrect={false}
                />
                {isSearching && <ActivityIndicator size="small" color="#0D7A6B" />}
                {searchQuery.length > 0 && !isSearching && (
                  <TouchableOpacity onPress={() => { setSearchQuery(''); setSearchResults([]); }}>
                    <Ionicons name="close-circle" size={20} color="#94A3B8" />
                  </TouchableOpacity>
                )}
              </View>

              {/* Arama sonuçları */}
              {searchResults.length > 0 && (
                <View style={styles.resultCard}>
                  {searchResults.map((r, idx) => {
                    const c = r.gi_value >= 70 ? '#EF4444' : r.gi_value >= 56 ? '#F59E0B' : '#10B981';
                    return (
                      <TouchableOpacity
                        key={r.id}
                        onPress={() => openModal(r)}
                        style={[styles.resultRow, idx < searchResults.length - 1 && { borderBottomWidth: 1, borderBottomColor: '#F1F5F9' }]}
                      >
                        <View style={{ flex: 1 }}>
                          <Text style={styles.resultName} numberOfLines={1}>{r.name}</Text>
                          <Text style={styles.resultMeta}>{r.category}</Text>
                        </View>
                        <View style={[styles.giBadge, { backgroundColor: c + '18' }]}>
                          <Text style={[styles.giText, { color: c }]}>Gİ {r.gi_value}</Text>
                        </View>
                        <Ionicons name="add-circle" size={28} color="#0D7A6B" style={{ marginLeft: 10 }} />
                      </TouchableOpacity>
                    );
                  })}
                </View>
              )}
            </View>

            {/* Boş durum */}
            {mealItems.length === 0 && (
              <View style={styles.emptyWrap}>
                <View style={styles.emptyIcon}>
                  <Ionicons name="restaurant-outline" size={38} color="#0D7A6B" />
                </View>
                <Text style={styles.emptyTitle}>Tabağınız boş</Text>
                <Text style={styles.emptyDesc}>Yukarıdan besin arayarak tabağınızı oluşturun</Text>
              </View>
            )}

            {mealItems.length > 0 && (
              <Text style={styles.sectionLabel}>Tabağınızdakiler ({mealItems.length} besin)</Text>
            )}
          </View>
        }

        renderItem={({ item }) => {
          const carbs  = (item.carbs100 / 100) * item.portion;
          const itemGL = Math.round((item.food.gi_value * carbs) / 100 * 10) / 10;
          const c      = glColor(itemGL);

          return (
            <View style={styles.mealCard}>
              <View style={[styles.cardAccent, { backgroundColor: c }]} />
              <View style={{ flex: 1, paddingLeft: 14 }}>
                <Text style={styles.mealName} numberOfLines={1}>{item.food.name}</Text>
                <Text style={styles.mealMeta}>{item.portion}g · Gİ {item.food.gi_value} · {Math.round(item.carbs100 * item.portion / 100 * 10) / 10}g karb</Text>
              </View>
              <View style={{ alignItems: 'flex-end', gap: 6 }}>
                <Text style={[styles.mealGL, { color: c }]}>GL {itemGL}</Text>
                <TouchableOpacity onPress={() => removeItem(item.id)} style={styles.removeBtn}>
                  <Ionicons name="trash-outline" size={16} color="#EF4444" />
                </TouchableOpacity>
              </View>
            </View>
          );
        }}
      />

      {/* Sabit alt özet + kaydet */}
      {mealItems.length > 0 && (
        <View style={[styles.summaryBar, { paddingBottom: insets.bottom + 16 }]}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
            <Text style={{ fontSize: 16, fontWeight: '700', color: '#475569' }}>Toplam GL</Text>
            <Text style={[{ fontSize: 40, fontWeight: '900' }, { color: currentGlColor }]}>
              {totalGL}
            </Text>
          </View>
          <TouchableOpacity onPress={handleSave} style={{ borderRadius: 18, overflow: 'hidden' }}>
            <LinearGradient
              colors={['#0A5748', '#0D7A6B']}
              start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
              style={styles.saveBtn}
            >
              <Ionicons name="checkmark-circle" size={22} color="#FFF" style={{ marginRight: 8 }} />
              <Text style={styles.saveBtnText}>Günlüğe Kaydet</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      )}

      {/* Porsiyon Modalı */}
      <Modal visible={!!selectedFood} transparent animationType="fade">
        <View style={styles.overlay}>
          <View style={styles.modal}>
            <Text style={styles.modalTitle}>{selectedFood?.name}</Text>

            {fetchingCarbs ? (
              <View style={{ paddingVertical: 32 }}>
                <ActivityIndicator size="large" color="#0D7A6B" />
                <Text style={{ textAlign: 'center', color: '#94A3B8', marginTop: 10 }}>Besin değerleri yükleniyor...</Text>
              </View>
            ) : (
              <>
                {/* GL göstergesi */}
                <View style={[styles.modalGlBox, { borderColor: modalGlColor + '40', backgroundColor: modalGlColor + '10' }]}>
                  <Text style={[styles.modalGlVal, { color: modalGlColor }]}>{modalGL}</Text>
                  <Text style={[styles.modalGlLbl, { color: modalGlColor }]}>GL</Text>
                </View>

                <Text style={styles.modalPortionVal}>{portion} gram</Text>
                <Slider
                  style={{ width: '100%', height: 44, marginVertical: 12 }}
                  minimumValue={10}
                  maximumValue={500}
                  step={5}
                  value={portion}
                  onValueChange={setPortion}
                  minimumTrackTintColor="#0D7A6B"
                  maximumTrackTintColor="#E2E8F0"
                  thumbTintColor="#0D7A6B"
                />
                <View style={{ flexDirection: 'row', gap: 10, marginTop: 8 }}>
                  <TouchableOpacity onPress={() => setSelectedFood(null)} style={styles.modalBtnCancel}>
                    <Text style={styles.modalBtnCancelText}>İptal</Text>
                  </TouchableOpacity>
                  <TouchableOpacity onPress={confirmAdd} style={{ flex: 2, borderRadius: 16, overflow: 'hidden' }}>
                    <LinearGradient colors={['#0A5748', '#0D7A6B']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={styles.modalBtnAdd}>
                      <Ionicons name="add-circle" size={20} color="#FFF" style={{ marginRight: 6 }} />
                      <Text style={styles.modalBtnAddText}>Tabağa Ekle</Text>
                    </LinearGradient>
                  </TouchableOpacity>
                </View>
              </>
            )}
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    paddingBottom: 28, paddingHorizontal: 22,
    borderBottomLeftRadius: 36, borderBottomRightRadius: 36,
    marginBottom: 0,
    shadowColor: '#052E28', shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.22, shadowRadius: 18, elevation: 12,
  },
  deco: {
    position: 'absolute', right: -20, top: -20,
    width: 150, height: 150, borderRadius: 75,
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
  eyebrow: { fontSize: 13, color: '#6EE7B7', fontWeight: '700', marginBottom: 4 },
  title: { fontSize: 30, fontWeight: '900', color: '#FFFFFF', marginBottom: 4 },
  subtitle: { fontSize: 14, color: 'rgba(255,255,255,0.7)', fontWeight: '500' },

  glBadge: {
    marginTop: 16, backgroundColor: '#FFFFFF',
    borderRadius: 16, paddingHorizontal: 20, paddingVertical: 14,
    flexDirection: 'row', alignItems: 'center', gap: 12,
    borderWidth: 1.5,
  },
  glBadgeLabel: { fontSize: 14, fontWeight: '600', color: '#475569', flex: 1 },
  glBadgeVal: { fontSize: 32, fontWeight: '900' },
  glBadgeStatus: { fontSize: 13, fontWeight: '700' },

  searchWrap: { paddingHorizontal: 16, marginTop: 16, marginBottom: 4, zIndex: 10 },
  searchBox: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: '#FFFFFF', borderRadius: 18,
    paddingHorizontal: 16, height: 54,
    shadowColor: '#0F172A', shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08, shadowRadius: 10, elevation: 4,
  },
  searchInput: { flex: 1, fontSize: 16, color: '#0F172A', fontWeight: '500' },
  resultCard: {
    backgroundColor: '#FFFFFF', borderRadius: 18, marginTop: 8,
    shadowColor: '#0F172A', shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08, shadowRadius: 10, elevation: 4,
    overflow: 'hidden',
  },
  resultRow: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 14 },
  resultName: { fontSize: 15, fontWeight: '700', color: '#0F172A' },
  resultMeta: { fontSize: 12, color: '#94A3B8', marginTop: 2 },
  giBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8 },
  giText: { fontSize: 12, fontWeight: '800' },

  emptyWrap: { alignItems: 'center', paddingTop: 56, paddingHorizontal: 40 },
  emptyIcon: { width: 84, height: 84, borderRadius: 42, backgroundColor: '#E8F5F3', alignItems: 'center', justifyContent: 'center', marginBottom: 18 },
  emptyTitle: { fontSize: 20, fontWeight: '800', color: '#0F172A', marginBottom: 8 },
  emptyDesc: { fontSize: 14, color: '#64748B', textAlign: 'center', lineHeight: 22 },

  sectionLabel: {
    fontSize: 13, fontWeight: '700', color: '#94A3B8',
    textTransform: 'uppercase', letterSpacing: 0.8,
    paddingHorizontal: 20, marginTop: 16, marginBottom: 10,
  },

  mealCard: {
    marginHorizontal: 16, marginBottom: 10,
    backgroundColor: '#FFFFFF', borderRadius: 18,
    flexDirection: 'row', alignItems: 'stretch',
    paddingVertical: 16, paddingRight: 16,
    shadowColor: '#0F172A', shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05, shadowRadius: 8, elevation: 2,
    overflow: 'hidden',
  },
  cardAccent: { width: 5, borderRadius: 3 },
  mealName: { fontSize: 16, fontWeight: '800', color: '#0F172A', marginBottom: 4 },
  mealMeta: { fontSize: 12, color: '#64748B', fontWeight: '500' },
  mealGL: { fontSize: 17, fontWeight: '900' },
  removeBtn: { padding: 6, backgroundColor: '#FEF2F2', borderRadius: 10 },

  summaryBar: {
    position: 'absolute', bottom: 0, left: 0, right: 0,
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 20, paddingTop: 20,
    borderTopLeftRadius: 28, borderTopRightRadius: 28,
    shadowColor: '#0F172A', shadowOffset: { width: 0, height: -8 },
    shadowOpacity: 0.1, shadowRadius: 18, elevation: 20,
  },
  saveBtn: { paddingVertical: 17, borderRadius: 18, flexDirection: 'row', justifyContent: 'center', alignItems: 'center' },
  saveBtnText: { fontSize: 17, fontWeight: '900', color: '#FFFFFF', letterSpacing: 0.3 },

  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.55)', justifyContent: 'center', alignItems: 'center', padding: 24 },
  modal: { width: '100%', backgroundColor: '#FFFFFF', borderRadius: 28, padding: 26, alignItems: 'center' },
  modalTitle: { fontSize: 20, fontWeight: '900', color: '#0F172A', textAlign: 'center', marginBottom: 20 },
  modalGlBox: {
    flexDirection: 'row', alignItems: 'baseline', gap: 6,
    paddingHorizontal: 28, paddingVertical: 14, borderRadius: 18,
    borderWidth: 2, marginBottom: 16,
  },
  modalGlVal: { fontSize: 48, fontWeight: '900' },
  modalGlLbl: { fontSize: 18, fontWeight: '700' },
  modalPortionVal: { fontSize: 26, fontWeight: '800', color: '#0F172A', marginBottom: 4 },
  modalBtnCancel: {
    flex: 1, paddingVertical: 16, backgroundColor: '#F1F5F9',
    borderRadius: 16, alignItems: 'center',
  },
  modalBtnCancelText: { fontSize: 16, fontWeight: '700', color: '#64748B' },
  modalBtnAdd: { paddingVertical: 16, flexDirection: 'row', justifyContent: 'center', alignItems: 'center' },
  modalBtnAddText: { fontSize: 16, fontWeight: '800', color: '#FFFFFF' },
});
