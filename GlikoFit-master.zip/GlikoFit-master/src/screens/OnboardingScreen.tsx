// ============================================================
// 🚀 Onboarding Ekranı — Çok Adımlı Kişisel Sağlık Profili
// ============================================================
import React, { useState, useRef } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  Dimensions,
  Animated,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useUserStore } from '../store/useUserStore';
import type {
  DiabetesType,
  ActivityLevel,
  Gender,
  UserHealthProfile,
} from '../utils/healthCalculations';
import {
  calculateBMI,
  getBmiCategory,
  DIABETES_TYPE_LABELS,
  ACTIVITY_LEVEL_LABELS,
  GENDER_LABELS,
} from '../utils/healthCalculations';

const { width: SCREEN_WIDTH } = Dimensions.get('window');
const TOTAL_STEPS = 4;

// ── Seçenek Bileşeni ────────────────────────────────────────
function OptionChip({
  label,
  selected,
  onPress,
  emoji,
}: {
  label: string;
  selected: boolean;
  onPress: () => void;
  emoji?: string;
}) {
  return (
    <TouchableOpacity
      activeOpacity={0.7}
      onPress={onPress}
      style={{
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: selected ? '#008A79' : '#FFFFFF',
        paddingVertical: 16,
        paddingHorizontal: 20,
        borderRadius: 16,
        marginBottom: 12,
        borderWidth: selected ? 0 : 1.5,
        borderColor: '#E8E8E8',
        shadowColor: selected ? '#008A79' : '#000',
        shadowOffset: { width: 0, height: 3 },
        shadowOpacity: selected ? 0.25 : 0.05,
        shadowRadius: 8,
        elevation: selected ? 4 : 1,
      }}
    >
      {emoji && (
        <Text style={{ fontSize: 22, marginRight: 12 }}>{emoji}</Text>
      )}
      <Text
        style={{
          fontSize: 16,
          fontWeight: '700',
          color: selected ? '#FFFFFF' : '#333',
          flex: 1,
        }}
      >
        {label}
      </Text>
      {selected && (
        <Ionicons name="checkmark-circle" size={24} color="#FFFFFF" />
      )}
    </TouchableOpacity>
  );
}

// ── Ana Bileşen ─────────────────────────────────────────────
export default function OnboardingScreen() {
  const insets = useSafeAreaInsets();
  const { completeOnboarding } = useUserStore();
  const progressAnim = useRef(new Animated.Value(0)).current;

  const [step, setStep] = useState(0);

  // Form state
  const [fullName, setFullName] = useState('');
  const [birthYear, setBirthYear] = useState('');
  const [gender, setGender] = useState<Gender | null>(null);
  const [heightCm, setHeightCm] = useState('');
  const [weightKg, setWeightKg] = useState('');
  const [diabetesType, setDiabetesType] = useState<DiabetesType | null>(null);
  const [hba1c, setHba1c] = useState('');
  const [fastingGlucose, setFastingGlucose] = useState('');
  const [activityLevel, setActivityLevel] = useState<ActivityLevel | null>(null);

  const animateProgress = (toStep: number) => {
    Animated.spring(progressAnim, {
      toValue: toStep / (TOTAL_STEPS - 1),
      useNativeDriver: false,
      friction: 8,
    }).start();
  };

  const goNext = () => {
    if (step === 0 && (!fullName.trim() || !birthYear || !gender)) {
      Alert.alert('Eksik Bilgi', 'Lütfen adınızı, doğum yılınızı ve cinsiyetinizi girin.');
      return;
    }
    if (step === 1 && (!heightCm || !weightKg)) {
      Alert.alert('Eksik Bilgi', 'Lütfen boy ve kilo bilgilerinizi girin.');
      return;
    }
    if (step === 2 && !diabetesType) {
      Alert.alert('Eksik Bilgi', 'Lütfen diyabet durumunuzu seçin.');
      return;
    }

    if (step < TOTAL_STEPS - 1) {
      const nextStep = step + 1;
      setStep(nextStep);
      animateProgress(nextStep);
    }
  };

  const goBack = () => {
    if (step > 0) {
      const prevStep = step - 1;
      setStep(prevStep);
      animateProgress(prevStep);
    }
  };

  const handleComplete = () => {
    if (!activityLevel) {
      Alert.alert('Eksik Bilgi', 'Lütfen aktivite seviyenizi seçin.');
      return;
    }

    const profile: UserHealthProfile = {
      fullName: fullName.trim(),
      birthYear: parseInt(birthYear) || 1990,
      gender: gender!,
      heightCm: parseFloat(heightCm) || 170,
      weightKg: parseFloat(weightKg) || 70,
      diabetesType: diabetesType!,
      hba1c: hba1c ? parseFloat(hba1c) : null,
      fastingGlucose: fastingGlucose ? parseFloat(fastingGlucose) : null,
      activityLevel: activityLevel!,
    };

    completeOnboarding(profile);
  };

  // ── Step Rendering ────────────────────────────────────────

  const renderStep0 = () => (
    <View>
      <Text style={styles.stepTitle}>👋 Hoş Geldiniz!</Text>
      <Text style={styles.stepSubtitle}>
        Sizi tanıyalım. Bu bilgiler besin önerilerinizi kişiselleştirmek için kullanılacak.
      </Text>

      <Text style={styles.inputLabel}>Adınız</Text>
      <TextInput
        style={styles.textInput}
        placeholder="Adınızı girin"
        placeholderTextColor="#A0A0A0"
        value={fullName}
        onChangeText={setFullName}
        autoCapitalize="words"
      />

      <Text style={styles.inputLabel}>Doğum Yılı</Text>
      <TextInput
        style={styles.textInput}
        placeholder="Örn: 1990"
        placeholderTextColor="#A0A0A0"
        value={birthYear}
        onChangeText={setBirthYear}
        keyboardType="number-pad"
        maxLength={4}
      />

      <Text style={styles.inputLabel}>Cinsiyet</Text>
      {(Object.keys(GENDER_LABELS) as Gender[]).map((g) => (
        <OptionChip
          key={g}
          label={GENDER_LABELS[g]}
          selected={gender === g}
          onPress={() => setGender(g)}
          emoji={g === 'erkek' ? '👨' : '👩'}
        />
      ))}
    </View>
  );

  const renderStep1 = () => {
    const h = parseFloat(heightCm) || 0;
    const w = parseFloat(weightKg) || 0;
    const bmi = h > 0 && w > 0 ? calculateBMI(w, h) : 0;
    const bmiInfo = bmi > 0 ? getBmiCategory(bmi) : null;

    return (
      <View>
        <Text style={styles.stepTitle}>📏 Fiziksel Bilgiler</Text>
        <Text style={styles.stepSubtitle}>
          Boy ve kilonuz VKİ hesaplaması ve karbonhidrat limiti belirleme için kullanılır.
        </Text>

        <Text style={styles.inputLabel}>Boy (cm)</Text>
        <TextInput
          style={styles.textInput}
          placeholder="Örn: 170"
          placeholderTextColor="#A0A0A0"
          value={heightCm}
          onChangeText={setHeightCm}
          keyboardType="numeric"
          maxLength={3}
        />

        <Text style={styles.inputLabel}>Kilo (kg)</Text>
        <TextInput
          style={styles.textInput}
          placeholder="Örn: 72"
          placeholderTextColor="#A0A0A0"
          value={weightKg}
          onChangeText={setWeightKg}
          keyboardType="numeric"
          maxLength={5}
        />

        {bmiInfo && (
          <View
            style={{
              backgroundColor: '#F8F9FA',
              borderRadius: 20,
              padding: 20,
              marginTop: 20,
              alignItems: 'center',
              borderWidth: 2,
              borderColor: bmiInfo.color + '30',
            }}
          >
            <Text style={{ fontSize: 14, fontWeight: '600', color: '#666', marginBottom: 6 }}>
              Vücut Kitle İndeksiniz (VKİ)
            </Text>
            <Text style={{ fontSize: 48, fontWeight: '900', color: bmiInfo.color }}>
              {bmi}
            </Text>
            <View
              style={{
                backgroundColor: bmiInfo.color + '20',
                paddingHorizontal: 16,
                paddingVertical: 6,
                borderRadius: 20,
                marginTop: 8,
              }}
            >
              <Text style={{ fontSize: 15, fontWeight: '700', color: bmiInfo.color }}>
                {bmiInfo.emoji} {bmiInfo.label}
              </Text>
            </View>
          </View>
        )}
      </View>
    );
  };

  const renderStep2 = () => (
    <View>
      <Text style={styles.stepTitle}>🩺 Diyabet Durumu</Text>
      <Text style={styles.stepSubtitle}>
        Diyabet tipiniz GL eşiklerini ve besin önerilerini doğrudan etkiler.
      </Text>

      {(Object.keys(DIABETES_TYPE_LABELS) as DiabetesType[]).map((dt) => {
        const emojis: Record<DiabetesType, string> = {
          tip1: '💉',
          tip2: '💊',
          prediyabet: '⚠️',
          gestasyonel: '🤰',
          yok: '✅',
        };
        return (
          <OptionChip
            key={dt}
            label={DIABETES_TYPE_LABELS[dt]}
            selected={diabetesType === dt}
            onPress={() => setDiabetesType(dt)}
            emoji={emojis[dt]}
          />
        );
      })}

      {diabetesType && diabetesType !== 'yok' && (
        <View style={{ marginTop: 16 }}>
          <Text style={styles.inputLabel}>Son HbA1c Değeri (%) — Opsiyonel</Text>
          <TextInput
            style={styles.textInput}
            placeholder="Örn: 6.5"
            placeholderTextColor="#A0A0A0"
            value={hba1c}
            onChangeText={setHba1c}
            keyboardType="decimal-pad"
            maxLength={4}
          />
          <Text style={{ fontSize: 12, color: '#999', marginTop: 4, marginLeft: 4 }}>
            HbA1c son 2-3 aylık kan şekeri ortalamanızı gösterir.
          </Text>

          <Text style={[styles.inputLabel, { marginTop: 16 }]}>
            Açlık Kan Şekeri (mg/dL) — Opsiyonel
          </Text>
          <TextInput
            style={styles.textInput}
            placeholder="Örn: 110"
            placeholderTextColor="#A0A0A0"
            value={fastingGlucose}
            onChangeText={setFastingGlucose}
            keyboardType="numeric"
            maxLength={3}
          />
        </View>
      )}
    </View>
  );

  const renderStep3 = () => (
    <View>
      <Text style={styles.stepTitle}>🏃 Aktivite Seviyesi</Text>
      <Text style={styles.stepSubtitle}>
        Fiziksel aktiviteniz günlük karbonhidrat ihtiyacınızı belirler.
      </Text>

      {(Object.keys(ACTIVITY_LEVEL_LABELS) as ActivityLevel[]).map((al) => {
        const emojis: Record<ActivityLevel, string> = {
          sedanter: '🪑',
          hafif_aktif: '🚶',
          aktif: '🏃',
          cok_aktif: '🏋️',
        };
        return (
          <OptionChip
            key={al}
            label={ACTIVITY_LEVEL_LABELS[al]}
            selected={activityLevel === al}
            onPress={() => setActivityLevel(al)}
            emoji={emojis[al]}
          />
        );
      })}
    </View>
  );

  const steps = [renderStep0, renderStep1, renderStep2, renderStep3];
  const isLastStep = step === TOTAL_STEPS - 1;

  const progressWidth = progressAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ['0%', '100%'],
  });

  return (
    <View style={{ flex: 1, backgroundColor: '#F4F4F4' }}>
      <LinearGradient
        colors={['#008A79', '#00A68E']}
        style={{
          paddingTop: insets.top + 16,
          paddingBottom: 24,
          paddingHorizontal: 24,
          borderBottomLeftRadius: 32,
          borderBottomRightRadius: 32,
        }}
      >
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
          {step > 0 ? (
            <TouchableOpacity onPress={goBack} style={{ padding: 8 }}>
              <Ionicons name="arrow-back" size={24} color="#FFF" />
            </TouchableOpacity>
          ) : (
            <View style={{ width: 40 }} />
          )}
          <Text style={{ fontSize: 16, fontWeight: '700', color: 'rgba(255,255,255,0.9)' }}>
            {step + 1} / {TOTAL_STEPS}
          </Text>
          <View style={{ width: 40 }} />
        </View>

        {/* Progress Bar */}
        <View style={{ height: 6, backgroundColor: 'rgba(255,255,255,0.25)', borderRadius: 3, overflow: 'hidden' }}>
          <Animated.View
            style={{
              height: '100%',
              backgroundColor: '#FFFFFF',
              borderRadius: 3,
              width: progressWidth,
            }}
          />
        </View>
      </LinearGradient>

      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <ScrollView
          style={{ flex: 1 }}
          contentContainerStyle={{ padding: 24, paddingBottom: 120 }}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          {steps[step]()}
        </ScrollView>
      </KeyboardAvoidingView>

      {/* Bottom Button */}
      <View
        style={{
          position: 'absolute',
          bottom: 0,
          left: 0,
          right: 0,
          padding: 24,
          paddingBottom: insets.bottom + 24,
          backgroundColor: 'transparent',
        }}
      >
        <TouchableOpacity
          activeOpacity={0.8}
          onPress={isLastStep ? handleComplete : goNext}
          style={{
            backgroundColor: '#008A79',
            height: 60,
            borderRadius: 30,
            flexDirection: 'row',
            justifyContent: 'center',
            alignItems: 'center',
            shadowColor: '#006B5E',
            shadowOffset: { width: 0, height: 8 },
            shadowOpacity: 0.35,
            shadowRadius: 15,
            elevation: 10,
          }}
        >
          <Text style={{ color: '#FFF', fontSize: 18, fontWeight: '800', letterSpacing: 0.3 }}>
            {isLastStep ? 'Başlayalım! 🎉' : 'Devam Et'}
          </Text>
          {!isLastStep && (
            <Ionicons name="arrow-forward" size={22} color="#FFF" style={{ marginLeft: 8 }} />
          )}
        </TouchableOpacity>
      </View>
    </View>
  );
}

// ── Stiller ─────────────────────────────────────────────────
const styles = {
  stepTitle: {
    fontSize: 28,
    fontWeight: '900' as const,
    color: '#1A1A1A',
    marginBottom: 8,
  },
  stepSubtitle: {
    fontSize: 15,
    color: '#666',
    lineHeight: 22,
    marginBottom: 28,
  },
  inputLabel: {
    fontSize: 14,
    fontWeight: '700' as const,
    color: '#555',
    marginBottom: 8,
    marginLeft: 4,
    textTransform: 'uppercase' as const,
    letterSpacing: 0.5,
  },
  textInput: {
    backgroundColor: '#FFFFFF',
    borderRadius: 14,
    paddingHorizontal: 18,
    paddingVertical: 16,
    fontSize: 17,
    color: '#1A1A1A',
    fontWeight: '600' as const,
    borderWidth: 1.5,
    borderColor: '#E8E8E8',
    marginBottom: 20,
  },
};
