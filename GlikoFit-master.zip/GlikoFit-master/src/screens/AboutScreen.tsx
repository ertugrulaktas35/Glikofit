// ============================================================
// ℹ️ Hakkında Ekranı — Algoritma & Teknik Dökümantasyon
// ============================================================
import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';

export default function AboutScreen({ navigation }: any) {
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#F4F4F4' }}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Ionicons name="arrow-back" size={24} color="#1A1A1A" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Hakkında</Text>
        <View style={{ width: 40 }} />
      </View>
      <ScrollView contentContainerStyle={{ padding: 24, paddingBottom: 60 }} showsVerticalScrollIndicator={false}>
        <View style={styles.iconContainer}>
          <Ionicons name="leaf" size={64} color="#10B981" />
        </View>
        <Text style={styles.title}>GlikoFit</Text>
        <Text style={styles.subtitle}>Akıllı Kan Şekeri Asistanı</Text>
        
        {/* ── Amacımız ─────────────────────────────────── */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Amacımız Nedir?</Text>
          <Text style={styles.cardText}>
            Diyabet hastaları ve insülin direnci olanlar için klasik kalori sayma mantığı genellikle çalışmaz; çünkü 200 kalori pirincin vücuda etkisi ile 200 kalori etin etkisi aynı değildir. Amacımız, porsiyon kontrolü ve Glisemik Yük (GL) hesaplamasıyla ani şeker fırlamalarının önüne geçmek ve tatlı krizlerini akıllıca dengede tutmaktır.
          </Text>
        </View>
        
        {/* ── Özellikler ──────────────────────────────── */}
        <Text style={styles.sectionTitle}>Neler Sağlıyoruz?</Text>
        
        <View style={[styles.featureCard, { backgroundColor: '#E0F2FE' }]}>
          <View style={[styles.featIcon, { backgroundColor: '#BAE6FD' }]}>
            <Ionicons name="color-filter" size={24} color="#0284C7" />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={[styles.featTitle, { color: '#0369A1' }]}>1. Trafik Lambası Sistemi</Text>
            <Text style={[styles.featText, { color: '#075985' }]}>Güvenli, orta riskli ve kan şekerini fırlatacak yiyecekleri anında görsel olarak ayırt edersiniz.</Text>
          </View>
        </View>

        <View style={[styles.featureCard, { backgroundColor: '#D1FAE5' }]}>
          <View style={[styles.featIcon, { backgroundColor: '#A7F3D0' }]}>
            <Ionicons name="restaurant" size={24} color="#059669" />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={[styles.featTitle, { color: '#047857' }]}>2. Anlık Porsiyon Etkisi</Text>
            <Text style={[styles.featText, { color: '#064E3B' }]}>Yediğiniz porsiyon değiştikçe vücudunuza binen "şeker yükünü" ve karbonhidrat miktarını anında hesaplarız.</Text>
          </View>
        </View>
        
        <View style={[styles.featureCard, { backgroundColor: '#FEF3C7' }]}>
          <View style={[styles.featIcon, { backgroundColor: '#FDE68A' }]}>
            <Ionicons name="bulb" size={24} color="#D97706" />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={[styles.featTitle, { color: '#B45309' }]}>3. Akıllı Dengeleyici Koç</Text>
            <Text style={[styles.featText, { color: '#92400E' }]}>Yasak yok! Eğer canınız çok tatlı veya karbonhidrat çekerse, sistem size onu neyle eşleştirmeniz gerektiğini söyler.</Text>
          </View>
        </View>

        <View style={[styles.featureCard, { backgroundColor: '#E0E7FF' }]}>
          <View style={[styles.featIcon, { backgroundColor: '#C7D2FE' }]}>
            <Ionicons name="person" size={24} color="#4F46E5" />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={[styles.featTitle, { color: '#4338CA' }]}>4. Kişisel Sağlık Profili</Text>
            <Text style={[styles.featText, { color: '#3730A3' }]}>Diyabet tipiniz, HbA1c değeriniz ve fiziksel özelliklerinize göre tüm hesaplamalar size özel kalibre edilir.</Text>
          </View>
        </View>

        {/* ══════════════════════════════════════════════ */}
        {/* TEKNİK DÖKÜMANTASYON BÖLÜMÜ                   */}
        {/* ══════════════════════════════════════════════ */}

        <View style={{ marginTop: 32, marginBottom: 8, flexDirection: 'row', alignItems: 'center' }}>
          <View style={{ width: 4, height: 28, backgroundColor: '#008A79', borderRadius: 2, marginRight: 12 }} />
          <Text style={[styles.sectionTitle, { marginBottom: 0 }]}>Teknik Dökümantasyon</Text>
        </View>
        <Text style={{ fontSize: 14, color: '#999', marginBottom: 20, fontWeight: '500' }}>
          Kullanıcıdan alınan ve hesaplanan tüm değerlerin detaylı açıklaması
        </Text>

        {/* ── Kullanıcıdan Alınan Veriler ─────────────── */}
        <View style={styles.techCard}>
          <View style={styles.techHeaderRow}>
            <Ionicons name="create-outline" size={22} color="#008A79" />
            <Text style={styles.techCardTitle}>Kullanıcıdan Alınan Veriler</Text>
          </View>
          <Text style={styles.techDesc}>Onboarding ekranında kullanıcıdan toplanan ham girdiler:</Text>
          
          {[
            { field: 'Ad Soyad', desc: 'Kişisel karşılama ve profil kimliği için' },
            { field: 'Doğum Yılı', desc: 'Yaş hesaplaması — metabolizma hızı ve risk grubu tayini' },
            { field: 'Cinsiyet', desc: 'Erkek / Kadın — bazal metabolizma oranı farkları' },
            { field: 'Boy (cm)', desc: 'VKİ hesaplaması için temel fiziksel ölçüm' },
            { field: 'Kilo (kg)', desc: 'VKİ hesaplaması için temel fiziksel ölçüm' },
            { field: 'Diyabet Tipi', desc: 'Tip 1, Tip 2, Pre-diyabet, Gestasyonel veya Yok — GL eşikleri ve besin önerilerini belirler' },
            { field: 'HbA1c (%)', desc: 'Son 2-3 aylık kan şekeri ortalaması — diyabet kontrol kalitesi ölçütü. Opsiyonel' },
            { field: 'Açlık Kan Şekeri (mg/dL)', desc: 'Sabah aç karnına ölçülen kan şekeri değeri. Opsiyonel' },
            { field: 'Aktivite Seviyesi', desc: 'Sedanter / Hafif Aktif / Aktif / Çok Aktif — günlük enerji harcamasına göre karbonhidrat limiti düzeltmesi' },
          ].map((item, i) => (
            <View key={i} style={styles.techRow}>
              <Text style={styles.techField}>{item.field}</Text>
              <Text style={styles.techFieldDesc}>{item.desc}</Text>
            </View>
          ))}
        </View>

        {/* ── Hesaplanan Değerler ─────────────────────── */}
        <View style={styles.techCard}>
          <View style={styles.techHeaderRow}>
            <Ionicons name="calculator-outline" size={22} color="#D97706" />
            <Text style={[styles.techCardTitle, { color: '#92400E' }]}>Hesaplanan Değerler</Text>
          </View>

          {/* VKİ */}
          <View style={styles.algoBlock}>
            <Text style={styles.algoTitle}>1. Vücut Kitle İndeksi (VKİ / BMI)</Text>
            <View style={styles.formulaBox}>
              <Text style={styles.formulaText}>VKİ = Kilo(kg) ÷ [Boy(m)]²</Text>
            </View>
            <Text style={styles.algoDesc}>
              Örnek: 72 kg, 175 cm → VKİ = 72 ÷ 1.75² = 23.5{'\n'}
              • {'<'}18.5 → Zayıf{'\n'}
              • 18.5-24.9 → Normal{'\n'}
              • 25-29.9 → Fazla Kilolu{'\n'}
              • ≥30 → Obez
            </Text>
          </View>

          {/* GL */}
          <View style={styles.algoBlock}>
            <Text style={styles.algoTitle}>2. Glisemik Yük (GL)</Text>
            <View style={styles.formulaBox}>
              <Text style={styles.formulaText}>GL = (Gİ × Karbonhidrat_gram) ÷ 100</Text>
            </View>
            <Text style={styles.algoDesc}>
              Karbonhidrat_gram = (Karb_100g ÷ 100) × Porsiyon_gram{'\n\n'}
              Örnek: Beyaz ekmek (Gİ=75, Karb=49g/100g), 60g dilim{'\n'}
              → Karb = (49÷100)×60 = 29.4g{'\n'}
              → GL = (75 × 29.4) ÷ 100 = 22.1 🔴
            </Text>
          </View>

          {/* Kişisel GL Eşikleri */}
          <View style={styles.algoBlock}>
            <Text style={styles.algoTitle}>3. Kişiselleştirilmiş GL Eşikleri</Text>
            <Text style={styles.algoDesc}>
              Varsayılan eşikler (sağlıklı birey):{'\n'}
              🟢 Yeşil: GL {'<'} 10  •  🟡 Sarı: GL 10-19  •  🔴 Kırmızı: GL ≥ 20{'\n\n'}
              Diyabet tipine göre sıkılaştırma:
            </Text>
            <View style={styles.thresholdTable}>
              {[
                { type: 'Tip 1 Diyabet', y: '≥8', r: '≥16' },
                { type: 'Tip 2 Diyabet', y: '≥8', r: '≥15' },
                { type: 'Pre-diyabet', y: '≥9', r: '≥18' },
                { type: 'Gestasyonel', y: '≥7', r: '≥14' },
              ].map((row, i) => (
                <View key={i} style={styles.thresholdRow}>
                  <Text style={styles.thresholdType}>{row.type}</Text>
                  <Text style={[styles.thresholdVal, { color: '#F59E0B' }]}>{row.y}</Text>
                  <Text style={[styles.thresholdVal, { color: '#EF4444' }]}>{row.r}</Text>
                </View>
              ))}
            </View>
            <Text style={[styles.algoDesc, { marginTop: 8 }]}>
              ⚡ HbA1c {'>'} %7.5 ise eşikler ek olarak 2-3 puan daha düşürülür.
            </Text>
          </View>

          {/* Günlük Karb Limiti */}
          <View style={styles.algoBlock}>
            <Text style={styles.algoTitle}>4. Günlük Karbonhidrat Limiti</Text>
            <View style={styles.formulaBox}>
              <Text style={styles.formulaText}>
                Limit = Baz × VKİ_Katsayı × Aktivite_Katsayı × HbA1c_Katsayı
              </Text>
            </View>
            <Text style={styles.algoDesc}>
              Baz değerleri (ADA referansları):{'\n'}
              • Diyabet Yok: 250g  •  Tip 1: 180g  •  Tip 2: 150g{'\n'}
              • Pre-diyabet: 170g  •  Gestasyonel: 160g{'\n\n'}
              VKİ Düzeltmesi:{'\n'}
              • Obez (≥30): ×0.80  •  Fazla Kilolu (25-30): ×0.90{'\n'}
              • Zayıf ({'<'}18.5): ×1.10  •  Normal: ×1.00{'\n\n'}
              Aktivite Düzeltmesi:{'\n'}
              • Sedanter: ×0.85  •  Hafif Aktif: ×0.95{'\n'}
              • Aktif: ×1.05  •  Çok Aktif: ×1.15{'\n\n'}
              HbA1c {'>'} %7.0 ise: ×0.90 ek azaltma
            </Text>
          </View>

          {/* Besin Uygunluk */}
          <View style={[styles.algoBlock, { borderBottomWidth: 0 }]}>
            <Text style={styles.algoTitle}>5. Besin Uygunluk Algoritması</Text>
            <Text style={styles.algoDesc}>
              Her besin, kullanıcının diyabet tipine göre "Önerilir" veya "Önerilmez" olarak etiketlenir:{'\n\n'}
              • Gİ ≤ 55 → ✅ Tüm diyabet tipleri için güvenli{'\n'}
              • Gİ 56-69 → ⚠️ Tip 2 (HbA1c{'>'} 7) ve Gestasyonel için önerilmez{'\n'}
              • Gİ ≥ 70 → 🔴 Tüm diyabet hastaları için riskli
            </Text>
          </View>
        </View>

        {/* ── Veri Kaynakları ─────────────────────────── */}
        <View style={styles.techCard}>
          <View style={styles.techHeaderRow}>
            <Ionicons name="library-outline" size={22} color="#6366F1" />
            <Text style={[styles.techCardTitle, { color: '#4338CA' }]}>Veri Kaynakları</Text>
          </View>
          {[
            { src: 'Supabase Veritabanı', desc: 'Kendi besin veritabanımız — Gİ değerleri, karbonhidrat, kategori' },
            { src: 'FatSecret API', desc: 'Eksik karbonhidrat verisi için dış kaynak — otomatik tamamlama' },
            { src: 'Pixabay API', desc: 'Besin görselleri — arama sonuçlarına göre en uygun fotoğraf' },
            { src: 'Google Gemini AI', desc: 'Akıllı koç tavsiyeleri — yüksek GL durumlarında kişiselleştirilmiş beslenme önerileri' },
          ].map((item, i) => (
            <View key={i} style={styles.techRow}>
              <Text style={styles.techField}>{item.src}</Text>
              <Text style={styles.techFieldDesc}>{item.desc}</Text>
            </View>
          ))}
        </View>

        <Text style={{ textAlign: 'center', fontSize: 12, color: '#A0A0A0', marginTop: 20 }}>
          GlikoFit v1.1.0 — Tüm hesaplamalar ADA ve DSÖ kılavuzları referans alınarak yapılmıştır.
        </Text>
        <Text style={{ textAlign: 'center', fontSize: 11, color: '#CBCBCB', marginTop: 4 }}>
          Bu uygulama tıbbi tavsiye yerine geçmez. Lütfen diyetisyeninize danışın.
        </Text>

      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 20, paddingTop: 10, paddingBottom: 15, backgroundColor: '#F4F4F4' },
  backBtn: { width: 44, height: 44, borderRadius: 22, backgroundColor: '#FFF', alignItems: 'center', justifyContent: 'center', shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4, elevation: 2 },
  headerTitle: { fontSize: 20, fontWeight: '800', color: '#1A1A1A' },
  iconContainer: { alignSelf: 'center', backgroundColor: '#D1FAE5', padding: 25, borderRadius: 50, marginBottom: 16 },
  title: { fontSize: 32, fontWeight: '900', color: '#1A1A1A', textAlign: 'center' },
  subtitle: { fontSize: 18, color: '#10B981', fontWeight: '800', textAlign: 'center', marginBottom: 30 },
  card: { backgroundColor: '#FFF', borderRadius: 24, padding: 24, marginBottom: 30, shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.05, shadowRadius: 10, elevation: 3 },
  cardTitle: { fontSize: 20, fontWeight: '900', color: '#1A1A1A', marginBottom: 12 },
  cardText: { fontSize: 16, color: '#4B5563', lineHeight: 24, fontWeight: '500' },
  sectionTitle: { fontSize: 24, fontWeight: '900', color: '#1A1A1A', marginBottom: 16 },
  featureCard: { flexDirection: 'row', padding: 20, borderRadius: 24, marginBottom: 16 },
  featIcon: { width: 52, height: 52, borderRadius: 26, alignItems: 'center', justifyContent: 'center', marginRight: 16 },
  featTitle: { fontSize: 18, fontWeight: '900', marginBottom: 6 },
  featText: { fontSize: 14, lineHeight: 22, fontWeight: '600' },
  // Teknik Kart Stilleri
  techCard: {
    backgroundColor: '#FFF',
    borderRadius: 20,
    padding: 22,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.06,
    shadowRadius: 10,
    elevation: 3,
  },
  techHeaderRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 14 },
  techCardTitle: { fontSize: 18, fontWeight: '900', color: '#008A79', marginLeft: 10 },
  techDesc: { fontSize: 14, color: '#666', lineHeight: 20, marginBottom: 14, fontWeight: '500' },
  techRow: { borderBottomWidth: 1, borderBottomColor: '#F0F0F0', paddingVertical: 12 },
  techField: { fontSize: 15, fontWeight: '800', color: '#333', marginBottom: 3 },
  techFieldDesc: { fontSize: 13, color: '#777', lineHeight: 19, fontWeight: '500' },
  algoBlock: { borderBottomWidth: 1, borderBottomColor: '#F0F0F0', paddingVertical: 16 },
  algoTitle: { fontSize: 16, fontWeight: '800', color: '#1A1A1A', marginBottom: 10 },
  algoDesc: { fontSize: 13, color: '#555', lineHeight: 20, fontWeight: '500' },
  formulaBox: {
    backgroundColor: '#F0FDF4',
    borderWidth: 1.5,
    borderColor: '#BBF7D0',
    borderRadius: 12,
    paddingVertical: 12,
    paddingHorizontal: 16,
    marginBottom: 12,
  },
  formulaText: { fontSize: 14, fontWeight: '800', color: '#059669', fontFamily: 'monospace' },
  thresholdTable: { marginTop: 8 },
  thresholdRow: {
    flexDirection: 'row',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#F5F5F5',
    alignItems: 'center',
  },
  thresholdType: { flex: 1, fontSize: 13, fontWeight: '700', color: '#333' },
  thresholdVal: { width: 50, fontSize: 14, fontWeight: '800', textAlign: 'center' },
});
