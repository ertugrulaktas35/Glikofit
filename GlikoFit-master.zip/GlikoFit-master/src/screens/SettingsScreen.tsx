import React, { useState } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, Switch, Alert, Linking,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { useAppStore } from '../store/useAppStore';
import { useUserStore } from '../store/useUserStore';
import { cancelAllNotifications } from '../services/notificationService';

export default function SettingsScreen() {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation<any>();
  const { isPremium } = useAppStore();
  const { profile } = useUserStore();

  const [highGLNotif, setHighGLNotif] = useState(true);
  const [reminderNotif, setReminderNotif] = useState(false);

  const handleHighGLToggle = async (val: boolean) => {
    setHighGLNotif(val);
    if (!val) {
      await cancelAllNotifications();
    }
  };

  const handleOpenAppSettings = () => {
    Linking.openSettings();
  };

  const handlePrivacy = () => {
    Alert.alert(
      'Gizlilik Politikası',
      'GlikoFit uygulaması; sağlık verilerinizi yalnızca size özel öneriler sunmak amacıyla kullanır. Verileriniz üçüncü taraflarla paylaşılmaz ve şifreli olarak saklanır.',
      [{ text: 'Tamam' }]
    );
  };

  const handleContact = () => {
    Linking.openURL('mailto:destek@glikofit.com?subject=GlikoFit Destek');
  };

  return (
    <ScrollView style={{ flex: 1, backgroundColor: '#F5F7FA' }} showsVerticalScrollIndicator={false}>
      <LinearGradient
        colors={['#063830', '#0A5748', '#0D7A6B']}
        start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
        style={{
          paddingTop: insets.top + 16,
          paddingBottom: 28,
          paddingHorizontal: 20,
          borderBottomLeftRadius: 36,
          borderBottomRightRadius: 36,
          flexDirection: 'row',
          alignItems: 'center',
          shadowColor: '#052E28',
          shadowOffset: { width: 0, height: 10 },
          shadowOpacity: 0.22, shadowRadius: 18, elevation: 12,
        }}
      >
        <TouchableOpacity
          onPress={() => navigation.goBack()}
          style={{ width: 40, height: 40, borderRadius: 20, backgroundColor: 'rgba(255,255,255,0.2)', alignItems: 'center', justifyContent: 'center', marginRight: 16 }}
        >
          <Ionicons name="arrow-back" size={22} color="#FFF" />
        </TouchableOpacity>
        <View>
          <Text style={{ fontSize: 24, fontWeight: '800', color: '#FFF' }}>Ayarlar</Text>
          <Text style={{ fontSize: 14, color: '#A7F3D0', marginTop: 2, fontWeight: '600' }}>Uygulama tercihleriniz</Text>
        </View>
      </LinearGradient>

      <View style={{ paddingHorizontal: 20, paddingTop: 20, paddingBottom: 40 }}>

        {/* Bildirimler */}
        <Text style={{ fontSize: 13, fontWeight: '700', color: '#94A3B8', textTransform: 'uppercase', letterSpacing: 0.8, marginBottom: 10 }}>
          Bildirimler
        </Text>
        <View style={{ backgroundColor: '#FFF', borderRadius: 16, overflow: 'hidden', marginBottom: 20 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', paddingHorizontal: 18, paddingVertical: 16, borderBottomWidth: 1, borderBottomColor: '#F0F0F0' }}>
            <View style={{ width: 40, height: 40, borderRadius: 12, backgroundColor: '#FEE2E2', alignItems: 'center', justifyContent: 'center', marginRight: 14 }}>
              <Ionicons name="warning-outline" size={20} color="#DC2626" />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={{ fontSize: 16, fontWeight: '700', color: '#212121' }}>Yüksek GL Uyarısı</Text>
              <Text style={{ fontSize: 13, color: '#94A3B8', marginTop: 2 }}>GL ≥ 20 olduğunda bildir</Text>
            </View>
            <Switch
              value={highGLNotif}
              onValueChange={handleHighGLToggle}
              trackColor={{ false: '#E5E7EB', true: '#10B981' }}
              thumbColor="#FFF"
            />
          </View>

          <View style={{ flexDirection: 'row', alignItems: 'center', paddingHorizontal: 18, paddingVertical: 16 }}>
            <View style={{ width: 40, height: 40, borderRadius: 12, backgroundColor: '#E0F2FE', alignItems: 'center', justifyContent: 'center', marginRight: 14 }}>
              <Ionicons name="alarm-outline" size={20} color="#0284C7" />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={{ fontSize: 16, fontWeight: '700', color: '#212121' }}>Öğün Hatırlatıcısı</Text>
              <Text style={{ fontSize: 13, color: '#94A3B8', marginTop: 2 }}>
                {isPremium ? 'Öğün vakitlerinde hatırlat' : 'Premium özellik'}
              </Text>
            </View>
            <Switch
              value={reminderNotif}
              onValueChange={isPremium ? setReminderNotif : () => Alert.alert('Premium', 'Bu özellik için Premium\'a geçin.')}
              trackColor={{ false: '#E5E7EB', true: '#10B981' }}
              thumbColor="#FFF"
              disabled={!isPremium}
            />
          </View>
        </View>

        {/* Hesap */}
        <Text style={{ fontSize: 13, fontWeight: '700', color: '#94A3B8', textTransform: 'uppercase', letterSpacing: 0.8, marginBottom: 10 }}>
          Hesap
        </Text>
        <View style={{ backgroundColor: '#FFF', borderRadius: 16, overflow: 'hidden', marginBottom: 20 }}>
          <TouchableOpacity
            onPress={() => navigation.navigate('Onboarding')}
            style={{ flexDirection: 'row', alignItems: 'center', paddingHorizontal: 18, paddingVertical: 16, borderBottomWidth: 1, borderBottomColor: '#F0F0F0' }}
          >
            <View style={{ width: 40, height: 40, borderRadius: 12, backgroundColor: '#D1FAE5', alignItems: 'center', justifyContent: 'center', marginRight: 14 }}>
              <Ionicons name="person-outline" size={20} color="#059669" />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={{ fontSize: 16, fontWeight: '700', color: '#212121' }}>Profili Düzenle</Text>
              <Text style={{ fontSize: 13, color: '#94A3B8', marginTop: 2 }}>
                {profile ? `${profile.fullName} · ${profile.diabetesType}` : 'Sağlık bilgilerinizi güncelleyin'}
              </Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color="#D4D4D4" />
          </TouchableOpacity>

          <TouchableOpacity
            onPress={handleOpenAppSettings}
            style={{ flexDirection: 'row', alignItems: 'center', paddingHorizontal: 18, paddingVertical: 16 }}
          >
            <View style={{ width: 40, height: 40, borderRadius: 12, backgroundColor: '#F3F4F6', alignItems: 'center', justifyContent: 'center', marginRight: 14 }}>
              <Ionicons name="settings-outline" size={20} color="#6B7280" />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={{ fontSize: 16, fontWeight: '700', color: '#212121' }}>Uygulama İzinleri</Text>
              <Text style={{ fontSize: 13, color: '#94A3B8', marginTop: 2 }}>Kamera ve bildirim izinleri</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color="#D4D4D4" />
          </TouchableOpacity>
        </View>

        {/* Destek */}
        <Text style={{ fontSize: 13, fontWeight: '700', color: '#94A3B8', textTransform: 'uppercase', letterSpacing: 0.8, marginBottom: 10 }}>
          Destek & Bilgi
        </Text>
        <View style={{ backgroundColor: '#FFF', borderRadius: 16, overflow: 'hidden', marginBottom: 20 }}>
          <TouchableOpacity
            onPress={handlePrivacy}
            style={{ flexDirection: 'row', alignItems: 'center', paddingHorizontal: 18, paddingVertical: 16, borderBottomWidth: 1, borderBottomColor: '#F0F0F0' }}
          >
            <View style={{ width: 40, height: 40, borderRadius: 12, backgroundColor: '#EDE9FE', alignItems: 'center', justifyContent: 'center', marginRight: 14 }}>
              <Ionicons name="shield-checkmark-outline" size={20} color="#7C3AED" />
            </View>
            <Text style={{ fontSize: 16, fontWeight: '700', color: '#212121', flex: 1 }}>Gizlilik Politikası</Text>
            <Ionicons name="chevron-forward" size={20} color="#D4D4D4" />
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => navigation.navigate('About')}
            style={{ flexDirection: 'row', alignItems: 'center', paddingHorizontal: 18, paddingVertical: 16, borderBottomWidth: 1, borderBottomColor: '#F0F0F0' }}
          >
            <View style={{ width: 40, height: 40, borderRadius: 12, backgroundColor: '#FEF3C7', alignItems: 'center', justifyContent: 'center', marginRight: 14 }}>
              <Ionicons name="information-circle-outline" size={20} color="#B45309" />
            </View>
            <Text style={{ fontSize: 16, fontWeight: '700', color: '#212121', flex: 1 }}>Uygulama Hakkında</Text>
            <Ionicons name="chevron-forward" size={20} color="#D4D4D4" />
          </TouchableOpacity>

          <TouchableOpacity
            onPress={handleContact}
            style={{ flexDirection: 'row', alignItems: 'center', paddingHorizontal: 18, paddingVertical: 16 }}
          >
            <View style={{ width: 40, height: 40, borderRadius: 12, backgroundColor: '#E0F2FE', alignItems: 'center', justifyContent: 'center', marginRight: 14 }}>
              <Ionicons name="mail-outline" size={20} color="#0284C7" />
            </View>
            <Text style={{ fontSize: 16, fontWeight: '700', color: '#212121', flex: 1 }}>Bize Ulaşın</Text>
            <Ionicons name="chevron-forward" size={20} color="#D4D4D4" />
          </TouchableOpacity>
        </View>

        {/* Sürüm */}
        <Text style={{ textAlign: 'center', fontSize: 13, color: '#94A3B8', marginTop: 8 }}>
          GlikoFit v1.1.0 · Build 2026.05
        </Text>
      </View>
    </ScrollView>
  );
}
