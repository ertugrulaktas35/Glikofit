import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import {
  View, Text, TextInput, FlatList, TouchableOpacity,
  ActivityIndicator, Platform, Image, ScrollView, Animated, Easing, StyleSheet,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { supabase } from '../lib/supabase';
import type { Food, ColorCode } from '../types/database';
import { getFoodImage } from '../utils/images';
import { useUserStore } from '../store/useUserStore';
import { useAppStore } from '../store/useAppStore';
import { useHealthStore } from '../store/useHealthStore';
import { isFoodRecommended, DIABETES_TYPE_LABELS } from '../utils/healthCalculations';
import type { DiabetesType } from '../utils/healthCalculations';
import WaterModal from '../components/ui/WaterModal';
import WaterGlassWidget from '../components/ui/WaterGlassWidget';

// ── Tip ─────────────────────────────────────────────────────
type FilterKey = 'ALL' | ColorCode;

// ── Filtreler ────────────────────────────────────────────────
const FILTERS: { key: FilterKey; label: string; color: string }[] = [
  { key: 'ALL',    label: 'Tümü',    color: '#0D7A6B' },
  { key: 'GREEN',  label: 'Güvenli', color: '#10B981' },
  { key: 'YELLOW', label: 'Dikkat',  color: '#F59E0B' },
  { key: 'RED',    label: 'Riskli',  color: '#EF4444' },
];

const TRAFFIC: Record<ColorCode, { dot: string; label: string; bg: string; text: string }> = {
  GREEN:  { dot: '#10B981', label: 'Güvenli', bg: '#ECFDF5', text: '#065F46' },
  YELLOW: { dot: '#F59E0B', label: 'Dikkat',  bg: '#FFFBEB', text: '#78350F' },
  RED:    { dot: '#EF4444', label: 'Riskli',  bg: '#FEF2F2', text: '#7F1D1D' },
};

// ── Günlük AI İpucu (API çağrısız, profil bazlı) ─────────────
const DAILY_TIPS: Record<DiabetesType, string[]> = {
  tip1: [
    'İnsülin zamanlamanız için öğünden 15 dk önce karbonhidrat miktarını hesaplayın.',
    'Düşük GI (<55) gıdalar insülin tepkisini daha öngörülebilir kılar.',
    'Egzersiz öncesi kan şekerini kontrol edin; 90 mg/dL altındaysa hafif karbonhidrat alın.',
    'Lif oranı yüksek besinler (>5g/100g) glukoz emilimini yavaşlatır.',
    'Su içmek kan şekeri konsantrasyonunu düşürmeye yardımcı olur.',
    'Protein ağır öğünler glukoz yükselişini yavaşlatır.',
    'Uyku düzensizliği insülin direncini geçici olarak artırır.',
  ],
  tip2: [
    'Öğün atlamamak gün boyu kan şekerini dengelemenin en kolay yoludur.',
    'Beyaz ekmek yerine tam buğday ekmeği tercih edin; GI yarı yarıya düşer.',
    'Yürüyüş gibi hafif egzersiz öğün sonrası glukoz tepkisini %20 azaltır.',
    'Tabağınızın yarısı sebze olsun; karbonhidrat yoğunluğunu seyreltir.',
    'Tarçın insülin duyarlılığını artıran bileşikler içerir; kahvaltıya ekleyin.',
    'Bakliyatlar düşük GI ve yüksek lif içeriğiyle tip 2 için mükemmeldir.',
    'Gece geç saatte karbonhidrat tüketimi sabah açlık şekerini yükseltebilir.',
  ],
  prediyabet: [
    'Şu an önleyici aşamadasınız — küçük alışkanlıklar büyük fark yaratır.',
    'Haftalık 150 dk orta yoğunlukta egzersiz insülin direncini kırar.',
    'İşlenmiş şeker ve beyaz undan uzak durarak riski %58 azaltabilirsiniz.',
    'Zeytin yağı ve kuruyemiş gibi sağlıklı yağlar kan şekerini dengeler.',
    'Yeşil çay polifenolleri glukoz metabolizmasını destekler.',
    'Düzenli uyku (7-9 saat) insülin duyarlılığını korur.',
    'Stres hormonu kortizol kan şekerini yükseltir; nefes egzersizleri deneyin.',
  ],
  gestasyonel: [
    'Küçük ve sık öğünler (4-6/gün) kan şekeri dalgalanmalarını azaltır.',
    'Meyveleri günde 2-3 porsiyon ile sınırlı tutun, düşük GI olanları tercih edin.',
    'Her öğüne protein eklemek (yumurta, peynir, bakliyat) glukoz yükselişini frenler.',
    'Sabah kahvaltısı en önemli öğündür; karbonhidratı burada kısıtlayın.',
    'Yürüyüş (öğün sonrası 15 dk) gestasyonel diyabette kanıtlanmış etkilidir.',
    'Tam tahıllı besinler rafine alternatiflerine göre 2 kat daha fazla lif içerir.',
    'Bol su içmek (2-3L/gün) glukozun idrarla atılımını destekler.',
  ],
  yok: [
    'Trafik ışığı sistemimiz size en sağlıklı seçimleri anında gösterir.',
    'Günde 5 porsiyon meyve-sebze kronik hastalık riskini %26 düşürür.',
    'Düşük GI besinler enerji dalgalanmalarını önleyerek odaklanmanızı artırır.',
    'Öğünlerinizi renklendirin; renk çeşitliliği = antioksidan çeşitliliği.',
    'Lif hedefi: günde 25-30g. Baklagil ve tam tahıllar en iyi kaynaklardır.',
    'Su içmek metabolizma hızını %24-30 artırabilir.',
    'Ağır öğünleri öğle vakti tercih etmek metabolik ritmle uyumlu bir beslenme sağlar.',
  ],
};

function getDailyTip(diabetesType: DiabetesType): string {
  const pool = DAILY_TIPS[diabetesType] ?? DAILY_TIPS.yok;
  const dayOfYear = Math.floor(
    (Date.now() - new Date(new Date().getFullYear(), 0, 0).getTime()) / 86400000
  );
  return pool[dayOfYear % pool.length];
}

// ── Debounce Hook ────────────────────────────────────────────
function useDebounce<T>(value: T, delay: number): T {
  const [debouncedValue, setDebouncedValue] = useState<T>(value);
  useEffect(() => {
    const t = setTimeout(() => setDebouncedValue(value), delay);
    return () => clearTimeout(t);
  }, [value, delay]);
  return debouncedValue;
}

// ── Yiyecek Görseli ──────────────────────────────────────────
const FoodImage = React.memo(({ name, size = 56 }: { name: string; size?: number }) => {
  const [url, setUrl] = useState<string | null>(null);
  useEffect(() => {
    let active = true;
    getFoodImage(name).then(res => { if (active && res) setUrl(res); });
    return () => { active = false; };
  }, [name]);

  const s = { width: size, height: size, borderRadius: size * 0.28 };
  return url
    ? <Image source={{ uri: url }} style={s} resizeMode="cover" />
    : (
      <View style={[s, { backgroundColor: '#E8F5F3', justifyContent: 'center', alignItems: 'center' }]}>
        <Ionicons name="leaf-outline" size={size * 0.42} color="#0D7A6B" />
      </View>
    );
});

// ── Metrik Chip ──────────────────────────────────────────────
function MetricChip({ icon, value, unit, label, color, bg }: {
  icon: string; value: string | number; unit: string; label: string; color: string; bg: string;
}) {
  return (
    <View style={{ flex: 1, backgroundColor: bg, borderRadius: 16, padding: 12, alignItems: 'center' }}>
      <Text style={{ fontSize: 16 }}>{icon}</Text>
      <Text style={{ fontSize: 18, fontWeight: '900', color, marginTop: 2 }}>
        {value}<Text style={{ fontSize: 11, fontWeight: '600' }}>{unit}</Text>
      </Text>
      <Text style={{ fontSize: 10, color: '#64748B', marginTop: 1, fontWeight: '600', textAlign: 'center' }}>{label}</Text>
    </View>
  );
}

// ── Besin Kartı ──────────────────────────────────────────────
function FoodCard({ item, onPress }: { item: Food; onPress: () => void }) {
  const { profile } = useUserStore();
  const t = TRAFFIC[item.color_code];
  const recommended = profile ? isFoodRecommended(item.gi_value, profile.diabetesType, profile.hba1c) : true;
  const giColor = item.gi_value >= 70 ? '#EF4444' : item.gi_value >= 56 ? '#F59E0B' : '#10B981';
  const accentColor = t.dot;

  return (
    <TouchableOpacity
      activeOpacity={0.82}
      onPress={onPress}
      style={[
        foodCardStyles.card,
        !recommended && { opacity: 0.68 },
      ]}
    >
      {/* Sol renk aksanı */}
      <LinearGradient
        colors={[accentColor + 'CC', accentColor + '44']}
        start={{ x: 0, y: 0 }} end={{ x: 0, y: 1 }}
        style={foodCardStyles.accent}
      />

      {/* Fotoğraf */}
      <View style={foodCardStyles.imageWrap}>
        <FoodImage name={item.name} size={64} />
        {/* GI rozeti — fotoğraf üstünde */}
        <View style={[foodCardStyles.giBadge, { backgroundColor: giColor }]}>
          <Text style={foodCardStyles.giText}>{item.gi_value}</Text>
        </View>
      </View>

      {/* İçerik */}
      <View style={foodCardStyles.content}>
        <Text style={foodCardStyles.name} numberOfLines={1}>{item.name}</Text>
        <Text style={foodCardStyles.category} numberOfLines={1}>{item.category}</Text>

        <View style={foodCardStyles.chips}>
          {/* GI seviyesi */}
          <View style={[foodCardStyles.chip, { backgroundColor: giColor + '14' }]}>
            <View style={[foodCardStyles.chipDot, { backgroundColor: giColor }]} />
            <Text style={[foodCardStyles.chipText, { color: giColor }]}>
              {item.gi_value <= 55 ? 'Düşük GI' : item.gi_value <= 69 ? 'Orta GI' : 'Yüksek GI'}
            </Text>
          </View>

          {/* Karbonhidrat */}
          {item.carbs_per_100g > 0 && (
            <View style={[foodCardStyles.chip, { backgroundColor: '#F8FAFC' }]}>
              <Text style={[foodCardStyles.chipText, { color: '#64748B' }]}>
                {Math.round(item.carbs_per_100g)}g karb
              </Text>
            </View>
          )}

          {/* Önerilmez */}
          {!recommended && (
            <View style={[foodCardStyles.chip, { backgroundColor: '#FEF2F2' }]}>
              <Text style={[foodCardStyles.chipText, { color: '#EF4444' }]}>⚠ Önerilmez</Text>
            </View>
          )}
        </View>
      </View>

      {/* Sağ: trafik lambası */}
      <View style={foodCardStyles.right}>
        <View style={[foodCardStyles.trafficPill, { backgroundColor: t.bg }]}>
          <View style={[foodCardStyles.trafficDot, { backgroundColor: t.dot }]} />
          <Text style={[foodCardStyles.trafficText, { color: t.text }]}>{t.label}</Text>
        </View>
        <Ionicons name="chevron-forward" size={14} color="#CBD5E1" style={{ marginTop: 6 }} />
      </View>
    </TouchableOpacity>
  );
}

const foodCardStyles = StyleSheet.create({
  card: {
    marginHorizontal: 16,
    marginBottom: 10,
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 14,
    paddingRight: 14,
    shadowColor: '#0F172A',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.07,
    shadowRadius: 12,
    elevation: 3,
    overflow: 'hidden',
  },
  accent: {
    width: 4,
    borderRadius: 4,
    alignSelf: 'stretch',
    marginRight: 2,
  },
  imageWrap: {
    width: 68,
    height: 68,
    borderRadius: 16,
    overflow: 'visible',
    marginLeft: 10,
    position: 'relative',
  },
  giBadge: {
    position: 'absolute',
    bottom: -4,
    right: -4,
    width: 26,
    height: 26,
    borderRadius: 13,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: '#FFF',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 4,
    elevation: 3,
  },
  giText: {
    fontSize: 9,
    fontWeight: '900',
    color: '#FFF',
  },
  content: {
    flex: 1,
    marginLeft: 14,
    gap: 3,
  },
  name: {
    fontSize: 15,
    fontWeight: '800',
    color: '#0F172A',
    letterSpacing: -0.2,
  },
  category: {
    fontSize: 11,
    color: '#94A3B8',
    fontWeight: '500',
  },
  chips: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 5,
    marginTop: 6,
  },
  chip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 8,
  },
  chipDot: {
    width: 5,
    height: 5,
    borderRadius: 3,
  },
  chipText: {
    fontSize: 10,
    fontWeight: '700',
  },
  right: {
    alignItems: 'center',
    marginLeft: 8,
    justifyContent: 'center',
  },
  trafficPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 9,
    paddingVertical: 5,
    borderRadius: 10,
  },
  trafficDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  trafficText: {
    fontSize: 11,
    fontWeight: '800',
  },
});

// ─────────────────────────────────────────────────────────────
// ANA EKRAN
// ─────────────────────────────────────────────────────────────
export default function HomeScreen() {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation<any>();
  const inputRef = useRef<TextInput>(null);

  const { profile, dailyCarbLimit } = useUserStore();
  const { dailyLog } = useAppStore();
  const { todayWaterMl, loadTodayData } = useHealthStore();

  const [userId, setUserId] = useState<string | null>(null);
  const [searchText, setSearchText] = useState('');
  const [foods, setFoods] = useState<Food[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [hasSearched, setHasSearched] = useState(false);
  const [selectedFilter, setSelectedFilter] = useState<FilterKey>('ALL');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [categories, setCategories] = useState<string[]>([]);
  const [tipDismissed, setTipDismissed]     = useState(false);
  const [searchFocused, setSearchFocused]   = useState(false);
  const [waterModalOpen, setWaterModalOpen] = useState(false);

  // ── Bardak sallama animasyonu ────────────────────────────────
  const shakeAnim = useRef(new Animated.Value(0)).current;

  const triggerShake = useCallback(() => {
    Animated.sequence([
      Animated.timing(shakeAnim, { toValue:  8, duration: 60,  easing: Easing.linear, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: -8, duration: 60,  easing: Easing.linear, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue:  6, duration: 55,  easing: Easing.linear, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: -6, duration: 55,  easing: Easing.linear, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue:  3, duration: 50,  easing: Easing.linear, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue:  0, duration: 40,  easing: Easing.linear, useNativeDriver: true }),
    ]).start();
  }, [shakeAnim]);

  // Her 35 saniyede bir salla
  useEffect(() => {
    const timer = setTimeout(triggerShake, 4000);
    const interval = setInterval(triggerShake, 35000);
    return () => { clearTimeout(timer); clearInterval(interval); };
  }, [triggerShake]);

  const debouncedSearch = useDebounce(searchText.trim(), 400);

  // Kullanıcı ID + günlük veri yükle
  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      if (data.user) { setUserId(data.user.id); loadTodayData(data.user.id); }
    });
  }, []);

  // Kategoriler
  useEffect(() => {
    supabase.from('foods').select('category').then(({ data }) => {
      if (data) {
        const unique = [...new Set((data as { category: string }[]).map(d => d.category))].sort();
        setCategories(unique);
      }
    });
  }, []);

  // Besin arama
  const fetchFoods = useCallback(async (query: string) => {
    setIsLoading(true);
    try {
      let q = supabase.from('foods').select('*');
      if (query.length > 0) { q = q.ilike('name', `%${query}%`); setHasSearched(true); }
      else { setHasSearched(false); }
      if (selectedFilter !== 'ALL') q = q.eq('color_code', selectedFilter);
      if (selectedCategory) q = q.eq('category', selectedCategory);
      if (query.length === 0) q = q.limit(30);
      q = q.order('color_code', { ascending: true }).order('name', { ascending: true });
      const { data, error } = await q;
      let localFoods = (data as Food[]) || [];

      if (query.length > 2 && selectedFilter === 'ALL' && !selectedCategory) {
        const { searchFoodsFatSecret } = await import('../lib/fatsecret');
        const fsFoods = await searchFoodsFatSecret(query, 5);
        const mappedFs: Food[] = fsFoods.map(f => ({
          id: parseInt(f.food_id) || Math.floor(Math.random() * 1_000_000),
          name: f.food_name,
          category: 'FatSecret',
          gi_value: 50,
          carbs_per_100g: f.carbs_per_100g,
          protein_per_100g: 0,
          fat_per_100g: 0,
          calories_per_100g: 0,
          fiber_per_100g: 0,
          color_code: 'YELLOW' as ColorCode,
          source: 'fatsecret' as const,
          created_at: new Date().toISOString(),
        }));
        const existing = new Set(localFoods.map(l => l.name.toLowerCase()));
        localFoods = [...localFoods, ...mappedFs.filter(f => !existing.has(f.name.toLowerCase()))];
      }
      setFoods(error && localFoods.length === 0 ? [] : localFoods);
    } catch { setFoods([]); }
    finally { setIsLoading(false); }
  }, [selectedFilter, selectedCategory]);

  useEffect(() => { fetchFoods(debouncedSearch); }, [debouncedSearch, fetchFoods]);

  // Hesaplanan değerler
  const todayGL = useMemo(() =>
    Math.round(dailyLog.reduce((s, e) => s + e.glycemicLoad, 0) * 10) / 10,
    [dailyLog]
  );
  const carbConsumed = useMemo(() =>
    Math.round(dailyLog.reduce((s, e) => s + (e.portion * 0.35), 0)),
    [dailyLog]
  );
  const carbRemaining = Math.max(0, dailyCarbLimit - carbConsumed);
  const dailyTip = profile ? getDailyTip(profile.diabetesType) : null;
  const dayName = ['Pazar', 'Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi'][new Date().getDay()];
  const dayDate = `${new Date().getDate()} ${['Oca','Şub','Mar','Nis','May','Haz','Tem','Ağu','Eyl','Eki','Kas','Ara'][new Date().getMonth()]}`;

  const firstName = profile?.fullName.split(' ')[0] ?? 'Hoş geldin';

  const greetingHour = new Date().getHours();
  const greeting = greetingHour < 12 ? 'Günaydın' : greetingHour < 18 ? 'İyi günler' : 'İyi akşamlar';

  return (
    <View style={{ flex: 1, backgroundColor: '#F5F7FA' }}>
      <FlatList
        data={isLoading ? [] : foods}
        keyExtractor={item => item.id.toString()}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 120 }}

        renderItem={({ item }) => (
          <FoodCard
            item={item}
            onPress={() => navigation.navigate('FoodDetail', { food: item })}
          />
        )}

        ListEmptyComponent={
          isLoading ? (
            <View style={{ alignItems: 'center', paddingTop: 60 }}>
              <ActivityIndicator size="large" color="#0D7A6B" />
              <Text style={{ fontSize: 15, color: '#94A3B8', marginTop: 12 }}>Besinler yükleniyor...</Text>
            </View>
          ) : (
            <View style={{ alignItems: 'center', paddingTop: 48, paddingHorizontal: 40 }}>
              <View style={{ width: 68, height: 68, borderRadius: 34, backgroundColor: '#E8F5F3', alignItems: 'center', justifyContent: 'center', marginBottom: 14 }}>
                <Ionicons name={hasSearched ? 'search-outline' : 'nutrition-outline'} size={30} color="#0D7A6B" />
              </View>
              <Text style={{ fontSize: 20, fontWeight: '800', color: '#0F172A', textAlign: 'center', marginBottom: 6 }}>
                {hasSearched ? 'Besin bulunamadı' : 'Henüz besin yok'}
              </Text>
              <Text style={{ fontSize: 14, color: '#64748B', textAlign: 'center', lineHeight: 22 }}>
                {hasSearched
                  ? `"${searchText}" için sonuç yok.\nFarklı bir isim deneyin.`
                  : 'Veritabanında henüz besin kaydı bulunmuyor.'}
              </Text>
            </View>
          )
        }

        ListHeaderComponent={
          <View>
            {/* ══ HEADER ══════════════════════════════════════ */}
            <LinearGradient
              colors={['#063830', '#0A5748', '#0D7A6B']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={{
                paddingTop: insets.top + 16,
                paddingBottom: 32,
                paddingHorizontal: 20,
                borderBottomLeftRadius: 36,
                borderBottomRightRadius: 36,
                shadowColor: '#052E28',
                shadowOffset: { width: 0, height: 10 },
                shadowOpacity: 0.25,
                shadowRadius: 18,
                elevation: 12,
                marginBottom: 16,
              }}
            >
              {/* ── Dekoratif arka halka ── */}
              <View style={{
                position: 'absolute', right: -30, top: -30,
                width: 180, height: 180, borderRadius: 90,
                backgroundColor: 'rgba(255,255,255,0.04)',
              }} pointerEvents="none" />
              <View style={{
                position: 'absolute', right: 40, top: 20,
                width: 90, height: 90, borderRadius: 45,
                backgroundColor: 'rgba(255,255,255,0.06)',
              }} pointerEvents="none" />

              {/* ── Satır 1: Selamlama + Tarih ── */}
              <View style={{ flexDirection: 'row', alignItems: 'flex-start', marginBottom: 20 }}>
                <View style={{ flex: 1 }}>
                  {/* Selamlama küçük */}
                  <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 5 }}>
                    <View style={{
                      width: 8, height: 8, borderRadius: 4,
                      backgroundColor: '#34D399', marginRight: 8,
                    }} />
                    <Text style={{ fontSize: 14, color: '#6EE7B7', fontWeight: '700', letterSpacing: 0.3 }}>
                      {greeting}
                    </Text>
                  </View>
                  {/* İsim büyük */}
                  <Text style={{ fontSize: 28, fontWeight: '900', color: '#FFFFFF', letterSpacing: -0.3 }}>
                    {firstName}
                  </Text>
                </View>

                {/* Sağ: tarih + su bardağı */}
                {/* Tarih kutusu */}
                <View style={{
                  backgroundColor: 'rgba(255,255,255,0.12)',
                  borderRadius: 16, paddingHorizontal: 14, paddingVertical: 10,
                  alignItems: 'center', borderWidth: 1, borderColor: 'rgba(255,255,255,0.15)',
                }}>
                  <Text style={{ fontSize: 11, color: '#6EE7B7', fontWeight: '700', letterSpacing: 0.5, textTransform: 'uppercase' }}>
                    {dayName}
                  </Text>
                  <Text style={{ fontSize: 18, fontWeight: '900', color: '#FFFFFF', marginTop: 1 }}>
                    {dayDate}
                  </Text>
                </View>
              </View>

              {/* ── Arama çubuğu ── */}
              <View style={{
                flexDirection: 'row', alignItems: 'center',
                backgroundColor: '#FFFFFF',
                borderRadius: 18,
                paddingHorizontal: 16,
                height: 54,
                shadowColor: '#000',
                shadowOffset: { width: 0, height: 4 },
                shadowOpacity: 0.12,
                shadowRadius: 10,
                elevation: 5,
                borderWidth: searchFocused ? 2 : 0,
                borderColor: '#34D399',
              }}>
                <Ionicons
                  name="search"
                  size={22}
                  color={searchFocused ? '#0D7A6B' : '#94A3B8'}
                  style={{ marginRight: 10 }}
                />
                <TextInput
                  ref={inputRef}
                  style={{
                    flex: 1, fontSize: 16, fontWeight: '500',
                    color: '#0F172A',
                    paddingVertical: Platform.OS === 'ios' ? 14 : 10,
                  }}
                  placeholder="Besin adı yazın..."
                  placeholderTextColor="#94A3B8"
                  value={searchText}
                  onChangeText={setSearchText}
                  onFocus={() => setSearchFocused(true)}
                  onBlur={() => setSearchFocused(false)}
                  autoCapitalize="none"
                  autoCorrect={false}
                />
                {searchText.length > 0 ? (
                  <TouchableOpacity
                    onPress={() => { setSearchText(''); inputRef.current?.blur(); }}
                    style={{ width: 32, height: 32, borderRadius: 10, backgroundColor: '#F1F5F9', alignItems: 'center', justifyContent: 'center' }}
                    hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
                  >
                    <Ionicons name="close" size={18} color="#64748B" />
                  </TouchableOpacity>
                ) : (
                  <View style={{ flexDirection: 'row', gap: 8 }}>
                    {/* Kamera — AI yemek tarama */}
                    <TouchableOpacity
                      onPress={() => navigation.navigate('FoodCamera')}
                      style={{ width: 36, height: 36, borderRadius: 12, backgroundColor: '#0D7A6B', alignItems: 'center', justifyContent: 'center' }}
                      hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                    >
                      <Ionicons name="camera" size={19} color="#FFF" />
                    </TouchableOpacity>
                    {/* Barkod */}
                    <TouchableOpacity
                      onPress={() => navigation.navigate('BarcodeScanner')}
                      style={{ width: 36, height: 36, borderRadius: 12, backgroundColor: '#F0FDF4', alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: '#BBF7D0' }}
                      hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                    >
                      <Ionicons name="barcode-outline" size={19} color="#0D7A6B" />
                    </TouchableOpacity>
                  </View>
                )}
              </View>
            </LinearGradient>

            {/* ══ METRİK DASHBOARD ════════════════════════════ */}
            {profile && (
              <View style={{ flexDirection: 'row', gap: 8, paddingHorizontal: 16, paddingTop: 14, paddingBottom: 6 }}>
                <MetricChip
                  icon="🔥"
                  value={todayGL}
                  unit=" GL"
                  label="Bugünkü GL"
                  color="#C2410C"
                  bg="#FFF7ED"
                />
                <MetricChip
                  icon="🌾"
                  value={carbRemaining}
                  unit="g"
                  label="Karb Kalan"
                  color="#0D7A6B"
                  bg="#F0FDF4"
                />
                <MetricChip
                  icon="💧"
                  value={(todayWaterMl / 1000).toFixed(1)}
                  unit="L"
                  label="Su İçildi"
                  color="#0369A1"
                  bg="#EFF6FF"
                />
              </View>
            )}

            {/* ══ AI GÜNLÜK İPUCU ═════════════════════════════ */}
            {dailyTip && !tipDismissed && (
              <View style={{
                marginHorizontal: 16, marginTop: 10, marginBottom: 4,
                backgroundColor: '#F0FDF4', borderRadius: 16,
                padding: 14, flexDirection: 'row', alignItems: 'flex-start',
                borderWidth: 1, borderColor: '#BBF7D0',
              }}>
                <View style={{
                  width: 34, height: 34, borderRadius: 17,
                  backgroundColor: '#0D7A6B', alignItems: 'center', justifyContent: 'center',
                  marginRight: 12, flexShrink: 0,
                }}>
                  <Ionicons name="bulb-outline" size={18} color="#FFFFFF" />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={{ fontSize: 11, fontWeight: '700', color: '#059669', marginBottom: 3, textTransform: 'uppercase', letterSpacing: 0.5 }}>
                    Günün İpucu
                  </Text>
                  <Text style={{ fontSize: 13, color: '#064E3B', lineHeight: 20, fontWeight: '500' }}>
                    {dailyTip}
                  </Text>
                </View>
                <TouchableOpacity
                  onPress={() => setTipDismissed(true)}
                  hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                  style={{ marginLeft: 8 }}
                >
                  <Ionicons name="close" size={16} color="#94A3B8" />
                </TouchableOpacity>
              </View>
            )}

            {/* ══ SU TAKİBİ — bardağa tıklayarak aç ─────── */}

            {/* ══ FİLTRELER ───────────────────────────────── */}
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={{ paddingHorizontal: 16, paddingVertical: 12, gap: 8 }}
            >
              {FILTERS.map(f => {
                const active = selectedFilter === f.key;
                return (
                  <TouchableOpacity
                    key={f.key}
                    onPress={() => setSelectedFilter(f.key as FilterKey)}
                    style={{
                      paddingHorizontal: 16, paddingVertical: 9, borderRadius: 24,
                      backgroundColor: active ? f.color : '#FFFFFF',
                      borderWidth: 1.5,
                      borderColor: active ? f.color : '#E2E8F0',
                      shadowColor: active ? f.color : '#000',
                      shadowOffset: { width: 0, height: 2 },
                      shadowOpacity: active ? 0.25 : 0.04,
                      shadowRadius: 5, elevation: active ? 4 : 1,
                    }}
                  >
                    <Text style={{ fontSize: 14, fontWeight: '800', color: active ? '#FFFFFF' : '#475569' }}>
                      {f.label}
                    </Text>
                  </TouchableOpacity>
                );
              })}
            </ScrollView>

            {/* ══ KATEGORİLER ─────────────────────────────── */}
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: 14, gap: 8 }}
            >
              <TouchableOpacity
                onPress={() => setSelectedCategory(null)}
                style={{
                  paddingHorizontal: 14, paddingVertical: 7, borderRadius: 12,
                  backgroundColor: !selectedCategory ? '#0D7A6B' : 'transparent',
                  borderWidth: 1, borderColor: !selectedCategory ? '#0D7A6B' : '#E2E8F0',
                }}
              >
                <Text style={{ fontSize: 13, fontWeight: '700', color: !selectedCategory ? '#FFF' : '#64748B' }}>
                  Tümü
                </Text>
              </TouchableOpacity>
              {categories.map(cat => {
                const active = selectedCategory === cat;
                return (
                  <TouchableOpacity
                    key={cat}
                    onPress={() => setSelectedCategory(active ? null : cat)}
                    style={{
                      paddingHorizontal: 14, paddingVertical: 7, borderRadius: 12,
                      backgroundColor: active ? '#0D7A6B' : 'transparent',
                      borderWidth: 1, borderColor: active ? '#0D7A6B' : '#E2E8F0',
                    }}
                  >
                    <Text style={{ fontSize: 13, fontWeight: '700', color: active ? '#FFF' : '#64748B' }}>
                      {cat}
                    </Text>
                  </TouchableOpacity>
                );
              })}
            </ScrollView>

            {/* ══ BÖLÜM BAŞLIĞI ───────────────────────────── */}
            <View style={{ paddingHorizontal: 16, paddingBottom: 10, flexDirection: 'row', alignItems: 'center' }}>
              <Text style={{ fontSize: 16, fontWeight: '800', color: '#0F172A', flex: 1 }}>
                {hasSearched ? `"${searchText}" sonuçları` : 'Besinler'}
              </Text>
              {profile?.diabetesType !== 'yok' && (
                <View style={{ backgroundColor: '#FEF3C7', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 10 }}>
                  <Text style={{ fontSize: 11, fontWeight: '700', color: '#92400E' }}>
                    {DIABETES_TYPE_LABELS[profile!.diabetesType]}
                  </Text>
                </View>
              )}
            </View>
          </View>
        }
      />

      {/* ── Yüzen Su Bardağı ── */}
      {profile && userId && (
        <WaterGlassWidget
          pct={Math.min(100, (todayWaterMl / Math.round(profile.weightKg * 30)) * 100)}
          waterMl={todayWaterMl}
          shakeAnim={shakeAnim}
          onPress={() => setWaterModalOpen(true)}
        />
      )}

      {/* Su Takibi Modalı */}
      {profile && userId && (
        <WaterModal
          visible={waterModalOpen}
          onClose={() => setWaterModalOpen(false)}
          userId={userId}
          weightKg={profile.weightKg}
        />
      )}
    </View>
  );
}
