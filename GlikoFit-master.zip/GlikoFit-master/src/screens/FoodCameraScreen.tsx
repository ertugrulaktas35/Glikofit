import React, { useState, useRef, useEffect } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, ActivityIndicator,
  Alert, ScrollView, Image, Animated, Easing, Dimensions,
} from 'react-native';
import { CameraView, Camera } from 'expo-camera';
import * as ImagePicker from 'expo-image-picker';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import Slider from '@react-native-community/slider';
import { analyzeFoodPhoto } from '../services/logmeal';
import type { LogMealResult, LogMealFood } from '../services/logmeal';
import { useAppStore } from '../store/useAppStore';
import { scheduleHighGLNotification } from '../services/notificationService';

const { width: SW, height: SH } = Dimensions.get('window');

// ── Yardımcılar ───────────────────────────────────────────────

function glColor(gl: number): string {
  if (gl >= 20) return '#EF4444';
  if (gl >= 10) return '#F59E0B';
  return '#10B981';
}

function calcGL(gi: number, carbs: number, grams: number): number {
  const carbsInPortion = (carbs / 100) * grams;
  return Math.round((gi * carbsInPortion) / 100 * 10) / 10;
}

// ── Makro Kutu Bileşeni ───────────────────────────────────────

function MacroBox({ icon, label, value, unit, color }: {
  icon: string; label: string; value: number; unit: string; color: string;
}) {
  return (
    <View style={[styles.macroBox, { borderColor: color + '30', backgroundColor: color + '0D' }]}>
      <Text style={{ fontSize: 20, marginBottom: 4 }}>{icon}</Text>
      <Text style={[styles.macroVal, { color }]}>{value}</Text>
      <Text style={styles.macroUnit}>{unit}</Text>
      <Text style={styles.macroLabel}>{label}</Text>
    </View>
  );
}

// ── Analiz Animasyonu ─────────────────────────────────────────

function ScanAnimation() {
  const scanY = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(scanY, { toValue: 1, duration: 1800, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
        Animated.timing(scanY, { toValue: 0, duration: 1800, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
      ])
    ).start();
  }, []);

  const translateY = scanY.interpolate({
    inputRange: [0, 1],
    outputRange: [0, 200],
  });

  return (
    <View style={styles.scanOverlay}>
      <View style={styles.scanFrame}>
        <View style={[styles.corner, styles.cornerTL]} />
        <View style={[styles.corner, styles.cornerTR]} />
        <View style={[styles.corner, styles.cornerBL]} />
        <View style={[styles.corner, styles.cornerBR]} />
        <Animated.View style={[styles.scanBeam, { transform: [{ translateY }] }]} />
      </View>
      <Text style={styles.scanHint}>Yemeği çerçeve içine alın</Text>
    </View>
  );
}

// ── Ana Ekran ─────────────────────────────────────────────────

type Screen = 'camera' | 'analyzing' | 'result';

export default function FoodCameraScreen() {
  const insets = useSafeAreaInsets();
  const nav    = useNavigation<any>();
  const { addToDailyLog } = useAppStore();
  const cameraRef = useRef<any>(null);

  const [screen, setScreen]           = useState<Screen>('camera');
  const [hasPermission, setHasPermission] = useState<boolean | null>(null);
  const [torchOn, setTorchOn]         = useState(false);
  const [capturedUri, setCapturedUri] = useState<string | null>(null);
  const [result, setResult]           = useState<LogMealResult | null>(null);
  const [error, setError]             = useState<string | null>(null);
  const [selectedFood, setSelectedFood] = useState<LogMealFood | null>(null);

  // Porsiyon ayarı
  const [portion, setPortion]         = useState(200);

  // İzin
  useEffect(() => {
    Camera.requestCameraPermissionsAsync().then(({ status }) => {
      setHasPermission(status === 'granted');
    });
  }, []);

  // Hesaplama — result.gi API'den gelir (Supabase + tahmin zinciri)
  const gi = result?.gi ?? 55;
  // servingSize 0 olursa 100 varsay (100g başına olarak kabul et)
  const safeServing = result && result.nutrition.servingSize > 0 ? result.nutrition.servingSize : 100;
  const carbs100 = result ? (result.nutrition.carbs / safeServing) * 100 : 0;
  const hasMacros = result ? (result.nutrition.calories > 0 || result.nutrition.carbs > 0) : false;

  const scaledNutrition = result ? {
    calories: Math.round((result.nutrition.calories / safeServing) * portion),
    carbs:    Math.round((result.nutrition.carbs    / safeServing) * portion * 10) / 10,
    protein:  Math.round((result.nutrition.protein  / safeServing) * portion * 10) / 10,
    fat:      Math.round((result.nutrition.fat       / safeServing) * portion * 10) / 10,
    fiber:    Math.round((result.nutrition.fiber     / safeServing) * portion * 10) / 10,
  } : null;

  const gl = scaledNutrition ? calcGL(gi, carbs100, portion) : 0;
  const glStatus: 'green' | 'yellow' | 'red' = gl >= 20 ? 'red' : gl >= 10 ? 'yellow' : 'green';

  // ── Fotoğraf Çek ─────────────────────────────────────────────

  const takePicture = async () => {
    if (!cameraRef.current) return;
    try {
      const photo = await cameraRef.current.takePictureAsync({ quality: 0.75, base64: false });
      await startAnalysis(photo.uri);
    } catch {
      Alert.alert('Hata', 'Fotoğraf çekilemedi, tekrar deneyin.');
    }
  };

  // ── Galeriden Seç ─────────────────────────────────────────────

  const pickFromGallery = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('İzin Gerekli', 'Galerinize erişim izni verilmedi.');
      return;
    }
    const picked = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'],
      quality: 0.75,
      allowsEditing: true,
      aspect: [4, 3],
    });
    if (!picked.canceled && picked.assets[0]) {
      await startAnalysis(picked.assets[0].uri);
    }
  };

  // ── Analiz Başlat ─────────────────────────────────────────────

  const startAnalysis = async (uri: string) => {
    setCapturedUri(uri);
    setError(null);
    setScreen('analyzing');
    try {
      const analysisResult = await analyzeFoodPhoto(uri);
      setResult(analysisResult);
      setSelectedFood(analysisResult.foods[0]);
      setPortion(analysisResult.nutrition.servingSize || 200);
      setScreen('result');
    } catch (e: any) {
      setError(e?.message ?? 'Analiz başarısız oldu.');
      setScreen('camera');
    }
  };

  // ── Günlüğe Ekle ─────────────────────────────────────────────

  const handleAddToLog = () => {
    if (!selectedFood || !scaledNutrition) return;
    addToDailyLog({
      foodId:       `logmeal-${Date.now()}`,
      foodName:     selectedFood.name,
      portion,
      portionText:  `${portion}g`,
      glycemicLoad: gl,
      trafficLight: glStatus,
      mealType:     undefined,
      mealCategory: 'tabak',
    });
    if (glStatus === 'red') scheduleHighGLNotification();
    Alert.alert(
      'Eklendi ✅',
      `${selectedFood.name} günlüğe kaydedildi!\nGL: ${gl}`,
      [
        { text: 'Günlüğü Gör',  onPress: () => nav.navigate('MainTabs', { screen: 'DailyLog' }) },
        { text: 'Öğüne Ekle', onPress: () => nav.navigate('MainTabs', { screen: 'Meals' }) },
        { text: 'Tamam' },
      ]
    );
  };

  // ── İzin Yok ──────────────────────────────────────────────────

  if (hasPermission === false) {
    return (
      <View style={styles.centered}>
        <Ionicons name="camera-outline" size={64} color="#9CA3AF" />
        <Text style={styles.permTitle}>Kamera Erişimi Gerekli</Text>
        <Text style={styles.permSub}>Yemek analizi için kamera iznine ihtiyacınız var.</Text>
        <TouchableOpacity
          onPress={() => nav.goBack()}
          style={[styles.pillBtn, { backgroundColor: '#0D7A6B', marginTop: 20 }]}
        >
          <Text style={styles.pillBtnText}>Geri Dön</Text>
        </TouchableOpacity>
      </View>
    );
  }

  if (hasPermission === null) {
    return <View style={styles.centered}><ActivityIndicator size="large" color="#0D7A6B" /></View>;
  }

  // ── ANALİZ OLUYOR ekranı ──────────────────────────────────────

  if (screen === 'analyzing') {
    return (
      <View style={styles.centered}>
        {capturedUri && (
          <Image source={{ uri: capturedUri }} style={styles.previewImg} resizeMode="cover" />
        )}
        <LinearGradient
          colors={['transparent', 'rgba(0,0,0,0.92)']}
          style={StyleSheet.absoluteFill}
        />
        <View style={{ alignItems: 'center', zIndex: 2 }}>
          <View style={styles.aiIconWrap}>
            <ActivityIndicator size="large" color="#0D7A6B" />
          </View>
          <Text style={styles.analyzingTitle}>Yemek Analiz Ediliyor</Text>
          <Text style={styles.analyzingSubtitle}>
            AI destekli makro hesaplama yapılıyor...
          </Text>
          <View style={styles.analyzingSteps}>
            {[
              '🔍  AI ile yemek tespit ediliyor...',
              '🥗  Makro değerler alınıyor...',
              '📊  Glisemik indeks hesaplanıyor...',
            ].map((s, i) => (
              <View key={i} style={styles.analyzingStep}>
                <ActivityIndicator size="small" color="#10B981" />
                <Text style={styles.analyzingStepText}>{s}</Text>
              </View>
            ))}
          </View>
        </View>
      </View>
    );
  }

  // ── SONUÇ ekranı ──────────────────────────────────────────────

  if (screen === 'result' && result && scaledNutrition && selectedFood) {
    const c = glColor(gl);

    return (
      <View style={{ flex: 1, backgroundColor: '#0A0A0A' }}>
        {/* Fotoğraf arka plan */}
        {capturedUri && (
          <Image source={{ uri: capturedUri }} style={styles.resultBg} resizeMode="cover" />
        )}
        <LinearGradient
          colors={['rgba(0,0,0,0.45)', 'rgba(0,0,0,0.92)', '#0A0A0A']}
          style={StyleSheet.absoluteFill}
        />

        {/* Üst bar */}
        <View style={[styles.topBar, { paddingTop: insets.top + 8 }]}>
          <TouchableOpacity onPress={() => setScreen('camera')} style={styles.overlayBtn}>
            <Ionicons name="arrow-back" size={22} color="#fff" />
          </TouchableOpacity>
          <View style={styles.successPill}>
            <Ionicons name="sparkles" size={14} color="#10B981" />
            <Text style={styles.successPillText}>
              {result?.occasion
                ? { breakfast:'Kahvaltı', lunch:'Öğle', dinner:'Akşam', snack:'Atıştırmalık' }[result.occasion] ?? 'Yemek Tanındı'
                : 'Yemek Tanındı'}
            </Text>
          </View>
          <TouchableOpacity onPress={() => startAnalysis(capturedUri!)} style={styles.overlayBtn}>
            <Ionicons name="refresh" size={22} color="#fff" />
          </TouchableOpacity>
        </View>

        <ScrollView
          contentContainerStyle={{ paddingTop: SH * 0.22, paddingBottom: 40 }}
          showsVerticalScrollIndicator={false}
        >
          {/* GL Rozet */}
          <View style={{ alignItems: 'center', marginBottom: 20 }}>
            <View style={[styles.glCircle, { borderColor: c, shadowColor: c }]}>
              <Text style={[styles.glVal, { color: c }]}>{gl}</Text>
              <Text style={[styles.glLbl, { color: c }]}>GL</Text>
            </View>
            <View style={[styles.glStatusPill, { backgroundColor: c + '22', borderColor: c + '44' }]}>
              <View style={[styles.glDot, { backgroundColor: c }]} />
              <Text style={[styles.glStatusText, { color: c }]}>
                {glStatus === 'green' ? 'Güvenli Bölge' : glStatus === 'yellow' ? 'Dikkat Bölgesi' : 'Risk Bölgesi!'}
              </Text>
            </View>
          </View>

          {/* Sonuç kartı */}
          <View style={styles.resultCard}>
            {/* Yemek adı + güven */}
            <Text style={styles.foodTitle}>{selectedFood.name}</Text>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 12, flexWrap: 'wrap' }}>
              {/* Güven skoru */}
              <View style={[styles.confBadge, { backgroundColor: selectedFood.confidence > 0.8 ? '#10B98122' : '#F59E0B22' }]}>
                <Text style={[styles.confText, { color: selectedFood.confidence > 0.8 ? '#10B981' : '#F59E0B' }]}>
                  %{Math.round(selectedFood.confidence * 100)} güven
                </Text>
              </View>
              {/* GI rozeti — kaynak göster */}
              <View style={[styles.confBadge, { backgroundColor: '#6366F122' }]}>
                <Text style={[styles.confText, { color: '#6366F1' }]}>
                  Gİ {gi}
                </Text>
              </View>
            </View>

            {/* Makro değerler alınamadıysa uyarı */}
            {!hasMacros && (
              <View style={{ backgroundColor: '#FFF7ED', borderRadius: 12, padding: 12, marginBottom: 12, flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                <Ionicons name="information-circle" size={18} color="#F59E0B" />
                <Text style={{ fontSize: 12, color: '#92400E', flex: 1, lineHeight: 18 }}>
                  Makro değerler bu görsel için hesaplanamadı. Porsiyon kaydedilecek, ancak GL tahmini kullanılacak.
                </Text>
              </View>
            )}

            {/* Alternatif yemekler */}
            {result.foods.length > 1 && (
              <View style={{ marginBottom: 14 }}>
                <Text style={styles.altTitle}>Diğer seçenekler:</Text>
                <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                  <View style={{ flexDirection: 'row', gap: 8 }}>
                    {result.foods.slice(1, 4).map((f, i) => (
                      <TouchableOpacity
                        key={i}
                        onPress={() => setSelectedFood(f)}
                        style={[
                          styles.altBtn,
                          selectedFood.name === f.name && styles.altBtnActive,
                        ]}
                      >
                        <Text style={[styles.altBtnText, selectedFood.name === f.name && { color: '#0D7A6B' }]}>
                          {f.name}
                        </Text>
                        <Text style={styles.altBtnConf}>%{Math.round(f.confidence * 100)}</Text>
                      </TouchableOpacity>
                    ))}
                  </View>
                </ScrollView>
              </View>
            )}

            {/* Porsiyon seçici */}
            <View style={styles.portionSection}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6 }}>
                <Text style={styles.portionLabel}>Porsiyon</Text>
                <Text style={styles.portionVal}>{portion} g</Text>
              </View>
              <Slider
                style={{ width: '100%', height: 40 }}
                minimumValue={50}
                maximumValue={600}
                step={25}
                value={portion}
                onValueChange={v => setPortion(Math.round(v))}
                minimumTrackTintColor="#0D7A6B"
                maximumTrackTintColor="#374151"
                thumbTintColor="#0D7A6B"
              />
              <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                <Text style={styles.portionMark}>50g</Text>
                <Text style={styles.portionMark}>600g</Text>
              </View>
            </View>

            {/* Kalori büyük gösterim */}
            <View style={styles.calorieRow}>
              <Text style={{ fontSize: 28 }}>🔥</Text>
              <View style={{ marginLeft: 12 }}>
                <Text style={styles.calorieVal}>{scaledNutrition.calories}</Text>
                <Text style={styles.calorieUnit}>kcal · {portion}g için</Text>
              </View>
            </View>

            {/* Makro grid */}
            <View style={styles.macroGrid}>
              <MacroBox icon="🌾" label="Karb"    value={scaledNutrition.carbs}   unit="g"    color="#F59E0B" />
              <MacroBox icon="💪" label="Protein" value={scaledNutrition.protein} unit="g"    color="#3B82F6" />
              <MacroBox icon="🫒" label="Yağ"     value={scaledNutrition.fat}     unit="g"    color="#8B5CF6" />
              <MacroBox icon="🌿" label="Lif"     value={scaledNutrition.fiber}   unit="g"    color="#10B981" />
            </View>

            {/* Uyarı banner */}
            {glStatus === 'red' && (
              <View style={styles.warnBanner}>
                <Ionicons name="warning" size={20} color="#FFF" style={{ marginRight: 8 }} />
                <Text style={styles.warnText}>
                  Bu porsiyon kan şekerini hızla yükseltebilir! Miktarı azaltmayı düşünün.
                </Text>
              </View>
            )}

            {/* Eylem butonlar */}
            <View style={styles.actionRow}>
              <TouchableOpacity
                onPress={() => setScreen('camera')}
                style={styles.btnSecondary}
              >
                <Ionicons name="camera-outline" size={18} color="#0D7A6B" />
                <Text style={styles.btnSecondaryText}>Yeni Çek</Text>
              </TouchableOpacity>

              <TouchableOpacity
                onPress={handleAddToLog}
                style={{ flex: 2, borderRadius: 18, overflow: 'hidden' }}
              >
                <LinearGradient
                  colors={['#0A5748', '#0D7A6B']}
                  start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
                  style={styles.btnPrimary}
                >
                  <Ionicons name="add-circle" size={20} color="#FFF" style={{ marginRight: 6 }} />
                  <Text style={styles.btnPrimaryText}>Günlüğe Ekle</Text>
                </LinearGradient>
              </TouchableOpacity>
            </View>
          </View>
        </ScrollView>
      </View>
    );
  }

  // ── KAMERA ekranı ─────────────────────────────────────────────

  return (
    <View style={{ flex: 1, backgroundColor: '#000' }}>
      <CameraView
        ref={cameraRef}
        style={StyleSheet.absoluteFill}
        facing="back"
        enableTorch={torchOn}
      />

      {/* Overlay */}
      <View style={StyleSheet.absoluteFill} pointerEvents="box-none">
        {/* Üst gradient + butonlar */}
        <LinearGradient
          colors={['rgba(0,0,0,0.75)', 'transparent']}
          style={{ paddingTop: insets.top + 12, paddingHorizontal: 20, paddingBottom: 50 }}
        >
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
            <TouchableOpacity onPress={() => nav.goBack()} style={styles.overlayBtn}>
              <Ionicons name="close" size={24} color="#fff" />
            </TouchableOpacity>
            <View style={{ alignItems: 'center' }}>
              <Text style={styles.cameraTitle}>Yemek Tara</Text>
              <Text style={styles.cameraSub}>AI makro analizi</Text>
            </View>
            <TouchableOpacity
              onPress={() => setTorchOn(!torchOn)}
              style={[styles.overlayBtn, torchOn && { backgroundColor: '#F59E0B' }]}
            >
              <Ionicons name={torchOn ? 'flash' : 'flash-outline'} size={22} color="#fff" />
            </TouchableOpacity>
          </View>
        </LinearGradient>

        {/* Tarama animasyonu */}
        <ScanAnimation />

        {/* Alt kısım */}
        <LinearGradient
          colors={['transparent', 'rgba(0,0,0,0.9)']}
          style={{ flex: 1, justifyContent: 'flex-end', paddingBottom: insets.bottom + 30, paddingHorizontal: 24 }}
        >
          {/* Hata mesajı */}
          {error && (
            <View style={styles.errorBox}>
              <Ionicons name="alert-circle" size={18} color="#EF4444" style={{ marginRight: 6 }} />
              <Text style={styles.errorText}>{error}</Text>
            </View>
          )}

          {/* Çek butonu + galeri */}
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 20 }}>
            <TouchableOpacity onPress={pickFromGallery} style={styles.galleryBtn}>
              <Ionicons name="images-outline" size={26} color="#fff" />
              <Text style={styles.galleryBtnText}>Galeri</Text>
            </TouchableOpacity>

            <TouchableOpacity onPress={takePicture} style={styles.captureBtn} activeOpacity={0.85}>
              <LinearGradient
                colors={['#0D7A6B', '#10B981']}
                start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
                style={styles.captureBtnInner}
              >
                <Ionicons name="camera" size={34} color="#fff" />
              </LinearGradient>
            </TouchableOpacity>

            <View style={{ width: 80 }} />
          </View>

          <Text style={styles.cameraFooter}>
            Yemeğin tamamını çerçeve içinde gösterin
          </Text>
        </LinearGradient>
      </View>
    </View>
  );
}

// ── Stiller ───────────────────────────────────────────────────

const styles = StyleSheet.create({
  centered: {
    flex: 1, backgroundColor: '#0A0A0A',
    alignItems: 'center', justifyContent: 'center', padding: 24,
  },
  permTitle: { fontSize: 20, fontWeight: '800', color: '#F9FAFB', marginTop: 18, textAlign: 'center' },
  permSub:   { fontSize: 14, color: '#9CA3AF', marginTop: 8, textAlign: 'center', lineHeight: 20 },
  pillBtn:   { paddingHorizontal: 28, paddingVertical: 14, borderRadius: 20 },
  pillBtnText:{ fontSize: 16, fontWeight: '800', color: '#FFF' },

  // Analiz ekranı
  previewImg:       { ...StyleSheet.absoluteFillObject, width: '100%', height: '100%' },
  aiIconWrap:       { width: 90, height: 90, borderRadius: 45, backgroundColor: 'rgba(13,122,107,0.2)', alignItems: 'center', justifyContent: 'center', marginBottom: 20, borderWidth: 2, borderColor: '#0D7A6B' },
  analyzingTitle:   { fontSize: 22, fontWeight: '900', color: '#F9FAFB', marginBottom: 8 },
  analyzingSubtitle:{ fontSize: 14, color: '#9CA3AF', marginBottom: 24, textAlign: 'center' },
  analyzingSteps:   { gap: 10, alignSelf: 'stretch', paddingHorizontal: 32 },
  analyzingStep:    { flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: 'rgba(16,185,129,0.1)', padding: 12, borderRadius: 12 },
  analyzingStepText:{ color: '#D1FAE5', fontWeight: '600', fontSize: 13 },

  // Sonuç ekranı
  resultBg: { position: 'absolute', top: 0, left: 0, right: 0, height: SH * 0.42, width: SW },
  topBar:   { position: 'absolute', top: 0, left: 0, right: 0, zIndex: 10, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 20 },
  overlayBtn: { width: 44, height: 44, borderRadius: 22, backgroundColor: 'rgba(255,255,255,0.15)', alignItems: 'center', justifyContent: 'center' },
  successPill: { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: 'rgba(16,185,129,0.25)', paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20 },
  successPillText: { color: '#10B981', fontWeight: '700', fontSize: 13 },

  glCircle: {
    width: 110, height: 110, borderRadius: 55,
    alignItems: 'center', justifyContent: 'center',
    backgroundColor: '#111827', borderWidth: 3,
    shadowOffset: { width: 0, height: 0 }, shadowOpacity: 0.6, shadowRadius: 16, elevation: 10,
    marginBottom: 10,
  },
  glVal:         { fontSize: 42, fontWeight: '900' },
  glLbl:         { fontSize: 15, fontWeight: '700', marginTop: -4 },
  glStatusPill:  { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 14, paddingVertical: 6, borderRadius: 14, borderWidth: 1 },
  glDot:         { width: 8, height: 8, borderRadius: 4 },
  glStatusText:  { fontSize: 13, fontWeight: '800' },

  resultCard: {
    marginHorizontal: 16, marginTop: 16,
    backgroundColor: '#111827', borderRadius: 28,
    padding: 22,
  },
  foodTitle:     { fontSize: 22, fontWeight: '900', color: '#F9FAFB', marginBottom: 8 },
  confBadge:     { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8 },
  confText:      { fontSize: 12, fontWeight: '800' },
  giEstimate:    { fontSize: 13, color: '#6B7280', fontWeight: '600' },

  altTitle:      { fontSize: 12, fontWeight: '700', color: '#6B7280', marginBottom: 8, textTransform: 'uppercase', letterSpacing: 0.5 },
  altBtn:        { paddingHorizontal: 14, paddingVertical: 8, borderRadius: 12, backgroundColor: '#1F2937', borderWidth: 1.5, borderColor: 'transparent' },
  altBtnActive:  { borderColor: '#0D7A6B', backgroundColor: '#0D7A6B1A' },
  altBtnText:    { fontSize: 13, fontWeight: '700', color: '#9CA3AF' },
  altBtnConf:    { fontSize: 10, color: '#6B7280', marginTop: 2 },

  portionSection: { backgroundColor: '#1F2937', borderRadius: 16, padding: 16, marginBottom: 16 },
  portionLabel:  { fontSize: 13, fontWeight: '700', color: '#9CA3AF' },
  portionVal:    { fontSize: 20, fontWeight: '900', color: '#F9FAFB' },
  portionMark:   { fontSize: 11, color: '#6B7280', fontWeight: '600' },

  calorieRow:    { flexDirection: 'row', alignItems: 'center', backgroundColor: '#1F2937', borderRadius: 16, padding: 16, marginBottom: 14 },
  calorieVal:    { fontSize: 36, fontWeight: '900', color: '#F97316' },
  calorieUnit:   { fontSize: 13, color: '#9A3412', fontWeight: '600' },

  macroGrid:     { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 16 },
  macroBox:      { width: '47%', borderRadius: 16, padding: 14, alignItems: 'center', borderWidth: 1.5 },
  macroVal:      { fontSize: 22, fontWeight: '900' },
  macroUnit:     { fontSize: 11, fontWeight: '600', color: '#6B7280', marginTop: 1 },
  macroLabel:    { fontSize: 11, fontWeight: '600', color: '#9CA3AF', marginTop: 4 },

  warnBanner:    { flexDirection: 'row', alignItems: 'center', backgroundColor: '#EF4444', padding: 14, borderRadius: 16, marginBottom: 16 },
  warnText:      { flex: 1, color: '#FFF', fontWeight: '700', fontSize: 13, lineHeight: 18 },

  actionRow:     { flexDirection: 'row', gap: 12 },
  btnSecondary:  { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, paddingVertical: 16, borderRadius: 18, borderWidth: 2, borderColor: '#0D7A6B' },
  btnSecondaryText: { fontSize: 15, fontWeight: '800', color: '#0D7A6B' },
  btnPrimary:    { paddingVertical: 17, flexDirection: 'row', justifyContent: 'center', alignItems: 'center' },
  btnPrimaryText:{ fontSize: 16, fontWeight: '800', color: '#FFF' },

  // Kamera ekranı
  scanOverlay: { ...StyleSheet.absoluteFillObject, alignItems: 'center', justifyContent: 'center' },
  scanFrame:   { width: SW * 0.78, height: SW * 0.6, position: 'relative', overflow: 'hidden' },
  corner:      { position: 'absolute', width: 32, height: 32, borderColor: '#10B981', borderWidth: 4 },
  cornerTL:    { top: 0, left: 0, borderRightWidth: 0, borderBottomWidth: 0, borderTopLeftRadius: 8 },
  cornerTR:    { top: 0, right: 0, borderLeftWidth: 0, borderBottomWidth: 0, borderTopRightRadius: 8 },
  cornerBL:    { bottom: 0, left: 0, borderRightWidth: 0, borderTopWidth: 0, borderBottomLeftRadius: 8 },
  cornerBR:    { bottom: 0, right: 0, borderLeftWidth: 0, borderTopWidth: 0, borderBottomRightRadius: 8 },
  scanBeam:    { position: 'absolute', left: 8, right: 8, height: 2.5, backgroundColor: '#10B981', shadowColor: '#10B981', shadowOffset: { width: 0, height: 0 }, shadowOpacity: 0.9, shadowRadius: 6, elevation: 4, borderRadius: 2 },
  scanHint:    { color: 'rgba(255,255,255,0.8)', fontSize: 14, fontWeight: '600', marginTop: 20 },

  cameraTitle:   { fontSize: 17, fontWeight: '800', color: '#FFF', textAlign: 'center' },
  cameraSub:     { fontSize: 12, color: 'rgba(255,255,255,0.6)', fontWeight: '500', marginTop: 2 },

  captureBtn:    { width: 80, height: 80, borderRadius: 40, borderWidth: 4, borderColor: 'rgba(255,255,255,0.5)', overflow: 'hidden' },
  captureBtnInner:{ flex: 1, alignItems: 'center', justifyContent: 'center' },
  galleryBtn:    { width: 80, alignItems: 'center', gap: 4 },
  galleryBtnText:{ color: 'rgba(255,255,255,0.8)', fontSize: 12, fontWeight: '600' },

  errorBox:      { flexDirection: 'row', alignItems: 'center', backgroundColor: 'rgba(239,68,68,0.18)', padding: 12, borderRadius: 14, marginBottom: 16, borderWidth: 1, borderColor: 'rgba(239,68,68,0.3)' },
  errorText:     { flex: 1, color: '#FCA5A5', fontWeight: '600', fontSize: 13 },
  cameraFooter:  { color: 'rgba(255,255,255,0.45)', fontSize: 12, textAlign: 'center', marginTop: 16, fontWeight: '500' },
});
