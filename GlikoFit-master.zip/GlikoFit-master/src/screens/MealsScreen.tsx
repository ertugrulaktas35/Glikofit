import React, { useState, useEffect } from 'react';
import {
  View, Text, FlatList, TouchableOpacity, TextInput,
  ActivityIndicator, Alert, Modal, StyleSheet, ScrollView,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Slider from '@react-native-community/slider';
import { supabase } from '../lib/supabase';
import type { Food } from '../types/database';
import { useAppStore } from '../store/useAppStore';
import type { MealType, MealCategory } from '../store/useAppStore';
import { getCarbsPer100g } from '../lib/fatsecret';
import { scheduleHighGLNotification } from '../services/notificationService';

// ── Sabitler ──────────────────────────────────────────────────

const MEALS: { type: MealType; label: string; icon: string; timeRange: string; color: string }[] = [
  { type: 'kahvalti', label: 'Kahvaltı',       icon: '🌅', timeRange: '06:00–10:00', color: '#F59E0B' },
  { type: 'ogle',     label: 'Öğle Yemeği',    icon: '☀️', timeRange: '12:00–14:00', color: '#10B981' },
  { type: 'aksam',    label: 'Akşam Yemeği',   icon: '🌙', timeRange: '18:00–21:00', color: '#6366F1' },
  { type: 'ara',      label: 'Ara Öğün',        icon: '🍎', timeRange: 'Herhangi',    color: '#EC4899' },
];

const CATEGORIES: { type: MealCategory; label: string; icon: string }[] = [
  { type: 'tabak',   label: 'Tabak',    icon: '🍽️' },
  { type: 'icecek',  label: 'İçecek',   icon: '🥤' },
  { type: 'meyve',   label: 'Meyve',    icon: '🍎' },
  { type: 'diger',   label: 'Diğer',    icon: '🥨' },
];

// ── Akıllı Porsiyon ──────────────────────────────────────────

function getSmartPortion(name: string, category: string, mealCat?: MealCategory): { unit: string; grams: number } {
  const n = (name ?? '').toLocaleLowerCase('tr');
  const c = (category ?? '').toLocaleLowerCase('tr');

  // İçecek kategorisi seçilmişse her zaman bardak
  if (mealCat === 'icecek') return { unit: 'Bardak', grams: 200 };

  if (n.includes('gazlı') || n.includes('gazlı içecek') || n.includes('kola') || n.includes('soda') || n.includes('limonata') || n.includes('ayran') || n.includes('komposto') || n.includes('şerbet')) return { unit: 'Bardak', grams: 200 };
  if (n.includes('ekmek') || n.includes('pide') || n.includes('tost') || n.includes('pizza') || n.includes('börek') || n.includes('poğaça') || n.includes('karpuz') || n.includes('kavun')) return { unit: 'Dilim', grams: 30 };
  if (n.includes('pasta') || n.includes('kek') || n.includes('turta') || n.includes('cheesecake')) return { unit: 'Dilim', grams: 80 };
  if (n.includes('bisküvi') || n.includes('kurabiye') || n.includes('kraker') || n.includes('çikolata') || n.includes('waffle') || n.includes('muffin')) return { unit: 'Tane', grams: 25 };
  if (n.includes('yumurta') || n.includes('köfte') || n.includes('sarma') || n.includes('dolma') || n.includes('simit') || n.includes('lahmacun')) return { unit: 'Adet', grams: 60 };
  if (n.includes('elma') || n.includes('armut') || n.includes('portakal') || n.includes('muz') || n.includes('şeftali') || n.includes('nar') || n.includes('mango') || n.includes('avokado') || n.includes('kivi') || n.includes('mandalina') || n.includes('greyfurt')) return { unit: 'Adet', grams: 120 };
  if (n.includes('peynir') || n.includes('sucuk') || n.includes('salam') || n.includes('pastırma') || n.includes('kaşar')) return { unit: 'Parça', grams: 30 };
  if (n.includes('çorba') || n.includes('yoğurt') || n.includes('müsli') || n.includes('granola') || n.includes('salata')) return { unit: 'Kase', grams: 200 };
  if (n.includes('süt') || n.includes('kefir') || n.includes('meyve suyu') || n.includes('smoothie') || n.includes('kahve') || n.includes('çay')) return { unit: 'Bardak', grams: 200 };
  if (n.includes('fıstık') || n.includes('badem') || n.includes('ceviz') || n.includes('fındık') || n.includes('kaju') || n.includes('kuruyemiş')) return { unit: 'Avuç', grams: 30 };
  if (n.includes('bal') || n.includes('şeker') || n.includes('reçel') || n.includes('pekmez') || n.includes('tahin') || n.includes('tereyağı') || n.includes('zeytinyağı') || n.includes('sos')) return { unit: 'Kaşık', grams: 15 };
  if (n.includes('pilav') || n.includes('makarna') || n.includes('et') || n.includes('tavuk') || n.includes('balık') || n.includes('kebap') || n.includes('fasulye') || n.includes('nohut') || n.includes('mercimek')) return { unit: 'Tabak', grams: 200 };
  if (c.includes('çorba')) return { unit: 'Kase', grams: 200 };
  if (c.includes('meyve')) return { unit: 'Adet', grams: 120 };
  if (c.includes('içecek')) return { unit: 'Bardak', grams: 200 };
  if (c.includes('kuruyemiş') || c.includes('çerez')) return { unit: 'Avuç', grams: 30 };
  if (c.includes('ekmek') || c.includes('hamur') || c.includes('unlu')) return { unit: 'Dilim', grams: 30 };
  if (c.includes('tatlı') || c.includes('pasta')) return { unit: 'Dilim', grams: 80 };
  if (c.includes('atıştırmalık') || c.includes('bisküvi')) return { unit: 'Tane', grams: 25 };
  return { unit: 'Porsiyon', grams: 150 };
}

function glColor(gl: number): string {
  if (gl >= 20) return '#EF4444';
  if (gl >= 10) return '#F59E0B';
  return '#10B981';
}

// ── Tip Tanımları ─────────────────────────────────────────────

interface MealItem {
  id: string;
  food: Food;
  portion: number;
  portionText: string;
  carbs100: number;
  mealType: MealType;
  mealCategory: MealCategory;
}

type MealData = Record<MealType, MealItem[]>;

// ── Ana Ekran ─────────────────────────────────────────────────

export default function MealsScreen({ navigation }: any) {
  const insets = useSafeAreaInsets();
  const { addToDailyLog } = useAppStore();

  const [activeMeal, setActiveMeal]         = useState<MealType>(() => {
    const h = new Date().getHours();
    if (h >= 6 && h < 11)  return 'kahvalti';
    if (h >= 12 && h < 15) return 'ogle';
    if (h >= 18 && h < 22) return 'aksam';
    return 'kahvalti';
  });
  const [activeCategory, setActiveCategory] = useState<MealCategory>('tabak');
  const [mealData, setMealData]             = useState<MealData>({ kahvalti: [], ogle: [], aksam: [], ara: [] });

  // Arama
  const [searchQuery, setSearchQuery]       = useState('');
  const [searchResults, setSearchResults]   = useState<Food[]>([]);
  const [isSearching, setIsSearching]       = useState(false);

  // Modal
  const [selectedFood, setSelectedFood]     = useState<Food | null>(null);
  const [portion, setPortion]               = useState(1);
  const [measureMode, setMeasureMode]       = useState<'pratik' | 'gram'>('pratik');
  const [gramValue, setGramValue]           = useState(100);
  const [tempCarbs100, setTempCarbs100]     = useState<number | null>(null);
  const [fetchingCarbs, setFetchingCarbs]   = useState(false);

  const currentMeal   = MEALS.find(m => m.type === activeMeal)!;
  const currentItems  = mealData[activeMeal];
  const smartMeasure  = selectedFood
    ? getSmartPortion(selectedFood.name, selectedFood.category, activeCategory)
    : { unit: 'Porsiyon', grams: 150 };

  const actualGrams   = measureMode === 'gram' ? gramValue : portion * smartMeasure.grams;
  const totalGL       = Math.round(
    currentItems.reduce((acc, item) => {
      const carbs = (item.carbs100 / 100) * item.portion;
      return acc + (item.food.gi_value * carbs) / 100;
    }, 0) * 10
  ) / 10;
  const grandTotalGL  = Math.round(
    Object.values(mealData).flat().reduce((acc, item) => {
      const carbs = (item.carbs100 / 100) * item.portion;
      return acc + (item.food.gi_value * carbs) / 100;
    }, 0) * 10
  ) / 10;

  const modalGL = selectedFood && tempCarbs100 !== null
    ? Math.round((selectedFood.gi_value * (tempCarbs100 / 100) * actualGrams) / 100 * 10) / 10
    : 0;

  // Arama debounce
  useEffect(() => {
    if (searchQuery.length < 2) { setSearchResults([]); return; }
    const timer = setTimeout(async () => {
      setIsSearching(true);
      const { data } = await supabase.from('foods').select('*').ilike('name', `%${searchQuery}%`).limit(8);
      setSearchResults(data || []);
      setIsSearching(false);
    }, 400);
    return () => clearTimeout(timer);
  }, [searchQuery]);

  const openModal = async (food: Food) => {
    setSelectedFood(food);
    setPortion(1);
    setGramValue(100);
    setMeasureMode('pratik');
    if (food.carbs_per_100g > 0) {
      setTempCarbs100(food.carbs_per_100g);
    } else {
      setFetchingCarbs(true);
      const c = await getCarbsPer100g(food.name);
      setTempCarbs100(c ?? 0);
      setFetchingCarbs(false);
    }
    setSearchQuery('');
    setSearchResults([]);
  };

  const confirmAdd = () => {
    if (!selectedFood || tempCarbs100 === null) return;
    const portionText = measureMode === 'gram'
      ? `${gramValue}g`
      : `${portion} ${smartMeasure.unit}`;
    const newItem: MealItem = {
      id: `${Date.now()}-${Math.random()}`,
      food: selectedFood,
      portion: actualGrams,
      portionText,
      carbs100: tempCarbs100,
      mealType: activeMeal,
      mealCategory: activeCategory,
    };
    setMealData(prev => ({
      ...prev,
      [activeMeal]: [...prev[activeMeal], newItem],
    }));
    setSelectedFood(null);
  };

  const removeItem = (mealType: MealType, id: string) => {
    setMealData(prev => ({
      ...prev,
      [mealType]: prev[mealType].filter(i => i.id !== id),
    }));
  };

  const handleSaveMeal = () => {
    if (currentItems.length === 0) return;
    currentItems.forEach(item => {
      const carbs  = (item.carbs100 / 100) * item.portion;
      const gl     = Math.round((item.food.gi_value * carbs) / 100 * 10) / 10;
      const status: 'green' | 'yellow' | 'red' = gl >= 20 ? 'red' : gl >= 10 ? 'yellow' : 'green';
      addToDailyLog({
        foodId:       item.food.id.toString(),
        foodName:     item.food.name,
        portion:      item.portion,
        portionText:  item.portionText,
        glycemicLoad: gl,
        trafficLight: status,
        mealType:     item.mealType,
        mealCategory: item.mealCategory,
      });
    });
    if (totalGL >= 20) scheduleHighGLNotification();
    setMealData(prev => ({ ...prev, [activeMeal]: [] }));
    Alert.alert('Kaydedildi ✅', `${currentMeal.label} günlüğe eklendi!`, [
      { text: 'Günlüğü Gör', onPress: () => navigation.navigate('DailyLog') },
      { text: 'Tamam' },
    ]);
  };

  const totalFoodCount = Object.values(mealData).flat().length;

  return (
    <View style={{ flex: 1, backgroundColor: '#F5F7FA' }}>
      <FlatList
        data={currentItems}
        keyExtractor={item => item.id}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: currentItems.length > 0 ? 230 : 130 }}
        keyboardShouldPersistTaps="handled"
        ListHeaderComponent={
          <View>
            {/* ── HEADER ── */}
            <LinearGradient
              colors={['#063830', '#0A5748', '#0D7A6B']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={[styles.header, { paddingTop: insets.top + 12 }]}
            >
              <View style={styles.deco} pointerEvents="none" />
              <View style={styles.deco2} pointerEvents="none" />

              <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
                <View>
                  <Text style={styles.eyebrow}>Bugünkü Beslenmen</Text>
                  <Text style={styles.title}>Öğünler 🍽️</Text>
                </View>
                {totalFoodCount > 0 && (
                  <View style={styles.grandGlBadge}>
                    <Text style={styles.grandGlLabel}>Günlük GL</Text>
                    <Text style={[styles.grandGlVal, { color: glColor(grandTotalGL) }]}>{grandTotalGL}</Text>
                  </View>
                )}
              </View>

              {/* Öğün Seçici */}
              <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 0 }}>
                <View style={{ flexDirection: 'row', gap: 8, paddingRight: 8 }}>
                  {MEALS.map(m => {
                    const count = mealData[m.type].length;
                    const isActive = activeMeal === m.type;
                    return (
                      <TouchableOpacity
                        key={m.type}
                        onPress={() => setActiveMeal(m.type)}
                        style={[
                          styles.mealTab,
                          isActive && { backgroundColor: '#FFFFFF' },
                          !isActive && { backgroundColor: 'rgba(255,255,255,0.15)' },
                        ]}
                      >
                        <Text style={{ fontSize: 16 }}>{m.icon}</Text>
                        <Text style={[styles.mealTabLabel, isActive && { color: '#0D7A6B' }]}>
                          {m.label}
                        </Text>
                        {count > 0 && (
                          <View style={[styles.mealBadge, { backgroundColor: isActive ? '#0D7A6B' : 'rgba(255,255,255,0.4)' }]}>
                            <Text style={{ fontSize: 10, fontWeight: '800', color: '#FFF' }}>{count}</Text>
                          </View>
                        )}
                      </TouchableOpacity>
                    );
                  })}
                </View>
              </ScrollView>
            </LinearGradient>

            {/* ── KATEGORİ SEÇİCİ ── */}
            <View style={styles.categoryWrap}>
              {CATEGORIES.map(cat => {
                const isActive = activeCategory === cat.type;
                return (
                  <TouchableOpacity
                    key={cat.type}
                    onPress={() => setActiveCategory(cat.type)}
                    style={[styles.categoryBtn, isActive && styles.categoryBtnActive]}
                  >
                    <Text style={{ fontSize: 14 }}>{cat.icon}</Text>
                    <Text style={[styles.categoryLabel, isActive && { color: '#0D7A6B', fontWeight: '800' }]}>
                      {cat.label}
                    </Text>
                  </TouchableOpacity>
                );
              })}
            </View>

            {/* ── ARAMA KUTUSU ── */}
            <View style={styles.searchWrap}>
              <View style={styles.searchBox}>
                <Ionicons name="search" size={20} color={searchQuery ? '#0D7A6B' : '#94A3B8'} style={{ marginRight: 10 }} />
                <TextInput
                  style={styles.searchInput}
                  placeholder={`${CATEGORIES.find(c => c.type === activeCategory)?.label} ekle...`}
                  placeholderTextColor="#94A3B8"
                  value={searchQuery}
                  onChangeText={setSearchQuery}
                  autoCapitalize="none"
                  autoCorrect={false}
                />
                {isSearching
                  ? <ActivityIndicator size="small" color="#0D7A6B" />
                  : searchQuery.length > 0
                    ? <TouchableOpacity onPress={() => { setSearchQuery(''); setSearchResults([]); }}>
                        <Ionicons name="close-circle" size={20} color="#94A3B8" />
                      </TouchableOpacity>
                    : null
                }
              </View>

              {/* Barkod Butonu */}
              <TouchableOpacity
                style={styles.barcodeBtn}
                onPress={() => navigation.navigate('BarcodeScanner')}
              >
                <Ionicons name="barcode-outline" size={24} color="#0D7A6B" />
              </TouchableOpacity>

              {/* Kamera / AI Analiz Butonu */}
              <TouchableOpacity
                style={[styles.barcodeBtn, { backgroundColor: '#0D7A6B' }]}
                onPress={() => navigation.navigate('FoodCamera')}
              >
                <Ionicons name="camera" size={22} color="#FFF" />
              </TouchableOpacity>
            </View>

            {/* Arama sonuçları */}
            {searchResults.length > 0 && (
              <View style={styles.resultCard}>
                {searchResults.map((r, idx) => {
                  const c = r.gi_value >= 70 ? '#EF4444' : r.gi_value >= 56 ? '#F59E0B' : '#10B981';
                  return (
                    <TouchableOpacity
                      key={r.id}
                      onPress={() => openModal(r)}
                      style={[styles.resultRow, idx < searchResults.length - 1 && { borderBottomWidth: 1, borderBottomColor: '#F1F5F9' }]}
                    >
                      <View style={{ flex: 1 }}>
                        <Text style={styles.resultName} numberOfLines={1}>{r.name}</Text>
                        <Text style={styles.resultMeta}>{r.category}</Text>
                      </View>
                      <View style={[styles.giBadge, { backgroundColor: c + '18' }]}>
                        <Text style={[styles.giText, { color: c }]}>Gİ {r.gi_value}</Text>
                      </View>
                      <Ionicons name="add-circle" size={28} color="#0D7A6B" style={{ marginLeft: 10 }} />
                    </TouchableOpacity>
                  );
                })}
              </View>
            )}

            {/* Boş durum */}
            {currentItems.length === 0 && (
              <View style={styles.emptyWrap}>
                <View style={styles.emptyIcon}>
                  <Text style={{ fontSize: 32 }}>{currentMeal.icon}</Text>
                </View>
                <Text style={styles.emptyTitle}>{currentMeal.label} boş</Text>
                <Text style={styles.emptyDesc}>
                  Yukarıdan besin arayın veya barkod tarayın{'\n'}
                  {CATEGORIES.find(c => c.type === activeCategory)?.icon} {CATEGORIES.find(c => c.type === activeCategory)?.label} kategorisi seçili
                </Text>
              </View>
            )}

            {currentItems.length > 0 && (
              <View style={styles.mealSummaryHeader}>
                <Text style={styles.sectionLabel}>
                  {currentMeal.icon} {currentMeal.label} ({currentItems.length} besin)
                </Text>
                <View style={[styles.mealGlChip, { backgroundColor: glColor(totalGL) + '18' }]}>
                  <Text style={[styles.mealGlChipText, { color: glColor(totalGL) }]}>GL {totalGL}</Text>
                </View>
              </View>
            )}
          </View>
        }

        renderItem={({ item }) => {
          const carbs  = (item.carbs100 / 100) * item.portion;
          const itemGL = Math.round((item.food.gi_value * carbs) / 100 * 10) / 10;
          const c      = glColor(itemGL);
          const catInfo = CATEGORIES.find(cat => cat.type === item.mealCategory);

          return (
            <View style={styles.mealCard}>
              <View style={[styles.cardAccent, { backgroundColor: c }]} />
              <View style={{ flex: 1, paddingLeft: 14 }}>
                <Text style={styles.mealName} numberOfLines={1}>{item.food.name}</Text>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 4 }}>
                  <View style={styles.catChip}>
                    <Text style={{ fontSize: 10 }}>{catInfo?.icon}</Text>
                    <Text style={styles.catChipText}>{catInfo?.label}</Text>
                  </View>
                  <Text style={styles.mealMeta}>{item.portionText} · Gİ {item.food.gi_value}</Text>
                </View>
              </View>
              <View style={{ alignItems: 'flex-end', gap: 6 }}>
                <Text style={[styles.mealGL, { color: c }]}>GL {itemGL}</Text>
                <TouchableOpacity onPress={() => removeItem(item.mealType, item.id)} style={styles.removeBtn}>
                  <Ionicons name="trash-outline" size={16} color="#EF4444" />
                </TouchableOpacity>
              </View>
            </View>
          );
        }}
      />

      {/* Sabit alt kaydet barı */}
      {currentItems.length > 0 && (
        <View style={[styles.summaryBar, { paddingBottom: insets.bottom + 16 }]}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
            <View>
              <Text style={{ fontSize: 13, fontWeight: '700', color: '#94A3B8' }}>{currentMeal.label} Toplamı</Text>
              <Text style={{ fontSize: 14, fontWeight: '600', color: '#475569', marginTop: 2 }}>{currentItems.length} besin</Text>
            </View>
            <Text style={[{ fontSize: 44, fontWeight: '900' }, { color: glColor(totalGL) }]}>
              {totalGL} <Text style={{ fontSize: 18, color: '#94A3B8' }}>GL</Text>
            </Text>
          </View>
          <TouchableOpacity onPress={handleSaveMeal} style={{ borderRadius: 18, overflow: 'hidden' }}>
            <LinearGradient
              colors={['#0A5748', '#0D7A6B']}
              start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
              style={styles.saveBtn}
            >
              <Ionicons name="checkmark-circle" size={22} color="#FFF" style={{ marginRight: 8 }} />
              <Text style={styles.saveBtnText}>{currentMeal.label}'ı Günlüğe Kaydet</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      )}

      {/* Porsiyon Modalı */}
      <Modal visible={!!selectedFood} transparent animationType="slide">
        <View style={styles.overlay}>
          <View style={styles.modal}>
            <Text style={styles.modalTitle} numberOfLines={2}>{selectedFood?.name}</Text>

            {/* Kategori bilgisi */}
            <View style={styles.modalCatRow}>
              <Text style={{ fontSize: 14 }}>{CATEGORIES.find(c => c.type === activeCategory)?.icon}</Text>
              <Text style={styles.modalCatText}>
                {currentMeal.label} · {CATEGORIES.find(c => c.type === activeCategory)?.label}
              </Text>
            </View>

            {fetchingCarbs ? (
              <View style={{ paddingVertical: 32 }}>
                <ActivityIndicator size="large" color="#0D7A6B" />
                <Text style={{ textAlign: 'center', color: '#94A3B8', marginTop: 10 }}>Besin değerleri yükleniyor...</Text>
              </View>
            ) : (
              <>
                {/* GL göstergesi */}
                {tempCarbs100 !== null && (
                  <View style={[styles.modalGlBox, { borderColor: glColor(modalGL) + '40', backgroundColor: glColor(modalGL) + '10' }]}>
                    <Text style={[styles.modalGlVal, { color: glColor(modalGL) }]}>{modalGL}</Text>
                    <Text style={[styles.modalGlLbl, { color: glColor(modalGL) }]}>GL</Text>
                  </View>
                )}

                {/* Ölçü modu seçici */}
                <View style={styles.modalModeRow}>
                  {(['pratik', 'gram'] as const).map(m => (
                    <TouchableOpacity
                      key={m}
                      onPress={() => setMeasureMode(m)}
                      style={[styles.modalModeBtn, measureMode === m && styles.modalModeBtnActive]}
                    >
                      <Text style={[styles.modalModeBtnText, measureMode === m && { color: '#FFF' }]}>
                        {m === 'pratik' ? `${smartMeasure.unit} ile` : 'Gram ile'}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>

                {/* Değer göster */}
                <Text style={styles.modalPortionVal}>
                  {measureMode === 'gram'
                    ? `${gramValue} gram`
                    : `${portion} ${smartMeasure.unit} ≈ ${Math.round(actualGrams)}g`}
                </Text>

                <Slider
                  style={{ width: '100%', height: 44, marginVertical: 8 }}
                  minimumValue={measureMode === 'gram' ? 10 : 0.5}
                  maximumValue={measureMode === 'gram' ? 500 : 10}
                  step={measureMode === 'gram' ? 10 : 0.5}
                  value={measureMode === 'gram' ? gramValue : portion}
                  onValueChange={val => measureMode === 'gram' ? setGramValue(Math.round(val)) : setPortion(Math.round(val * 2) / 2)}
                  minimumTrackTintColor="#0D7A6B"
                  maximumTrackTintColor="#E2E8F0"
                  thumbTintColor="#0D7A6B"
                />

                <View style={{ flexDirection: 'row', gap: 10, marginTop: 8 }}>
                  <TouchableOpacity onPress={() => setSelectedFood(null)} style={styles.modalBtnCancel}>
                    <Text style={styles.modalBtnCancelText}>İptal</Text>
                  </TouchableOpacity>
                  <TouchableOpacity onPress={confirmAdd} style={{ flex: 2, borderRadius: 16, overflow: 'hidden' }}>
                    <LinearGradient colors={['#0A5748', '#0D7A6B']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={styles.modalBtnAdd}>
                      <Ionicons name="add-circle" size={20} color="#FFF" style={{ marginRight: 6 }} />
                      <Text style={styles.modalBtnAddText}>Öğüne Ekle</Text>
                    </LinearGradient>
                  </TouchableOpacity>
                </View>
              </>
            )}
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    paddingBottom: 18, paddingHorizontal: 20,
    borderBottomLeftRadius: 32, borderBottomRightRadius: 32,
    shadowColor: '#052E28', shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.22, shadowRadius: 18, elevation: 12,
    marginBottom: 0,
  },
  deco: {
    position: 'absolute', right: -20, top: -20,
    width: 150, height: 150, borderRadius: 75,
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
  deco2: {
    position: 'absolute', left: -30, bottom: -30,
    width: 100, height: 100, borderRadius: 50,
    backgroundColor: 'rgba(255,255,255,0.04)',
  },
  eyebrow: { fontSize: 12, color: '#6EE7B7', fontWeight: '700', marginBottom: 2 },
  title:   { fontSize: 26, fontWeight: '900', color: '#FFFFFF' },

  grandGlBadge: {
    backgroundColor: 'rgba(255,255,255,0.15)', borderRadius: 14,
    paddingHorizontal: 14, paddingVertical: 10, alignItems: 'center',
  },
  grandGlLabel: { fontSize: 10, fontWeight: '700', color: 'rgba(255,255,255,0.7)', marginBottom: 2 },
  grandGlVal:   { fontSize: 24, fontWeight: '900' },

  mealTab: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    paddingHorizontal: 14, paddingVertical: 9,
    borderRadius: 14, position: 'relative',
  },
  mealTabLabel: { fontSize: 13, fontWeight: '700', color: 'rgba(255,255,255,0.9)' },
  mealBadge: {
    position: 'absolute', top: -2, right: -2,
    width: 18, height: 18, borderRadius: 9,
    alignItems: 'center', justifyContent: 'center',
  },

  categoryWrap: {
    flexDirection: 'row', paddingHorizontal: 16, paddingVertical: 12, gap: 8,
  },
  categoryBtn: {
    flex: 1, flexDirection: 'column', alignItems: 'center', paddingVertical: 10,
    backgroundColor: '#FFFFFF', borderRadius: 14,
    shadowColor: '#0F172A', shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05, shadowRadius: 6, elevation: 2, gap: 4,
    borderWidth: 1.5, borderColor: 'transparent',
  },
  categoryBtnActive: {
    borderColor: '#0D7A6B', backgroundColor: '#E8F5F3',
  },
  categoryLabel: { fontSize: 11, fontWeight: '600', color: '#64748B' },

  searchWrap: {
    paddingHorizontal: 16, marginBottom: 4,
    flexDirection: 'row', gap: 10, zIndex: 10,
  },
  searchBox: {
    flex: 1, flexDirection: 'row', alignItems: 'center',
    backgroundColor: '#FFFFFF', borderRadius: 18,
    paddingHorizontal: 16, height: 54,
    shadowColor: '#0F172A', shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08, shadowRadius: 10, elevation: 4,
  },
  searchInput: { flex: 1, fontSize: 15, color: '#0F172A', fontWeight: '500' },
  barcodeBtn: {
    width: 54, height: 54, borderRadius: 18,
    backgroundColor: '#E8F5F3', alignItems: 'center', justifyContent: 'center',
    shadowColor: '#0F172A', shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08, shadowRadius: 10, elevation: 4,
  },

  resultCard: {
    backgroundColor: '#FFFFFF', borderRadius: 18,
    marginHorizontal: 16, marginTop: 8,
    shadowColor: '#0F172A', shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08, shadowRadius: 10, elevation: 4,
    overflow: 'hidden',
  },
  resultRow: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 14 },
  resultName: { fontSize: 15, fontWeight: '700', color: '#0F172A' },
  resultMeta: { fontSize: 12, color: '#94A3B8', marginTop: 2 },
  giBadge:    { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8 },
  giText:     { fontSize: 12, fontWeight: '800' },

  emptyWrap: { alignItems: 'center', paddingTop: 48, paddingHorizontal: 40 },
  emptyIcon: {
    width: 80, height: 80, borderRadius: 40,
    backgroundColor: '#E8F5F3', alignItems: 'center', justifyContent: 'center', marginBottom: 16,
  },
  emptyTitle: { fontSize: 20, fontWeight: '800', color: '#0F172A', marginBottom: 8 },
  emptyDesc:  { fontSize: 13, color: '#64748B', textAlign: 'center', lineHeight: 20 },

  mealSummaryHeader: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 20, marginTop: 16, marginBottom: 10,
  },
  sectionLabel: { fontSize: 13, fontWeight: '700', color: '#0F172A' },
  mealGlChip: { paddingHorizontal: 12, paddingVertical: 5, borderRadius: 10 },
  mealGlChipText: { fontSize: 13, fontWeight: '800' },

  mealCard: {
    marginHorizontal: 16, marginBottom: 10,
    backgroundColor: '#FFFFFF', borderRadius: 18,
    flexDirection: 'row', alignItems: 'stretch',
    paddingVertical: 14, paddingRight: 16,
    shadowColor: '#0F172A', shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05, shadowRadius: 8, elevation: 2, overflow: 'hidden',
  },
  cardAccent: { width: 5, borderRadius: 3 },
  mealName:   { fontSize: 15, fontWeight: '800', color: '#0F172A' },
  mealMeta:   { fontSize: 12, color: '#64748B', fontWeight: '500' },
  mealGL:     { fontSize: 17, fontWeight: '900' },
  removeBtn:  { padding: 6, backgroundColor: '#FEF2F2', borderRadius: 10 },
  catChip: {
    flexDirection: 'row', alignItems: 'center', gap: 3,
    backgroundColor: '#F1F5F9', paddingHorizontal: 7, paddingVertical: 3, borderRadius: 7,
  },
  catChipText: { fontSize: 10, fontWeight: '700', color: '#64748B' },

  summaryBar: {
    position: 'absolute', bottom: 0, left: 0, right: 0,
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 20, paddingTop: 18,
    borderTopLeftRadius: 28, borderTopRightRadius: 28,
    shadowColor: '#0F172A', shadowOffset: { width: 0, height: -8 },
    shadowOpacity: 0.1, shadowRadius: 18, elevation: 20,
  },
  saveBtn:     { paddingVertical: 17, borderRadius: 18, flexDirection: 'row', justifyContent: 'center', alignItems: 'center' },
  saveBtnText: { fontSize: 16, fontWeight: '900', color: '#FFFFFF', letterSpacing: 0.3 },

  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.55)', justifyContent: 'flex-end' },
  modal: {
    backgroundColor: '#FFFFFF', borderTopLeftRadius: 32, borderTopRightRadius: 32,
    padding: 26, paddingBottom: 36,
  },
  modalTitle:   { fontSize: 19, fontWeight: '900', color: '#0F172A', textAlign: 'center', marginBottom: 8 },
  modalCatRow:  { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, marginBottom: 16 },
  modalCatText: { fontSize: 13, fontWeight: '600', color: '#64748B' },
  modalGlBox: {
    flexDirection: 'row', alignItems: 'baseline', gap: 6, alignSelf: 'center',
    paddingHorizontal: 28, paddingVertical: 12, borderRadius: 18,
    borderWidth: 2, marginBottom: 14,
  },
  modalGlVal:  { fontSize: 44, fontWeight: '900' },
  modalGlLbl:  { fontSize: 18, fontWeight: '700' },
  modalModeRow: {
    flexDirection: 'row', gap: 8, marginBottom: 12,
    backgroundColor: '#F2F1F6', borderRadius: 12, padding: 4,
  },
  modalModeBtn: { flex: 1, paddingVertical: 8, borderRadius: 9, alignItems: 'center' },
  modalModeBtnActive: { backgroundColor: '#0D7A6B' },
  modalModeBtnText: { fontSize: 13, fontWeight: '700', color: '#64748B' },
  modalPortionVal: { fontSize: 24, fontWeight: '800', color: '#0F172A', textAlign: 'center', marginBottom: 4 },
  modalBtnCancel: {
    flex: 1, paddingVertical: 16, backgroundColor: '#F1F5F9',
    borderRadius: 16, alignItems: 'center',
  },
  modalBtnCancelText: { fontSize: 16, fontWeight: '700', color: '#64748B' },
  modalBtnAdd: { paddingVertical: 16, flexDirection: 'row', justifyContent: 'center', alignItems: 'center' },
  modalBtnAddText: { fontSize: 16, fontWeight: '800', color: '#FFFFFF' },
});
