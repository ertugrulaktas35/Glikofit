import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, FlatList, TouchableOpacity, ActivityIndicator, ScrollView, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { supabase } from '../lib/supabase';
import type { Food, ColorCode } from '../types/database';

type FilterKey = 'ALL' | ColorCode;

const FILTERS: { key: FilterKey; label: string; color: string }[] = [
  { key: 'ALL',    label: 'Tümü',    color: '#0D7A6B' },
  { key: 'GREEN',  label: 'Güvenli', color: '#10B981' },
  { key: 'YELLOW', label: 'Dikkat',  color: '#F59E0B' },
  { key: 'RED',    label: 'Riskli',  color: '#EF4444' },
];

const TRAFFIC: Record<ColorCode, { dot: string; label: string; bg: string; text: string }> = {
  GREEN:  { dot: '#10B981', label: 'Güvenli', bg: '#ECFDF5', text: '#065F46' },
  YELLOW: { dot: '#F59E0B', label: 'Dikkat',  bg: '#FFFBEB', text: '#78350F' },
  RED:    { dot: '#EF4444', label: 'Riskli',  bg: '#FEF2F2', text: '#7F1D1D' },
};

export default function SearchScreen() {
  const insets    = useSafeAreaInsets();
  const navigation = useNavigation<any>();
  const [selectedFilter,   setSelectedFilter]   = useState<FilterKey>('ALL');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [categories, setCategories]             = useState<string[]>([]);
  const [foods,      setFoods]                  = useState<Food[]>([]);
  const [isLoading,  setIsLoading]              = useState(true);

  useEffect(() => {
    supabase.from('foods').select('category').then(({ data }) => {
      if (data) {
        const unique = [...new Set((data as { category: string }[]).map(d => d.category))].sort();
        setCategories(unique);
      }
    });
  }, []);

  const fetchFiltered = useCallback(async () => {
    setIsLoading(true);
    let q = supabase.from('foods').select('*');
    if (selectedFilter !== 'ALL') q = q.eq('color_code', selectedFilter);
    if (selectedCategory) q = q.eq('category', selectedCategory);
    q = q.order('name', { ascending: true });
    const { data, error } = await q;
    setFoods(!error && data ? (data as Food[]) : []);
    setIsLoading(false);
  }, [selectedFilter, selectedCategory]);

  useEffect(() => { fetchFiltered(); }, [fetchFiltered]);

  return (
    <View style={{ flex: 1, backgroundColor: '#F5F7FA' }}>
      <FlatList
        data={isLoading ? [] : foods}
        keyExtractor={item => item.id.toString()}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 120 }}

        ListEmptyComponent={
          isLoading ? (
            <View style={{ alignItems: 'center', paddingTop: 80 }}>
              <ActivityIndicator size="large" color="#0D7A6B" />
              <Text style={{ fontSize: 15, color: '#94A3B8', marginTop: 12 }}>Yükleniyor...</Text>
            </View>
          ) : (
            <View style={{ alignItems: 'center', paddingTop: 60, paddingHorizontal: 40 }}>
              <View style={styles.emptyIcon}>
                <Ionicons name="search-outline" size={32} color="#0D7A6B" />
              </View>
              <Text style={styles.emptyTitle}>Sonuç bulunamadı</Text>
              <Text style={styles.emptyDesc}>Filtrelerinizi değiştirmeyi deneyin</Text>
            </View>
          )
        }

        renderItem={({ item }) => {
          const t  = TRAFFIC[item.color_code];
          const gc = item.gi_value >= 70 ? '#EF4444' : item.gi_value >= 56 ? '#F59E0B' : '#10B981';
          return (
            <TouchableOpacity
              activeOpacity={0.75}
              onPress={() => navigation.navigate('FoodDetail', { food: item })}
              style={styles.card}
            >
              {/* Sol renk şeridi */}
              <View style={[styles.cardStripe, { backgroundColor: t.dot }]} />
              <View style={{ flex: 1, paddingLeft: 14 }}>
                <Text style={styles.cardName} numberOfLines={1}>{item.name}</Text>
                <Text style={styles.cardCategory}>{item.category}</Text>
                <View style={{ flexDirection: 'row', gap: 6, marginTop: 8 }}>
                  <View style={[styles.chip, { backgroundColor: gc + '18' }]}>
                    <Text style={[styles.chipText, { color: gc }]}>Gİ {item.gi_value}</Text>
                  </View>
                  {item.carbs_per_100g > 0 && (
                    <View style={[styles.chip, { backgroundColor: '#F1F5F9' }]}>
                      <Text style={[styles.chipText, { color: '#475569' }]}>{Math.round(item.carbs_per_100g)}g karb</Text>
                    </View>
                  )}
                </View>
              </View>
              <View style={{ alignItems: 'flex-end', gap: 6 }}>
                <View style={[styles.trafficBadge, { backgroundColor: t.bg }]}>
                  <View style={[styles.trafficDot, { backgroundColor: t.dot }]} />
                  <Text style={[styles.trafficLabel, { color: t.text }]}>{t.label}</Text>
                </View>
                <Ionicons name="chevron-forward" size={14} color="#CBD5E1" />
              </View>
            </TouchableOpacity>
          );
        }}

        ListHeaderComponent={
          <View>
            {/* Header */}
            <LinearGradient
              colors={['#063830', '#0A5748', '#0D7A6B']}
              start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
              style={[styles.header, { paddingTop: insets.top + 16 }]}
            >
              <View style={styles.deco} pointerEvents="none" />
              <Text style={styles.eyebrow}>Besin Veritabanı</Text>
              <Text style={styles.headerTitle}>Keşfet 🔍</Text>
              <Text style={styles.headerSub}>Renk ve kategoriye göre filtrele</Text>
            </LinearGradient>

            {/* Filtreler */}
            <ScrollView
              horizontal showsHorizontalScrollIndicator={false}
              contentContainerStyle={{ paddingHorizontal: 16, paddingVertical: 14, gap: 8 }}
            >
              {FILTERS.map(f => {
                const active = selectedFilter === f.key;
                return (
                  <TouchableOpacity
                    key={f.key}
                    onPress={() => setSelectedFilter(f.key)}
                    style={[styles.filterChip, {
                      backgroundColor: active ? f.color : '#FFFFFF',
                      borderColor: active ? f.color : '#E2E8F0',
                      shadowColor: active ? f.color : '#000',
                      shadowOpacity: active ? 0.22 : 0.04,
                    }]}
                  >
                    <Text style={[styles.filterText, { color: active ? '#FFF' : '#475569' }]}>{f.label}</Text>
                  </TouchableOpacity>
                );
              })}
            </ScrollView>

            {/* Kategoriler */}
            <ScrollView
              horizontal showsHorizontalScrollIndicator={false}
              contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: 14, gap: 8 }}
            >
              <TouchableOpacity
                onPress={() => setSelectedCategory(null)}
                style={[styles.catChip, { backgroundColor: !selectedCategory ? '#0D7A6B' : 'transparent', borderColor: !selectedCategory ? '#0D7A6B' : '#E2E8F0' }]}
              >
                <Text style={[styles.catText, { color: !selectedCategory ? '#FFF' : '#64748B' }]}>Tümü</Text>
              </TouchableOpacity>
              {categories.map(cat => {
                const active = selectedCategory === cat;
                return (
                  <TouchableOpacity
                    key={cat}
                    onPress={() => setSelectedCategory(active ? null : cat)}
                    style={[styles.catChip, { backgroundColor: active ? '#0D7A6B' : 'transparent', borderColor: active ? '#0D7A6B' : '#E2E8F0' }]}
                  >
                    <Text style={[styles.catText, { color: active ? '#FFF' : '#64748B' }]}>{cat}</Text>
                  </TouchableOpacity>
                );
              })}
            </ScrollView>

            {/* Sonuç sayısı */}
            {!isLoading && (
              <Text style={styles.resultCount}>
                {foods.length} besin listeleniyor
              </Text>
            )}
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    paddingBottom: 28, paddingHorizontal: 22,
    borderBottomLeftRadius: 36, borderBottomRightRadius: 36,
    marginBottom: 0,
    shadowColor: '#052E28', shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.22, shadowRadius: 18, elevation: 12,
  },
  deco: {
    position: 'absolute', right: -20, top: -20,
    width: 150, height: 150, borderRadius: 75,
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
  eyebrow: { fontSize: 13, color: '#6EE7B7', fontWeight: '700', marginBottom: 4 },
  headerTitle: { fontSize: 30, fontWeight: '900', color: '#FFFFFF', marginBottom: 4 },
  headerSub: { fontSize: 14, color: 'rgba(255,255,255,0.7)', fontWeight: '500' },

  filterChip: {
    paddingHorizontal: 18, paddingVertical: 10, borderRadius: 24,
    borderWidth: 1.5,
    shadowOffset: { width: 0, height: 2 }, shadowRadius: 6, elevation: 3,
  },
  filterText: { fontSize: 14, fontWeight: '800' },

  catChip: {
    paddingHorizontal: 14, paddingVertical: 8, borderRadius: 12,
    borderWidth: 1,
  },
  catText: { fontSize: 13, fontWeight: '700' },

  resultCount: {
    fontSize: 12, fontWeight: '600', color: '#94A3B8',
    paddingHorizontal: 20, marginBottom: 10,
  },

  card: {
    marginHorizontal: 16, marginBottom: 10,
    backgroundColor: '#FFFFFF', borderRadius: 18,
    flexDirection: 'row', alignItems: 'center',
    paddingVertical: 14, paddingRight: 14,
    shadowColor: '#0F172A', shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05, shadowRadius: 8, elevation: 2,
    overflow: 'hidden',
  },
  cardStripe: { width: 5, alignSelf: 'stretch', borderRadius: 3 },
  cardName: { fontSize: 16, fontWeight: '800', color: '#0F172A' },
  cardCategory: { fontSize: 12, color: '#94A3B8', marginTop: 2, fontWeight: '500' },
  chip: { paddingHorizontal: 9, paddingVertical: 3, borderRadius: 8 },
  chipText: { fontSize: 11, fontWeight: '800' },
  trafficBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 5,
    paddingHorizontal: 10, paddingVertical: 5, borderRadius: 10,
  },
  trafficDot: { width: 7, height: 7, borderRadius: 4 },
  trafficLabel: { fontSize: 12, fontWeight: '800' },

  emptyIcon: { width: 80, height: 80, borderRadius: 40, backgroundColor: '#E8F5F3', alignItems: 'center', justifyContent: 'center', marginBottom: 16 },
  emptyTitle: { fontSize: 20, fontWeight: '800', color: '#0F172A', marginBottom: 6 },
  emptyDesc: { fontSize: 14, color: '#64748B', textAlign: 'center' },
});
