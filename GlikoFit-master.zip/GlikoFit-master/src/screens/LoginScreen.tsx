// ============================================================
// 🔐 Giriş Ekranı — E-Posta & Şifre
// ============================================================
import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { supabase } from '../lib/supabase';

const SAVED_EMAIL_KEY = 'glikofit_last_email';

export default function LoginScreen() {
  const insets = useSafeAreaInsets();

  const [isLogin, setIsLogin] = useState(true); // true = Giriş, false = Kayıt
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(true);

  // Uygulama açılınca kayıtlı e-postayı kontrol et
  useEffect(() => {
    AsyncStorage.getItem(SAVED_EMAIL_KEY).then((stored) => {
      if (stored) {
        setEmail(stored);
      }
      setLoading(false);
    });
  }, []);

  const handleAuth = async () => {
    const trimmedEmail = email.trim().toLowerCase();
    
    if (!trimmedEmail || !trimmedEmail.includes('@')) {
      Alert.alert('Hata', 'Lütfen geçerli bir e-posta adresi girin.');
      return;
    }
    
    if (password.length < 6) {
      Alert.alert('Hata', 'Şifreniz en az 6 karakter olmalıdır.');
      return;
    }

    setLoading(true);
    try {
      if (isLogin) {
        // GİRİŞ YAP
        const { error } = await supabase.auth.signInWithPassword({
          email: trimmedEmail,
          password: password,
        });
        if (error) throw error;
      } else {
        // KAYIT OL
        const { error } = await supabase.auth.signUp({
          email: trimmedEmail,
          password: password,
        });
        if (error) throw error;
        Alert.alert('Başarılı', 'Kayıt başarılı! Şimdi giriş yapabilirsiniz.');
        setIsLogin(true); // Başarılı kayıttan sonra giriş ekranına dön
        setPassword('');
      }

      // E-postayı cihazda hatırla
      await AsyncStorage.setItem(SAVED_EMAIL_KEY, trimmedEmail);
      
    } catch (err: any) {
      const msg = err?.message || 'Bir hata oluştu.';
      const tr: Record<string, string> = {
        'Invalid login credentials': 'E-posta veya şifre hatalı.',
        'User already registered': 'Bu e-posta ile zaten bir hesap var.',
      };
      Alert.alert('Hata', tr[msg] || msg);
    } finally {
      setLoading(false);
    }
  };

  if (loading && email === '') {
    return (
      <View style={{ flex: 1, backgroundColor: '#F4F4F4', justifyContent: 'center', alignItems: 'center' }}>
        <ActivityIndicator size="large" color="#0D7A6B" />
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: '#F5F7FA' }}>
      {/* ── Üst Gradient Bölüm ──────────────────────────── */}
      <LinearGradient
        colors={['#063830', '#0A5748', '#0D7A6B']}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={{
          paddingTop: insets.top + 48,
          paddingBottom: 80,
          paddingHorizontal: 32,
          borderBottomLeftRadius: 48,
          borderBottomRightRadius: 48,
        }}
      >
        {/* Dekoratif halkalar */}
        <View style={{ position: 'absolute', right: -30, top: -30, width: 180, height: 180, borderRadius: 90, backgroundColor: 'rgba(255,255,255,0.04)' }} pointerEvents="none" />
        <View style={{ position: 'absolute', left: -40, bottom: 20, width: 120, height: 120, borderRadius: 60, backgroundColor: 'rgba(255,255,255,0.04)' }} pointerEvents="none" />

        <View style={{ alignItems: 'center' }}>
          <View style={{
            width: 88, height: 88, borderRadius: 32,
            backgroundColor: 'rgba(255,255,255,0.15)',
            borderWidth: 1.5, borderColor: 'rgba(255,255,255,0.2)',
            alignItems: 'center', justifyContent: 'center',
            marginBottom: 20,
          }}>
            <Ionicons name="leaf" size={44} color="#FFFFFF" />
          </View>
          <Text style={{ fontSize: 38, fontWeight: '900', color: '#FFFFFF', letterSpacing: -1 }}>
            GlikoFit
          </Text>
          <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 8, gap: 8 }}>
            <View style={{ width: 6, height: 6, borderRadius: 3, backgroundColor: '#6EE7B7' }} />
            <Text style={{ fontSize: 15, color: '#A7F3D0', fontWeight: '600' }}>
              Akıllı Kan Şekeri Asistanı
            </Text>
            <View style={{ width: 6, height: 6, borderRadius: 3, backgroundColor: '#6EE7B7' }} />
          </View>
        </View>
      </LinearGradient>

      {/* ── Form Alanı ──────────────────────────────────── */}
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <ScrollView
          style={{ flex: 1, marginTop: -40 }}
          contentContainerStyle={{ paddingHorizontal: 24, paddingBottom: 40 }}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          <View style={{
            backgroundColor: '#FFFFFF',
            borderRadius: 28,
            padding: 28,
            shadowColor: '#000',
            shadowOffset: { width: 0, height: 10 },
            shadowOpacity: 0.08,
            shadowRadius: 20,
            elevation: 8,
          }}>
            <View style={{ alignItems: 'center', marginBottom: 28 }}>
              <View style={{
                width: 56, height: 56, borderRadius: 20,
                backgroundColor: '#F0FDF4',
                alignItems: 'center', justifyContent: 'center',
                marginBottom: 16,
              }}>
                <Ionicons name={isLogin ? 'log-in' : 'person-add'} size={28} color="#0D7A6B" />
              </View>
              <Text style={{ fontSize: 22, fontWeight: '900', color: '#1A1A1A', textAlign: 'center' }}>
                {isLogin ? 'Tekrar Hoş Geldiniz!' : 'Hesap Oluşturun'}
              </Text>
              <Text style={{ fontSize: 15, color: '#888', fontWeight: '500', textAlign: 'center', marginTop: 6, lineHeight: 22 }}>
                {isLogin ? 'Hesabınıza giriş yapın.' : 'Aramıza katılmak için e-posta ve şifre belirleyin.'}
              </Text>
            </View>

            <Text style={labelStyle}>E-posta Adresiniz</Text>
            <View style={inputContainerStyle}>
              <Ionicons name="mail-outline" size={20} color="#A0A0A0" style={{ marginRight: 10 }} />
              <TextInput
                style={inputStyle}
                placeholder="ornek@email.com"
                placeholderTextColor="#C0C0C0"
                value={email}
                onChangeText={setEmail}
                keyboardType="email-address"
                autoCapitalize="none"
                autoCorrect={false}
              />
            </View>

            <Text style={labelStyle}>Şifreniz</Text>
            <View style={inputContainerStyle}>
              <Ionicons name="lock-closed-outline" size={20} color="#A0A0A0" style={{ marginRight: 10 }} />
              <TextInput
                style={inputStyle}
                placeholder="••••••"
                placeholderTextColor="#C0C0C0"
                value={password}
                onChangeText={setPassword}
                secureTextEntry
                autoCapitalize="none"
              />
            </View>

            {/* Giriş / Kayıt Butonu */}
            <TouchableOpacity
              activeOpacity={0.85}
              onPress={handleAuth}
              disabled={loading}
              style={{ height: 58, borderRadius: 20, overflow: 'hidden', marginTop: 8 }}
            >
              <LinearGradient
                colors={loading ? ['#80C4BC', '#80C4BC'] : ['#0D7A6B', '#10B981']}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
                style={{ flex: 1, justifyContent: 'center', alignItems: 'center', flexDirection: 'row' }}
              >
                {loading ? (
                  <ActivityIndicator color="#FFF" size="small" />
                ) : (
                  <>
                    <Ionicons name={isLogin ? "log-in" : "checkmark-circle"} size={22} color="#FFF" style={{ marginRight: 10 }} />
                    <Text style={{ fontSize: 18, fontWeight: '800', color: '#FFF', letterSpacing: 0.3 }}>
                      {isLogin ? 'Giriş Yap' : 'Kayıt Ol'}
                    </Text>
                  </>
                )}
              </LinearGradient>
            </TouchableOpacity>

            {/* Mod Değiştirme Butonu */}
            <TouchableOpacity
              onPress={() => setIsLogin(!isLogin)}
              disabled={loading}
              style={{ alignItems: 'center', marginTop: 20 }}
            >
              <Text style={{ fontSize: 14, color: '#0D7A6B', fontWeight: '700' }}>
                {isLogin ? 'Hesabınız yok mu? Kayıt Olun' : 'Zaten hesabınız var mı? Giriş Yapın'}
              </Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

// ── Paylaşılan Stiller ──────────────────────────────────────
const labelStyle = {
  fontSize: 13 as const,
  fontWeight: '700' as const,
  color: '#888',
  textTransform: 'uppercase' as const,
  letterSpacing: 0.5,
  marginBottom: 8,
  marginLeft: 4,
};

const inputContainerStyle = {
  flexDirection: 'row' as const,
  alignItems: 'center' as const,
  backgroundColor: '#F8F9FA',
  borderRadius: 16,
  paddingHorizontal: 16,
  borderWidth: 1.5,
  borderColor: '#E8E8E8',
  marginBottom: 22,
};

const inputStyle = {
  flex: 1 as const,
  paddingVertical: Platform.OS === 'ios' ? 16 : 14,
  fontSize: 17 as const,
  color: '#1A1A1A',
  fontWeight: '600' as const,
};
