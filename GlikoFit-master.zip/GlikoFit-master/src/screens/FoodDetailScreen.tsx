import React, { useState, useEffect, useMemo } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, ActivityIndicator,
  SafeAreaView, ScrollView, Alert, Image, Dimensions, Animated,
} from 'react-native';
import Svg, { Circle, G } from 'react-native-svg';
import { LinearGradient } from 'expo-linear-gradient';
import Slider from '@react-native-community/slider';
import { Ionicons } from '@expo/vector-icons';
import { useRoute, useNavigation } from '@react-navigation/native';
import { useAppStore } from '../store/useAppStore';
import { getCarbsPer100g } from '../lib/fatsecret';
import { getFoodImage } from '../utils/images';
import { useGlycemicLoad } from '../hooks/useGlycemicLoad';
import { getCoachAdvice } from '../services/db';
import { getSmartCoachAdvice } from '../services/ai';
import { CoachAdviceCard } from '../components/ui/CoachAdviceCard';
import type { CoachPairing } from '../types/database';
import { scheduleHighGLNotification } from '../services/notificationService';
import { useUserStore } from '../store/useUserStore';
import { isFoodRecommended, DIABETES_TYPE_LABELS } from '../utils/healthCalculations';

const { width: SW, height: SH } = Dimensions.get('window');
const IMG_H = SH * 0.36;

// ── Akıllı Porsiyon (genişletilmiş + ml desteği) ─────────────
interface PortionInfo {
  unit: string;
  grams: number;
  ml?: number;         // içecekler için ml
  icon: string;
  presets: number[];   // hızlı seçim değerleri
}

function getSmartPortion(name: string, category: string): PortionInfo {
  const n = (name ?? '').toLocaleLowerCase('tr');
  const c = (category ?? '').toLocaleLowerCase('tr');

  // ── İÇECEKLER ───────────────────────────────────────────────
  if (n.includes('gazlı') || n.includes('kola') || n.includes('soda') || n.includes('sprite') || n.includes('fanta'))
    return { unit: 'Kutu', grams: 330, ml: 330, icon: '🥤', presets: [0.5, 1, 2] };
  if (n.includes('limonata') || n.includes('meyve suyu') || n.includes('portakal suyu') || n.includes('elma suyu'))
    return { unit: 'Bardak', grams: 200, ml: 200, icon: '🥛', presets: [0.5, 1, 2] };
  if (n.includes('çay') || n.includes('kahve') || n.includes('nescafe') || n.includes('espresso'))
    return { unit: 'Fincan', grams: 150, ml: 150, icon: '☕', presets: [1, 2, 3] };
  if (n.includes('süt') || n.includes('ayran') || n.includes('kefir'))
    return { unit: 'Bardak', grams: 200, ml: 200, icon: '🥛', presets: [0.5, 1, 1.5] };
  if (n.includes('smoothie') || n.includes('şerbet') || n.includes('komposto'))
    return { unit: 'Bardak', grams: 250, ml: 250, icon: '🥤', presets: [0.5, 1, 2] };
  if (c.includes('içecek') || c.includes('içecekler'))
    return { unit: 'Bardak', grams: 200, ml: 200, icon: '🥤', presets: [0.5, 1, 2] };

  // ── EKMEK & HAMUR ────────────────────────────────────────────
  if (n.includes('ekmek') || n.includes('somun'))
    return { unit: 'Dilim', grams: 40, icon: '🍞', presets: [1, 2, 3] };
  if (n.includes('pide') || n.includes('lavaş') || n.includes('bazlama'))
    return { unit: 'Adet', grams: 80, icon: '🫓', presets: [0.5, 1, 2] };
  if (n.includes('tost') || n.includes('sandviç'))
    return { unit: 'Adet', grams: 100, icon: '🥪', presets: [0.5, 1, 2] };
  if (n.includes('simit'))
    return { unit: 'Adet', grams: 80, icon: '🥐', presets: [0.5, 1, 2] };
  if (n.includes('börek') || n.includes('poğaça') || n.includes('gözleme'))
    return { unit: 'Adet', grams: 80, icon: '🥐', presets: [0.5, 1, 2] };

  // ── PIZZA & FASTFOOD ─────────────────────────────────────────
  if (n.includes('pizza'))
    return { unit: 'Dilim', grams: 90, icon: '🍕', presets: [1, 2, 3] };
  if (n.includes('lahmacun') || n.includes('pide') && n.includes('kıymalı'))
    return { unit: 'Adet', grams: 120, icon: '🫓', presets: [1, 2, 3] };

  // ── TATLILAR & PASTALAR ──────────────────────────────────────
  if (n.includes('pasta') || n.includes('kek') || n.includes('turta') || n.includes('cheesecake'))
    return { unit: 'Dilim', grams: 90, icon: '🎂', presets: [0.5, 1, 2] };
  if (n.includes('baklava') || n.includes('kadayıf') || n.includes('lokma'))
    return { unit: 'Porsiyon', grams: 80, icon: '🍮', presets: [0.5, 1, 2] };
  if (n.includes('bisküvi') || n.includes('kurabiye') || n.includes('kraker'))
    return { unit: 'Tane', grams: 12, icon: '🍪', presets: [2, 5, 10] };
  if (n.includes('çikolata') && (n.includes('bar') || n.includes('tablet')))
    return { unit: 'Kare', grams: 15, icon: '🍫', presets: [2, 5, 8] };
  if (n.includes('çikolata'))
    return { unit: 'Tane', grams: 15, icon: '🍫', presets: [1, 2, 4] };
  if (n.includes('waffle') || n.includes('muffin') || n.includes('donut'))
    return { unit: 'Adet', grams: 80, icon: '🧇', presets: [0.5, 1, 2] };
  if (n.includes('dondurma'))
    return { unit: 'Top', grams: 60, icon: '🍦', presets: [1, 2, 3] };

  // ── MEYVELER ─────────────────────────────────────────────────
  if (n.includes('karpuz') || n.includes('kavun'))
    return { unit: 'Dilim', grams: 200, icon: '🍉', presets: [0.5, 1, 2] };
  if (n.includes('elma') || n.includes('armut') || n.includes('portakal') || n.includes('şeftali'))
    return { unit: 'Adet', grams: 150, icon: '🍎', presets: [0.5, 1, 2] };
  if (n.includes('muz'))
    return { unit: 'Adet', grams: 120, icon: '🍌', presets: [0.5, 1, 2] };
  if (n.includes('üzüm') || n.includes('kiraz') || n.includes('çilek'))
    return { unit: 'Kase', grams: 100, icon: '🍇', presets: [0.5, 1, 2] };
  if (n.includes('kivi') || n.includes('mandalina') || n.includes('greyfurt'))
    return { unit: 'Adet', grams: 100, icon: '🍊', presets: [1, 2, 3] };
  if (n.includes('nar') || n.includes('mango') || n.includes('avokado') || n.includes('ananas'))
    return { unit: 'Adet', grams: 180, icon: '🥭', presets: [0.5, 1, 2] };
  if (c.includes('meyve'))
    return { unit: 'Adet', grams: 130, icon: '🍎', presets: [0.5, 1, 2] };

  // ── YUMURTA & SÜTTEN ─────────────────────────────────────────
  if (n.includes('yumurta'))
    return { unit: 'Adet', grams: 60, icon: '🥚', presets: [1, 2, 3] };
  if (n.includes('peynir') || n.includes('kaşar') || n.includes('beyaz peynir') || n.includes('çedar'))
    return { unit: 'Dilim', grams: 20, icon: '🧀', presets: [1, 2, 4] };
  if (n.includes('yoğurt'))
    return { unit: 'Kase', grams: 150, icon: '🥣', presets: [0.5, 1, 1.5] };

  // ── KURUYEMIŞLER ─────────────────────────────────────────────
  if (n.includes('ceviz') || n.includes('badem') || n.includes('kaju') || n.includes('fıstık') || n.includes('fındık'))
    return { unit: 'Avuç', grams: 30, icon: '🥜', presets: [0.5, 1, 2] };
  if (c.includes('kuruyemiş') || c.includes('çerez'))
    return { unit: 'Avuç', grams: 30, icon: '🥜', presets: [0.5, 1, 2] };

  // ── SEBZELER ─────────────────────────────────────────────────
  if (n.includes('salata') || n.includes('çoban') || n.includes('yeşil salata'))
    return { unit: 'Kase', grams: 150, icon: '🥗', presets: [0.5, 1, 1.5] };
  if (n.includes('patates') && n.includes('kızartma'))
    return { unit: 'Porsiyon', grams: 150, icon: '🍟', presets: [0.5, 1, 1.5] };
  if (n.includes('patates'))
    return { unit: 'Adet', grams: 120, icon: '🥔', presets: [0.5, 1, 2] };

  // ── ÇORBALAR ─────────────────────────────────────────────────
  if (n.includes('çorba') || c.includes('çorba'))
    return { unit: 'Kase', grams: 250, icon: '🍲', presets: [0.5, 1, 1.5] };

  // ── ET & TAVUK & BALIK ──────────────────────────────────────
  if (n.includes('kebap') || n.includes('köfte') || n.includes('şiş'))
    return { unit: 'Porsiyon', grams: 150, icon: '🍖', presets: [0.5, 1, 1.5] };
  if (n.includes('tavuk') || n.includes('chicken') || n.includes('piliç'))
    return { unit: 'Porsiyon', grams: 150, icon: '🍗', presets: [0.5, 1, 1.5] };
  if (n.includes('balık') || n.includes('somon') || n.includes('levrek') || n.includes('çupra'))
    return { unit: 'Porsiyon', grams: 150, icon: '🐟', presets: [0.5, 1, 1.5] };
  if (n.includes('sucuk') || n.includes('salam') || n.includes('pastırma'))
    return { unit: 'Dilim', grams: 20, icon: '🍖', presets: [2, 4, 6] };
  if (c.includes('et') || c.includes('tavuk') || c.includes('balık'))
    return { unit: 'Porsiyon', grams: 150, icon: '🍖', presets: [0.5, 1, 1.5] };

  // ── PİLAV, MAKARNA, BAKLAGILLER ─────────────────────────────
  if (n.includes('pilav') || n.includes('rice'))
    return { unit: 'Kase', grams: 180, icon: '🍚', presets: [0.5, 1, 1.5] };
  if (n.includes('makarna') || n.includes('spagetti') || n.includes('pasta'))
    return { unit: 'Kase', grams: 180, icon: '🍝', presets: [0.5, 1, 1.5] };
  if (n.includes('fasulye') || n.includes('nohut') || n.includes('mercimek') || n.includes('bezelye'))
    return { unit: 'Kase', grams: 180, icon: '🫘', presets: [0.5, 1, 1.5] };

  // ── YAĞLAR & SOSLAR ──────────────────────────────────────────
  if (n.includes('zeytinyağı') || n.includes('ayçiçek yağı') || n.includes('tereyağı') || n.includes('margarin'))
    return { unit: 'Yemek Kaşığı', grams: 14, icon: '🫙', presets: [0.5, 1, 2] };
  if (n.includes('bal') || n.includes('reçel') || n.includes('pekmez') || n.includes('tahin'))
    return { unit: 'Tatlı Kaşığı', grams: 10, icon: '🍯', presets: [1, 2, 3] };
  if (n.includes('şeker') || n.includes('toz şeker'))
    return { unit: 'Tatlı Kaşığı', grams: 8, icon: '🧂', presets: [1, 2, 3] };
  if (c.includes('yağ') || c.includes('tatlandırıcı'))
    return { unit: 'Kaşık', grams: 15, icon: '🫙', presets: [0.5, 1, 2] };

  // ── MÜSLİ & KAHVALTI ─────────────────────────────────────────
  if (n.includes('müsli') || n.includes('granola') || n.includes('yulaf'))
    return { unit: 'Kase', grams: 60, icon: '🥣', presets: [0.5, 1, 1.5] };

  // Varsayılan
  return { unit: 'Porsiyon', grams: 150, icon: '🍽️', presets: [0.5, 1, 1.5] };
}

// ── Yardımcılar ──────────────────────────────────────────────
function scaleMacro(per100: number | undefined, grams: number): number {
  return Math.round(((per100 ?? 0) / 100) * grams * 10) / 10;
}

function giLabel(gi: number): string {
  if (gi <= 55) return 'Düşük GI';
  if (gi <= 69) return 'Orta GI';
  return 'Yüksek GI';
}

// ── Makro Halka (SVG tabanlı — doğru çalışan) ────────────────
const RING_SIZE    = 68;
const RING_STROKE  = 6;
const RING_RADIUS  = (RING_SIZE - RING_STROKE) / 2;
const RING_CIRCUM  = 2 * Math.PI * RING_RADIUS;

function MacroRing({ value, label, unit, color, max }: {
  value: number; label: string; unit: string; color: string; max: number;
}) {
  const pct    = max > 0 ? Math.min(100, (value / max) * 100) : 0;
  const offset = RING_CIRCUM - (pct / 100) * RING_CIRCUM;
  const cx     = RING_SIZE / 2;
  const cy     = RING_SIZE / 2;

  return (
    <View style={{ alignItems: 'center', flex: 1 }}>
      <View style={{ width: RING_SIZE, height: RING_SIZE, position: 'relative', marginBottom: 6 }}>
        <Svg width={RING_SIZE} height={RING_SIZE} viewBox={`0 0 ${RING_SIZE} ${RING_SIZE}`}>
          <G rotation="-90" origin={`${cx},${cy}`}>
            {/* Arka plan halkası */}
            <Circle
              cx={cx} cy={cy} r={RING_RADIUS}
              stroke={color + '22'}
              strokeWidth={RING_STROKE}
              fill={color + '08'}
            />
            {/* İlerleme halkası */}
            {pct > 0 && (
              <Circle
                cx={cx} cy={cy} r={RING_RADIUS}
                stroke={color}
                strokeWidth={RING_STROKE}
                fill="none"
                strokeDasharray={`${RING_CIRCUM} ${RING_CIRCUM}`}
                strokeDashoffset={offset}
                strokeLinecap="round"
              />
            )}
          </G>
        </Svg>

        {/* Ortadaki değer */}
        <View style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, alignItems: 'center', justifyContent: 'center' }}>
          <Text style={{ fontSize: 14, fontWeight: '900', color, lineHeight: 16 }}>{value}</Text>
          <Text style={{ fontSize: 8, fontWeight: '700', color: color + 'BB', letterSpacing: 0.2 }}>{unit}</Text>
        </View>
      </View>
      <Text style={{ fontSize: 11, fontWeight: '700', color: '#64748B' }}>{label}</Text>
    </View>
  );
}

// ── GI Göstergesi ────────────────────────────────────────────
function GIGauge({ gi }: { gi: number }) {
  const pct   = Math.min(100, (gi / 100) * 100);
  const color = gi >= 70 ? '#EF4444' : gi >= 56 ? '#F59E0B' : '#10B981';
  const label = gi >= 70 ? 'Yüksek' : gi >= 56 ? 'Orta' : 'Düşük';
  return (
    <View style={{ alignItems: 'center' }}>
      <View style={{ width: 80, height: 40, overflow: 'hidden', position: 'relative' }}>
        <View style={{ width: 80, height: 80, borderRadius: 40, borderWidth: 8, borderColor: '#F1F5F9', position: 'absolute', top: 0, left: 0 }} />
        <View style={{ width: 80, height: 80, borderRadius: 40, borderWidth: 8, borderColor: 'transparent', borderTopColor: color, borderRightColor: pct > 50 ? color : 'transparent', transform: [{ rotate: '-90deg' }], position: 'absolute', top: 0, left: 0 }} />
      </View>
      <Text style={{ fontSize: 22, fontWeight: '900', color, marginTop: -6 }}>{gi}</Text>
      <Text style={{ fontSize: 11, fontWeight: '700', color, marginTop: 2 }}>{label} GI</Text>
    </View>
  );
}

// ── Ana Ekran ────────────────────────────────────────────────
export default function FoodDetailScreen() {
  const route      = useRoute<any>();
  const navigation = useNavigation<any>();
  const food       = route.params?.food;
  const { addToDailyLog } = useAppStore();

  const giValue      = food?.gi_value ?? food?.glycemicIndex ?? 0;
  const initialCarbs = food?.carbs_per_100g ?? food?.carbsPer100g ?? 0;

  const [measureType, setMeasureType]     = useState<'pratik' | 'gram'>('pratik');
  const [gramValue, setGramValue]         = useState<number>(100);
  const [pratikValue, setPratikValue]     = useState<number>(1);
  const [carbs100, setCarbs100]           = useState<number | null>(initialCarbs > 0 ? initialCarbs : null);
  const [loadingCarbs, setLoadingCarbs]   = useState<boolean>(initialCarbs === 0);
  const [imageUrl, setImageUrl]           = useState<string | null>(null);
  const [loadingImage, setLoadingImage]   = useState<boolean>(true);
  const [coachAdvice, setCoachAdvice]     = useState<CoachPairing | null>(null);
  const [isFetchingAdvice, setIsFetchingAdvice] = useState<boolean>(false);
  const headerScale = useState(new Animated.Value(1))[0];

  const smartMeasure = useMemo(() => {
    if (!food) return { unit: 'Porsiyon', grams: 150, icon: '🍽️', presets: [0.5, 1, 1.5] } as PortionInfo;
    return getSmartPortion(food.name, food.category);
  }, [food]);

  const portion = measureType === 'gram' ? gramValue : pratikValue * smartMeasure.grams;

  const { instantCarbs, glValue, glStatus, glColor } = useGlycemicLoad(giValue, carbs100, portion);
  const { profile, glThresholds } = useUserStore();

  const personalGlStatus = useMemo(() => {
    if (!profile || profile.diabetesType === 'yok') return glStatus;
    if (glValue >= glThresholds.redThreshold) return 'red';
    if (glValue >= glThresholds.yellowThreshold) return 'yellow';
    return 'green';
  }, [glValue, glThresholds, profile, glStatus]);

  const personalGlColor  = personalGlStatus === 'red' ? '#EF4444' : personalGlStatus === 'yellow' ? '#F59E0B' : '#10B981';
  const foodRecommended  = profile ? isFoodRecommended(giValue, profile.diabetesType, profile.hba1c) : true;
  const giColor          = giValue >= 70 ? '#EF4444' : giValue >= 56 ? '#F59E0B' : '#059669';

  const bgGradientColors: [string, string] = useMemo(() => {
    if (giValue >= 70) return ['#FFEBEE', '#FFF'];
    if (giValue >= 56) return ['#FFF8E1', '#FFF'];
    return ['#E8F5E9', '#FFF'];
  }, [giValue]);

  const macros = useMemo(() => ({
    calories: scaleMacro(food?.calories_per_100g, portion),
    carbs:    scaleMacro(food?.carbs_per_100g ?? carbs100 ?? 0, portion),
    protein:  scaleMacro(food?.protein_per_100g, portion),
    fat:      scaleMacro(food?.fat_per_100g, portion),
    fiber:    scaleMacro(food?.fiber_per_100g, portion),
  }), [food, portion, carbs100]);

  const maxMacro = Math.max(macros.carbs, macros.protein, macros.fat, 1);

  useEffect(() => {
    if (!food?.name) { setLoadingImage(false); return; }

    // Supabase foods tablosunda image_url varsa direkt kullan
    if (food?.image_url) {
      setImageUrl(food.image_url);
      setLoadingImage(false);
      Animated.spring(headerScale, { toValue: 1.04, useNativeDriver: true, tension: 40 }).start(() =>
        Animated.spring(headerScale, { toValue: 1, useNativeDriver: true, tension: 60 }).start()
      );
      return;
    }

    // Yoksa Pixabay'den çek
    setLoadingImage(true);
    getFoodImage(food.name).then(url => {
      setImageUrl(url);
      setLoadingImage(false);
      if (url) {
        Animated.spring(headerScale, { toValue: 1.04, useNativeDriver: true, tension: 40 }).start(() =>
          Animated.spring(headerScale, { toValue: 1, useNativeDriver: true, tension: 60 }).start()
        );
      }
    });
  }, [food?.name, food?.image_url]);

  useEffect(() => {
    if (food && initialCarbs === 0) {
      setLoadingCarbs(true);
      getCarbsPer100g(food.name).then(c => {
        if (c !== null) setCarbs100(c);
        setLoadingCarbs(false);
      });
    }
  }, [food, initialCarbs]);

  useEffect(() => {
    let active = true;
    const timer = setTimeout(async () => {
      if (personalGlStatus === 'red' && food?.category) {
        setIsFetchingAdvice(true);
        const aiAdvice = await getSmartCoachAdvice(food, portion, profile);
        if (active) {
          if (aiAdvice) setCoachAdvice(aiAdvice);
          else { const db = await getCoachAdvice(food.category); setCoachAdvice(db); }
          setIsFetchingAdvice(false);
        }
      } else if (active) { setCoachAdvice(null); setIsFetchingAdvice(false); }
    }, 800);
    return () => { active = false; clearTimeout(timer); };
  }, [personalGlStatus, food, portion, profile]);

  const handleAddLog = () => {
    if (!food) return;
    const formatText = measureType === 'gram'
      ? `${gramValue}g`
      : `${pratikValue} ${smartMeasure.unit}${smartMeasure.ml ? ` (${Math.round(pratikValue * smartMeasure.ml)}ml)` : ''}`;
    addToDailyLog({ foodId: food.id.toString(), foodName: food.name, portion, portionText: formatText, glycemicLoad: glValue, trafficLight: personalGlStatus });
    if (personalGlStatus === 'red') scheduleHighGLNotification();
    Alert.alert('Eklendi ✅', 'Besin günlüğe kaydedildi!', [{ text: 'Tamam', onPress: () => navigation.goBack() }]);
  };

  if (!food) {
    return (
      <SafeAreaView style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#F5F7FA' }}>
        <Ionicons name="alert-circle-outline" size={54} color="#94A3B8" />
        <Text style={{ fontSize: 17, color: '#475569', marginTop: 14, fontWeight: '600' }}>Besin bilgisi bulunamadı.</Text>
        <TouchableOpacity onPress={() => navigation.goBack()} style={[s.btn, { marginTop: 20 }]}>
          <Text style={s.btnText}>Geri Dön</Text>
        </TouchableOpacity>
      </SafeAreaView>
    );
  }

  const portionLabel = measureType === 'gram'
    ? `${gramValue}g`
    : `${pratikValue} ${smartMeasure.unit}${smartMeasure.ml ? ` = ${Math.round(pratikValue * (smartMeasure.ml ?? 0))}ml` : ` ≈ ${Math.round(portion)}g`}`;

  return (
    <View style={{ flex: 1, backgroundColor: '#F5F7FA' }}>

      {/* ── HEADER FOTOĞRAF ──────────────────────────────────── */}
      <View style={{ position: 'absolute', top: 0, left: 0, right: 0, height: IMG_H }}>
        {/* Arka plan rengi */}
        <LinearGradient
          colors={bgGradientColors}
          style={StyleSheet.absoluteFill}
        />
        {loadingImage ? (
          <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
            <ActivityIndicator size="large" color="#0D7A6B" />
          </View>
        ) : imageUrl ? (
          <Animated.Image
            source={{ uri: imageUrl }}
            style={{ width: '100%', height: '100%', transform: [{ scale: headerScale }] }}
            resizeMode="cover"
          />
        ) : (
          <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
            <Text style={{ fontSize: 64 }}>{smartMeasure.icon}</Text>
          </View>
        )}

        {/* Çok katmanlı geçiş gradyanı */}
        <LinearGradient
          colors={['rgba(0,0,0,0)', 'rgba(0,0,0,0.08)', 'rgba(245,247,250,0.7)', '#F5F7FA']}
          locations={[0, 0.4, 0.78, 1]}
          style={{ position: 'absolute', bottom: 0, left: 0, right: 0, height: IMG_H * 0.65 }}
        />
        {/* Yan vinyetler */}
        <LinearGradient
          colors={['rgba(245,247,250,0.4)', 'transparent', 'rgba(245,247,250,0.4)']}
          start={{ x: 0, y: 0.5 }} end={{ x: 1, y: 0.5 }}
          style={StyleSheet.absoluteFill}
        />
      </View>

      {/* Geri Butonu */}
      <SafeAreaView style={{ position: 'absolute', top: 0, left: 0, right: 0, zIndex: 10, paddingHorizontal: 16, paddingTop: 10 }} pointerEvents="box-none">
        <TouchableOpacity onPress={() => navigation.goBack()} style={s.backBtn}>
          <Ionicons name="arrow-back" size={22} color="#0F172A" />
        </TouchableOpacity>
      </SafeAreaView>

      {/* ── SCROLL İÇERİK ────────────────────────────────────── */}
      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{ paddingTop: IMG_H - 44, paddingHorizontal: 16, paddingBottom: 130 }}
        showsVerticalScrollIndicator={false}
      >
        {/* ── HERO KARTI ──────────────────────────────────────── */}
        <View style={[s.card, { marginBottom: 12, overflow: 'hidden' }]}>
          {/* Renk aksanı şeridi */}
          <View style={{ height: 4, backgroundColor: giColor, borderRadius: 4, marginBottom: 16, marginHorizontal: -18, marginTop: -18 }} />

          <View style={{ flexDirection: 'row', alignItems: 'flex-start' }}>
            <View style={{ flex: 1, marginRight: 12 }}>
              <Text style={s.foodName} numberOfLines={2}>{food.name}</Text>
              <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 6, gap: 6, flexWrap: 'wrap' }}>
                <View style={[s.pill, { backgroundColor: '#F1F5F9' }]}>
                  <Ionicons name="layers-outline" size={11} color="#64748B" style={{ marginRight: 4 }} />
                  <Text style={[s.pillText, { color: '#64748B' }]}>{food.category || 'Genel'}</Text>
                </View>
                {!foodRecommended && profile && (
                  <View style={[s.pill, { backgroundColor: '#FEE2E2' }]}>
                    <Text style={[s.pillText, { color: '#DC2626' }]}>⚠ {DIABETES_TYPE_LABELS[profile.diabetesType]} için önerilmez</Text>
                  </View>
                )}
              </View>
            </View>
            <GIGauge gi={giValue} />
          </View>
        </View>

        {/* ── PORSİYON KONTROL ──────────────────────────────── */}
        <View style={[s.card, { marginBottom: 12 }]}>
          <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 14 }}>
            <Text style={{ fontSize: 22, marginRight: 8 }}>{smartMeasure.icon}</Text>
            <Text style={s.sectionTitle}>Porsiyon</Text>
            <View style={{ flex: 1 }} />
            {/* Mod seçici */}
            <View style={{ flexDirection: 'row', backgroundColor: '#F1F5F9', borderRadius: 10, padding: 2 }}>
              {(['pratik', 'gram'] as const).map(m => (
                <TouchableOpacity
                  key={m}
                  onPress={() => setMeasureType(m)}
                  style={[{ paddingHorizontal: 12, paddingVertical: 6, borderRadius: 8 },
                    measureType === m && { backgroundColor: '#0D7A6B' }]}
                >
                  <Text style={{ fontSize: 12, fontWeight: '700', color: measureType === m ? '#FFF' : '#64748B' }}>
                    {m === 'gram' ? 'g' : smartMeasure.unit}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>

          {/* Pratik hızlı preset butonları */}
          {measureType === 'pratik' && (
            <View style={{ flexDirection: 'row', gap: 8, marginBottom: 16 }}>
              {smartMeasure.presets.map(p => (
                <TouchableOpacity
                  key={p}
                  onPress={() => setPratikValue(p)}
                  style={[s.presetBtn, pratikValue === p && s.presetBtnActive]}
                >
                  <Text style={[s.presetText, pratikValue === p && s.presetTextActive]}>
                    {p % 1 === 0 ? p : p}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          )}

          {/* Değer büyük */}
          <View style={{ alignItems: 'center', marginBottom: 6 }}>
            <Text style={s.portionBig}>{portionLabel}</Text>
            {loadingCarbs
              ? <ActivityIndicator size="small" color="#0D7A6B" style={{ marginTop: 4 }} />
              : <Text style={s.portionSub}>{instantCarbs}g karbonhidrat</Text>
            }
          </View>

          <Slider
            style={{ width: '100%', height: 40 }}
            minimumValue={measureType === 'gram' ? 10 : 0.5}
            maximumValue={measureType === 'gram' ? 500 : Math.max(...smartMeasure.presets) * 2}
            step={measureType === 'gram' ? 5 : 0.5}
            value={measureType === 'gram' ? gramValue : pratikValue}
            onValueChange={v => measureType === 'gram' ? setGramValue(Math.round(v)) : setPratikValue(Math.round(v * 2) / 2)}
            minimumTrackTintColor="#0D7A6B"
            maximumTrackTintColor="#E2E8F0"
            thumbTintColor="#0D7A6B"
          />
          <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
            <Text style={s.sliderMark}>{measureType === 'gram' ? '10g' : `0.5 ${smartMeasure.unit}`}</Text>
            <Text style={s.sliderMark}>{measureType === 'gram' ? '500g' : `${Math.max(...smartMeasure.presets) * 2} ${smartMeasure.unit}`}</Text>
          </View>
        </View>

        {/* ── GL PANELİ ─────────────────────────────────────── */}
        <View style={[s.card, { marginBottom: 12, borderWidth: 2, borderColor: personalGlColor + '55', shadowColor: personalGlColor, shadowOpacity: 0.12 }]}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 16 }}>
            {/* GL sayı */}
            <View style={{ alignItems: 'center', minWidth: 90, backgroundColor: personalGlColor + '12', borderRadius: 16, padding: 14 }}>
              <Text style={{ fontSize: 11, fontWeight: '700', color: personalGlColor, textTransform: 'uppercase', letterSpacing: 0.8 }}>GL</Text>
              <Text style={{ fontSize: 52, fontWeight: '900', color: personalGlColor, lineHeight: 58 }}>{glValue}</Text>
              <Text style={{ fontSize: 11, fontWeight: '700', color: personalGlColor }}>
                {personalGlStatus === 'green' ? 'Güvenli' : personalGlStatus === 'yellow' ? 'Dikkat' : 'Riskli'}
              </Text>
            </View>

            <View style={{ flex: 1 }}>
              {/* Durum banner */}
              <View style={{ backgroundColor: personalGlColor + '14', borderRadius: 12, padding: 12, marginBottom: 10, flexDirection: 'row', alignItems: 'center' }}>
                <Ionicons
                  name={personalGlStatus === 'green' ? 'checkmark-circle' : personalGlStatus === 'yellow' ? 'alert-circle' : 'warning'}
                  size={18} color={personalGlColor} style={{ marginRight: 8 }}
                />
                <Text style={{ fontSize: 14, fontWeight: '800', color: personalGlColor }}>
                  {personalGlStatus === 'green' ? 'Güvenli Bölge' : personalGlStatus === 'yellow' ? 'Dikkat Bölgesi' : 'Risk Bölgesi!'}
                </Text>
              </View>

              {/* Eşikler */}
              <View style={{ flexDirection: 'row', gap: 8 }}>
                <View style={{ flex: 1, backgroundColor: '#FEF3C7', borderRadius: 10, padding: 8, alignItems: 'center' }}>
                  <Text style={{ fontSize: 9, fontWeight: '700', color: '#92400E', textTransform: 'uppercase' }}>Dikkat</Text>
                  <Text style={{ fontSize: 15, fontWeight: '900', color: '#F59E0B' }}>≥{glThresholds.yellowThreshold}</Text>
                </View>
                <View style={{ flex: 1, backgroundColor: '#FEE2E2', borderRadius: 10, padding: 8, alignItems: 'center' }}>
                  <Text style={{ fontSize: 9, fontWeight: '700', color: '#991B1B', textTransform: 'uppercase' }}>Risk</Text>
                  <Text style={{ fontSize: 15, fontWeight: '900', color: '#EF4444' }}>≥{glThresholds.redThreshold}</Text>
                </View>
              </View>

              {profile?.diabetesType !== 'yok' && personalGlStatus !== glStatus && (
                <Text style={{ fontSize: 11, color: '#0369A1', fontWeight: '600', marginTop: 6 }}>
                  ⓘ {DIABETES_TYPE_LABELS[profile!.diabetesType]} eşiği uygulandı
                </Text>
              )}
            </View>
          </View>

          {personalGlStatus === 'red' && (
            <View style={{ flexDirection: 'row', backgroundColor: '#EF4444', borderRadius: 12, padding: 12, alignItems: 'center', marginTop: 12 }}>
              <Ionicons name="warning" size={20} color="#FFF" style={{ marginRight: 8 }} />
              <Text style={{ color: '#FFF', fontWeight: '700', fontSize: 13, flex: 1, lineHeight: 18 }}>
                Bu porsiyon kan şekerini hızla yükseltir! Porsiyonu azaltmayı deneyin.
              </Text>
            </View>
          )}
        </View>

        {/* ── BESİN DEĞERLERİ ───────────────────────────────── */}
        <View style={[s.card, { marginBottom: 12 }]}>
          <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 16 }}>
            <Ionicons name="nutrition-outline" size={20} color="#0D7A6B" style={{ marginRight: 8 }} />
            <Text style={s.sectionTitle}>Besin Değerleri</Text>
            <View style={{ flex: 1 }} />
            <View style={{ backgroundColor: '#F0FDF4', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 10 }}>
              <Text style={{ fontSize: 11, fontWeight: '700', color: '#059669' }}>{portionLabel}</Text>
            </View>
          </View>

          {/* Kalori büyük */}
          {macros.calories > 0 && (
            <LinearGradient
              colors={['#FFF7ED', '#FFEDD5']}
              start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
              style={{ borderRadius: 16, padding: 16, flexDirection: 'row', alignItems: 'center', marginBottom: 18, borderWidth: 1, borderColor: '#FED7AA' }}
            >
              <Text style={{ fontSize: 32 }}>🔥</Text>
              <View style={{ flex: 1, marginLeft: 14 }}>
                <Text style={{ fontSize: 38, fontWeight: '900', color: '#C2410C', lineHeight: 42 }}>{macros.calories}</Text>
                <Text style={{ fontSize: 12, fontWeight: '600', color: '#9A3412' }}>kcal · bu porsiyonda</Text>
              </View>
              {food.calories_per_100g > 0 && (
                <View style={{ alignItems: 'flex-end' }}>
                  <Text style={{ fontSize: 11, color: '#999', marginBottom: 2 }}>100g'da</Text>
                  <Text style={{ fontSize: 15, fontWeight: '800', color: '#C2410C' }}>{food.calories_per_100g}</Text>
                  <Text style={{ fontSize: 10, color: '#9A3412', fontWeight: '600' }}>kcal</Text>
                </View>
              )}
            </LinearGradient>
          )}

          {/* Makro halkalar */}
          <View style={{ flexDirection: 'row', justifyContent: 'space-around', marginBottom: 18 }}>
            <MacroRing value={macros.carbs}   label="Karb"    unit="g" color="#F59E0B" max={maxMacro} />
            <MacroRing value={macros.protein} label="Protein" unit="g" color="#3B82F6" max={maxMacro} />
            <MacroRing value={macros.fat}     label="Yağ"     unit="g" color="#8B5CF6" max={maxMacro} />
            <MacroRing value={macros.fiber}   label="Lif"     unit="g" color="#10B981" max={maxMacro} />
          </View>

          {/* 100g referans */}
          <View style={{ borderTopWidth: 1, borderTopColor: '#F1F5F9', paddingTop: 14 }}>
            <Text style={{ fontSize: 11, fontWeight: '700', color: '#94A3B8', textTransform: 'uppercase', letterSpacing: 0.6, marginBottom: 10 }}>
              100g başına referans değerler
            </Text>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
              {[
                { icon: '🌾', label: 'Karb',    value: food.carbs_per_100g,    unit: 'g',   color: '#92400E', bg: '#FEF3C7' },
                { icon: '💪', label: 'Protein', value: food.protein_per_100g,  unit: 'g',   color: '#1D4ED8', bg: '#EFF6FF' },
                { icon: '🫒', label: 'Yağ',     value: food.fat_per_100g,      unit: 'g',   color: '#6D28D9', bg: '#F5F3FF' },
                { icon: '🌿', label: 'Lif',     value: food.fiber_per_100g,    unit: 'g',   color: '#166534', bg: '#F0FDF4' },
                { icon: '🔥', label: 'Kalori',  value: food.calories_per_100g, unit: 'kcal',color: '#C2410C', bg: '#FFF7ED' },
              ].filter(m => m.value > 0).map(m => (
                <View key={m.label} style={{ backgroundColor: m.bg, borderRadius: 14, padding: 12, alignItems: 'center', minWidth: 68 }}>
                  <Text style={{ fontSize: 18, marginBottom: 4 }}>{m.icon}</Text>
                  <Text style={{ fontSize: 16, fontWeight: '900', color: m.color }}>{Math.round(m.value * 10) / 10}</Text>
                  <Text style={{ fontSize: 9, fontWeight: '600', color: m.color + 'AA' }}>{m.unit}</Text>
                  <Text style={{ fontSize: 10, fontWeight: '600', color: '#888', marginTop: 2 }}>{m.label}</Text>
                </View>
              ))}
            </View>
          </View>
        </View>

        {/* ── GI BİLGİ KARTI ───────────────────────────────── */}
        <View style={[s.card, { marginBottom: 12 }]}>
          <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 12 }}>
            <Ionicons name="analytics-outline" size={20} color="#6366F1" style={{ marginRight: 8 }} />
            <Text style={s.sectionTitle}>Glisemik İndeks Skalası</Text>
          </View>
          <View style={{ flexDirection: 'row', gap: 8, marginBottom: 12 }}>
            {[
              { label: 'Düşük', range: '≤ 55', color: '#10B981', active: giValue <= 55 },
              { label: 'Orta',  range: '56–69', color: '#F59E0B', active: giValue >= 56 && giValue <= 69 },
              { label: 'Yüksek',range: '≥ 70', color: '#EF4444', active: giValue >= 70 },
            ].map(item => (
              <View key={item.label} style={{
                flex: 1, borderRadius: 14, padding: 10, alignItems: 'center',
                backgroundColor: item.active ? item.color + '14' : '#F8FAFC',
                borderWidth: item.active ? 2 : 1,
                borderColor: item.active ? item.color : '#E2E8F0',
              }}>
                <View style={{ width: 10, height: 10, borderRadius: 5, backgroundColor: item.active ? item.color : '#CBD5E1', marginBottom: 4 }} />
                <Text style={{ fontSize: 11, fontWeight: '800', color: item.active ? item.color : '#94A3B8' }}>{item.label}</Text>
                <Text style={{ fontSize: 12, fontWeight: '900', color: item.active ? item.color : '#CBD5E1', marginTop: 1 }}>{item.range}</Text>
              </View>
            ))}
          </View>
          <Text style={{ fontSize: 13, color: '#64748B', lineHeight: 20 }}>
            {personalGlStatus === 'green'
              ? '✅ Bu porsiyon kan şekerinizi nazikçe yükseltir. Güvenli tüketim aralığında.'
              : personalGlStatus === 'yellow'
              ? '⚡ Porsiyonu azaltmayı deneyin veya protein ile dengeleyin.'
              : '🚨 Bu porsiyon kan şekerini hızla yükseltebilir. Miktarı azaltın.'}
          </Text>
        </View>

        {/* ── KOÇ TAVSİYESİ ────────────────────────────────── */}
        {isFetchingAdvice && (
          <View style={[s.card, { flexDirection: 'row', alignItems: 'center', marginBottom: 12, backgroundColor: '#FFFBEB', borderWidth: 1, borderColor: '#FDE68A' }]}>
            <ActivityIndicator size="small" color="#D97706" />
            <Text style={{ marginLeft: 10, color: '#92400E', fontWeight: '700', fontSize: 14 }}>Koç özel tavsiye hazırlıyor...</Text>
          </View>
        )}
        {coachAdvice && !isFetchingAdvice && <CoachAdviceCard advice={coachAdvice} />}
      </ScrollView>

      {/* ── GÜNLÜĞE EKLE BUTONU ───────────────────────────── */}
      <View style={s.addBtnWrapper} pointerEvents="box-none">
        <TouchableOpacity
          activeOpacity={0.88}
          style={{ borderRadius: 28, overflow: 'hidden', shadowColor: '#006B5E', shadowOffset: { width: 0, height: 8 }, shadowOpacity: 0.3, shadowRadius: 16, elevation: 12 }}
          onPress={handleAddLog}
          disabled={loadingCarbs}
        >
          <LinearGradient
            colors={loadingCarbs ? ['#80C4BC', '#80C4BC'] : ['#0A5748', '#0D7A6B', '#0FA880']}
            start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
            style={{ height: 60, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', paddingHorizontal: 24 }}
          >
            {loadingCarbs
              ? <ActivityIndicator size="small" color="#FFF" />
              : <>
                  <Ionicons name="add-circle" size={24} color="#FFF" style={{ marginRight: 10 }} />
                  <Text style={{ color: '#FFF', fontSize: 17, fontWeight: '900', letterSpacing: 0.3 }}>Günlüğe Ekle</Text>
                  <View style={{ flex: 1 }} />
                  <View style={{ backgroundColor: 'rgba(255,255,255,0.2)', paddingHorizontal: 10, paddingVertical: 5, borderRadius: 10 }}>
                    <Text style={{ color: '#FFF', fontSize: 13, fontWeight: '700' }}>{portionLabel}</Text>
                  </View>
                </>
            }
          </LinearGradient>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  backBtn: {
    width: 40, height: 40, borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.88)',
    justifyContent: 'center', alignItems: 'center',
    shadowColor: '#000', shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15, shadowRadius: 8, elevation: 4,
    marginTop: 8,
  },
  card: {
    backgroundColor: '#FFF', borderRadius: 22, padding: 18,
    shadowColor: '#0F172A', shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.06, shadowRadius: 10, elevation: 3,
    marginBottom: 12,
  },
  foodName: {
    fontSize: 22, fontWeight: '900', color: '#0F172A', lineHeight: 28,
  },
  pill: {
    flexDirection: 'row', alignItems: 'center',
    paddingVertical: 4, paddingHorizontal: 10, borderRadius: 10,
  },
  pillText: { fontSize: 11, fontWeight: '700' },
  sectionTitle: { fontSize: 16, fontWeight: '800', color: '#0F172A' },

  // Preset butonları
  presetBtn: {
    flex: 1, paddingVertical: 10, borderRadius: 12,
    backgroundColor: '#F1F5F9', alignItems: 'center',
    borderWidth: 1.5, borderColor: 'transparent',
  },
  presetBtnActive: {
    backgroundColor: '#E8F5F3', borderColor: '#0D7A6B',
  },
  presetText: { fontSize: 14, fontWeight: '700', color: '#64748B' },
  presetTextActive: { color: '#0D7A6B', fontWeight: '900' },

  portionBig: { fontSize: 28, fontWeight: '900', color: '#0F172A', textAlign: 'center' },
  portionSub: { fontSize: 13, color: '#94A3B8', fontWeight: '500', marginTop: 3, textAlign: 'center' },
  sliderMark: { fontSize: 11, color: '#CBD5E1', fontWeight: '600' },

  btn: {
    backgroundColor: '#0D7A6B', paddingVertical: 14, paddingHorizontal: 28, borderRadius: 16,
  },
  btnText: { color: '#FFF', fontWeight: '800', fontSize: 16 },

  addBtnWrapper: {
    position: 'absolute', bottom: 0, left: 0, right: 0,
    paddingHorizontal: 16, paddingBottom: 28, paddingTop: 8,
    backgroundColor: 'transparent',
  },
});
