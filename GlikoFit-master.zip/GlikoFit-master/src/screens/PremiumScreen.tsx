import React, { useState } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet, Alert, Dimensions,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';

const { width: SW } = Dimensions.get('window');

// ── Özellik listesi ────────────────────────────────────────────

const FREE_FEATURES = [
  { icon: 'search-outline',      text: 'Besin arama (günlük 20 arama)' },
  { icon: 'analytics-outline',   text: 'GL hesaplama (temel)' },
  { icon: 'journal-outline',     text: 'Günlük yemek kaydı (20 kayıt/gün)' },
  { icon: 'barcode-outline',     text: 'Barkod ile besin tarama' },
  { icon: 'water-outline',       text: 'Günlük su takibi' },
  { icon: 'leaf-outline',        text: 'Temel GI veritabanı (500+ besin)' },
  { icon: 'restaurant-outline',  text: 'Öğün oluşturucu (temel)' },
];

const PREMIUM_FEATURES = [
  { icon: 'sparkles',            text: 'AI Koç — Gemini ile kişisel tavsiye', hot: true },
  { icon: 'camera-outline',      text: 'Fotoğrafla yemek tanıma (LogMeal AI)', hot: true },
  { icon: 'infinite-outline',    text: 'Sınırsız yemek kaydı ve arama' },
  { icon: 'trending-up-outline', text: 'GL trend grafiği ve haftalık analiz' },
  { icon: 'people-outline',      text: 'Diyabet tipine özel kişiselleştirilmiş GL eşikleri' },
  { icon: 'restaurant',          text: 'Tarif keşfet — diyabet dostu tarifler' },
  { icon: 'fitness-outline',     text: 'Egzersiz & kalori takibi entegrasyonu' },
  { icon: 'shield-checkmark-outline', text: 'HbA1c & kan şekeri geçmişi' },
  { icon: 'notifications-outline', text: 'Akıllı öğün hatırlatıcıları' },
  { icon: 'cloud-download-outline', text: 'Veri dışa aktarma (PDF/CSV)' },
];

// ── Fiyat planı ────────────────────────────────────────────────

const PLANS = [
  {
    id: 'monthly',
    label: 'Aylık',
    price: '₺49,99',
    period: '/ay',
    subtext: 'İstediğin zaman iptal et',
    badge: null,
    gradient: ['#1E3A5F', '#2563EB'] as [string, string],
  },
  {
    id: 'yearly',
    label: 'Yıllık',
    price: '₺399,99',
    period: '/yıl',
    subtext: '≈ ₺33,33/ay · %33 tasarruf',
    badge: 'En İyi Değer',
    gradient: ['#064E3B', '#0D7A6B'] as [string, string],
  },
];

// ── Bileşen ───────────────────────────────────────────────────

export default function PremiumScreen() {
  const insets = useSafeAreaInsets();
  const nav    = useNavigation<any>();
  const [selectedPlan, setSelectedPlan] = useState<'monthly' | 'yearly'>('yearly');

  const handleSubscribe = () => {
    Alert.alert(
      'Yakında 🚀',
      'Premium abonelik yakında aktif olacak. RevenueCat entegrasyonu tamamlanıyor.',
      [{ text: 'Tamam' }]
    );
  };

  return (
    <View style={{ flex: 1, backgroundColor: '#0A0F1E' }}>
      {/* Header gradient */}
      <LinearGradient
        colors={['#0D1B3E', '#0A0F1E']}
        style={{ paddingTop: insets.top + 16, paddingBottom: 32, paddingHorizontal: 20 }}
      >
        {/* Geri */}
        <TouchableOpacity onPress={() => nav.goBack()} style={styles.backBtn}>
          <Ionicons name="arrow-back" size={22} color="#FFF" />
        </TouchableOpacity>

        {/* Başlık */}
        <View style={{ alignItems: 'center', marginTop: 16 }}>
          <View style={styles.crownWrap}>
            <LinearGradient colors={['#F59E0B', '#D97706']} style={styles.crownGradient}>
              <Ionicons name="diamond" size={36} color="#FFF" />
            </LinearGradient>
          </View>
          <Text style={styles.heroTitle}>GlikoFit Premium</Text>
          <Text style={styles.heroSub}>Diyabet yönetiminizi bir üst seviyeye taşıyın</Text>
        </View>

        {/* Dekoratif */}
        <View style={styles.deco1} pointerEvents="none" />
        <View style={styles.deco2} pointerEvents="none" />
      </LinearGradient>

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 120, paddingHorizontal: 16 }}
      >
        {/* ── PLAN SEÇİCİ ──────────────────────────────────── */}
        <View style={{ flexDirection: 'row', gap: 10, marginTop: -16, marginBottom: 24 }}>
          {PLANS.map(plan => (
            <TouchableOpacity
              key={plan.id}
              onPress={() => setSelectedPlan(plan.id as any)}
              style={{ flex: 1 }}
              activeOpacity={0.85}
            >
              <LinearGradient
                colors={selectedPlan === plan.id ? plan.gradient : ['#1E293B', '#1E293B']}
                style={[styles.planCard, selectedPlan === plan.id && styles.planCardActive]}
              >
                {plan.badge && (
                  <View style={styles.planBadge}>
                    <Text style={styles.planBadgeText}>{plan.badge} 🏆</Text>
                  </View>
                )}
                <Text style={styles.planLabel}>{plan.label}</Text>
                <Text style={styles.planPrice}>{plan.price}</Text>
                <Text style={styles.planPeriod}>{plan.period}</Text>
                <Text style={styles.planSub}>{plan.subtext}</Text>
                {selectedPlan === plan.id && (
                  <View style={styles.planCheck}>
                    <Ionicons name="checkmark-circle" size={18} color="#FFF" />
                  </View>
                )}
              </LinearGradient>
            </TouchableOpacity>
          ))}
        </View>

        {/* ── ÜCRETSİZ vs PREMİUM KARŞILAŞTIRMA ───────────── */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Ücretsiz Planda Neler Var?</Text>
          {FREE_FEATURES.map((f, i) => (
            <View key={i} style={styles.featureRow}>
              <View style={[styles.featureIcon, { backgroundColor: '#1E293B' }]}>
                <Ionicons name={f.icon as any} size={16} color="#64748B" />
              </View>
              <Text style={styles.featureText}>{f.text}</Text>
              <Ionicons name="checkmark" size={16} color="#94A3B8" />
            </View>
          ))}
        </View>

        <View style={[styles.section, { borderColor: '#F59E0B55', borderWidth: 1 }]}>
          <LinearGradient
            colors={['rgba(245,158,11,0.1)', 'transparent']}
            style={StyleSheet.absoluteFill}
          />
          <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 14 }}>
            <Ionicons name="diamond" size={20} color="#F59E0B" style={{ marginRight: 8 }} />
            <Text style={[styles.sectionTitle, { color: '#F59E0B' }]}>Premium'da Her Şey Var</Text>
          </View>
          {PREMIUM_FEATURES.map((f, i) => (
            <View key={i} style={styles.featureRow}>
              <LinearGradient
                colors={['#064E3B', '#0D7A6B']}
                style={styles.featureIcon}
              >
                <Ionicons name={f.icon as any} size={15} color="#FFF" />
              </LinearGradient>
              <Text style={[styles.featureText, { color: '#E2E8F0' }]}>{f.text}</Text>
              {f.hot && (
                <View style={styles.hotBadge}>
                  <Text style={styles.hotText}>YENİ</Text>
                </View>
              )}
            </View>
          ))}
        </View>

        {/* ── KULLANICI YORUMLARI ───────────────────────────── */}
        <View style={styles.reviewCard}>
          <Text style={styles.reviewQuote}>"GL takibi ve AI koç sayesinde HbA1c değerim 3 ayda 8.4'ten 6.9'a düştü!"</Text>
          <Text style={styles.reviewName}>— Ayşe K., Tip 2 Diyabet</Text>
        </View>
      </ScrollView>

      {/* ── ALT BUTON ────────────────────────────────────────── */}
      <View style={[styles.bottomBar, { paddingBottom: insets.bottom + 16 }]}>
        <TouchableOpacity onPress={handleSubscribe} activeOpacity={0.88} style={{ borderRadius: 20, overflow: 'hidden' }}>
          <LinearGradient
            colors={['#F59E0B', '#D97706']}
            start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
            style={styles.subBtn}
          >
            <Ionicons name="diamond" size={20} color="#FFF" style={{ marginRight: 10 }} />
            <Text style={styles.subBtnText}>
              {selectedPlan === 'yearly' ? '₺399,99/yıl ile Başla' : '₺49,99/ay ile Başla'}
            </Text>
          </LinearGradient>
        </TouchableOpacity>
        <Text style={styles.legalText}>
          İstediğin zaman iptal edebilirsin · Otomatik yenileme · Gizlilik Politikası
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  backBtn: {
    width: 40, height: 40, borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.1)',
    alignItems: 'center', justifyContent: 'center',
  },
  crownWrap: {
    marginBottom: 16, shadowColor: '#F59E0B',
    shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.5, shadowRadius: 16, elevation: 10,
  },
  crownGradient: {
    width: 80, height: 80, borderRadius: 40,
    alignItems: 'center', justifyContent: 'center',
  },
  heroTitle: { fontSize: 28, fontWeight: '900', color: '#FFF', marginBottom: 8 },
  heroSub:   { fontSize: 14, color: 'rgba(255,255,255,0.65)', textAlign: 'center', lineHeight: 20 },
  deco1: {
    position: 'absolute', right: -40, top: 20,
    width: 160, height: 160, borderRadius: 80,
    backgroundColor: 'rgba(245,158,11,0.06)',
  },
  deco2: {
    position: 'absolute', left: -20, bottom: 0,
    width: 100, height: 100, borderRadius: 50,
    backgroundColor: 'rgba(13,122,107,0.08)',
  },

  planCard: {
    borderRadius: 20, padding: 18, alignItems: 'center',
    borderWidth: 1.5, borderColor: 'transparent', position: 'relative', overflow: 'hidden',
  },
  planCardActive: { borderColor: 'rgba(255,255,255,0.25)' },
  planBadge:      { backgroundColor: '#F59E0B', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8, marginBottom: 10 },
  planBadgeText:  { fontSize: 10, fontWeight: '800', color: '#000' },
  planLabel:      { fontSize: 12, fontWeight: '700', color: 'rgba(255,255,255,0.7)', marginBottom: 6 },
  planPrice:      { fontSize: 26, fontWeight: '900', color: '#FFF' },
  planPeriod:     { fontSize: 12, color: 'rgba(255,255,255,0.6)', fontWeight: '600', marginBottom: 6 },
  planSub:        { fontSize: 10, color: 'rgba(255,255,255,0.5)', textAlign: 'center' },
  planCheck:      { position: 'absolute', top: 10, right: 10 },

  section: {
    backgroundColor: '#111827', borderRadius: 20, padding: 18, marginBottom: 14, overflow: 'hidden',
  },
  sectionTitle: { fontSize: 15, fontWeight: '800', color: '#F1F5F9', marginBottom: 14 },
  featureRow:   { flexDirection: 'row', alignItems: 'center', marginBottom: 12 },
  featureIcon:  { width: 32, height: 32, borderRadius: 10, alignItems: 'center', justifyContent: 'center', marginRight: 12 },
  featureText:  { flex: 1, fontSize: 13, fontWeight: '500', color: '#94A3B8', lineHeight: 18 },
  hotBadge:     { backgroundColor: '#EF4444', paddingHorizontal: 6, paddingVertical: 2, borderRadius: 6 },
  hotText:      { fontSize: 9, fontWeight: '800', color: '#FFF' },

  reviewCard: {
    backgroundColor: '#111827', borderRadius: 20, padding: 18, marginBottom: 14,
    borderLeftWidth: 3, borderLeftColor: '#0D7A6B',
  },
  reviewQuote: { fontSize: 14, color: '#CBD5E1', lineHeight: 22, fontStyle: 'italic', marginBottom: 10 },
  reviewName:  { fontSize: 12, fontWeight: '700', color: '#64748B' },

  bottomBar: {
    position: 'absolute', bottom: 0, left: 0, right: 0,
    backgroundColor: '#0A0F1E', paddingHorizontal: 16, paddingTop: 12,
    borderTopWidth: 1, borderTopColor: 'rgba(255,255,255,0.06)',
  },
  subBtn:     { paddingVertical: 18, flexDirection: 'row', justifyContent: 'center', alignItems: 'center' },
  subBtnText: { fontSize: 17, fontWeight: '900', color: '#FFF', letterSpacing: 0.3 },
  legalText:  { fontSize: 10, color: '#475569', textAlign: 'center', marginTop: 10, lineHeight: 16 },
});
