import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity,
  TextInput, Image, ActivityIndicator, ScrollView,
  Linking, Platform,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { searchRecipes, getPopularRecipes, getRecipeDetail } from '../lib/fatsecret';
import type { FsRecipe } from '../lib/fatsecret';

type TabKey = 'popular' | 'search' | 'detail';

// ══════════════════════════════════════════════════════════════
//  🥗 Tarif Ekranı
// ══════════════════════════════════════════════════════════════

export default function RecipeScreen() {
  const insets = useSafeAreaInsets();
  const nav    = useNavigation<any>();

  const [tab, setTab]             = useState<TabKey>('popular');
  const [query, setQuery]         = useState('');
  const [recipes, setRecipes]     = useState<Omit<FsRecipe, 'ingredients'>[]>([]);
  const [selected, setSelected]   = useState<FsRecipe | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Popüler tarifleri yükle
  useEffect(() => {
    if (tab === 'popular' && recipes.length === 0) {
      setIsLoading(true);
      getPopularRecipes(12).then((r) => { setRecipes(r); setIsLoading(false); });
    }
  }, [tab]);

  const handleSearch = useCallback(async () => {
    if (!query.trim()) return;
    setIsLoading(true);
    const r = await searchRecipes(query.trim(), 15);
    setRecipes(r);
    setIsLoading(false);
  }, [query]);

  const openDetail = async (recipeId: string) => {
    setTab('detail');
    setIsLoading(true);
    const detail = await getRecipeDetail(recipeId);
    setSelected(detail);
    setIsLoading(false);
  };

  const macroColor = (val: number, type: 'carb' | 'protein' | 'fat') => {
    const colors = { carb:'#F59E0B', protein:'#10B981', fat:'#EF4444' };
    return colors[type];
  };

  // ── Tarif Kartı ────────────────────────────────────────────
  const RecipeCard = ({ item }: { item: Omit<FsRecipe, 'ingredients'> }) => (
    <TouchableOpacity style={styles.card} activeOpacity={0.7} onPress={() => openDetail(item.recipe_id)}>
      {item.image_url ? (
        <Image source={{ uri: item.image_url }} style={styles.cardImg} resizeMode="cover" />
      ) : (
        <View style={[styles.cardImg, styles.cardImgPlaceholder]}>
          <Ionicons name="restaurant-outline" size={30} color="#6B7280" />
        </View>
      )}
      <View style={styles.cardBody}>
        <Text style={styles.cardTitle} numberOfLines={2}>{item.recipe_name}</Text>

        {/* Rating */}
        {item.rating > 0 && (
          <View style={styles.ratingRow}>
            {[1,2,3,4,5].map((i) => (
              <Ionicons key={i} name={i <= Math.round(item.rating) ? 'star' : 'star-outline'} size={12} color="#F59E0B" />
            ))}
            <Text style={styles.ratingText}>{item.rating.toFixed(1)}</Text>
          </View>
        )}

        {/* Süre */}
        <View style={styles.metaRow}>
          {item.preparation_time_min > 0 && (
            <View style={styles.metaChip}>
              <Ionicons name="timer-outline" size={12} color="#9CA3AF" />
              <Text style={styles.metaText}>{item.preparation_time_min + item.cooking_time_min} dk</Text>
            </View>
          )}
          {item.number_of_servings > 0 && (
            <View style={styles.metaChip}>
              <Ionicons name="people-outline" size={12} color="#9CA3AF" />
              <Text style={styles.metaText}>{item.number_of_servings} kişi</Text>
            </View>
          )}
        </View>

        {/* Mini Makro */}
        <View style={styles.miniMacro}>
          <Text style={[styles.miniMacroText, { color:'#F59E0B' }]}>{Math.round(item.serving_nutrition.carbs)}g K</Text>
          <Text style={styles.miniDot}>·</Text>
          <Text style={[styles.miniMacroText, { color:'#10B981' }]}>{Math.round(item.serving_nutrition.protein)}g P</Text>
          <Text style={styles.miniDot}>·</Text>
          <Text style={[styles.miniMacroText, { color:'#6B7280' }]}>{Math.round(item.serving_nutrition.calories)} kcal</Text>
        </View>
      </View>
    </TouchableOpacity>
  );

  // ── Tarif Detayı ────────────────────────────────────────────
  if (tab === 'detail') {
    if (isLoading) {
      return (
        <View style={styles.centered}>
          <ActivityIndicator size="large" color="#10B981" />
          <Text style={styles.loadingText}>Tarif yükleniyor...</Text>
        </View>
      );
    }
    if (!selected) {
      return (
        <View style={styles.centered}>
          <Text style={styles.loadingText}>Tarif bulunamadı</Text>
          <TouchableOpacity style={styles.backBtnAlt} onPress={() => setTab('popular')}>
            <Text style={{ color:'#10B981', fontWeight:'700' }}>Geri Dön</Text>
          </TouchableOpacity>
        </View>
      );
    }

    return (
      <View style={{ flex:1, backgroundColor:'#F4F4F4' }}>
        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: insets.bottom + 40 }}>
          {/* Header Image */}
          {selected.image_url ? (
            <Image source={{ uri: selected.image_url }} style={styles.heroImg} resizeMode="cover" />
          ) : (
            <LinearGradient colors={['#064E3B','#10B981']} style={styles.heroPlaceholder}>
              <Ionicons name="restaurant" size={64} color="rgba(255,255,255,0.4)" />
            </LinearGradient>
          )}

          {/* Geri Butonu */}
          <TouchableOpacity
            style={[styles.heroBackBtn, { top: insets.top + 12 }]}
            onPress={() => { setSelected(null); setTab('popular'); }}
          >
            <Ionicons name="arrow-back" size={20} color="#fff" />
          </TouchableOpacity>

          <View style={styles.detailBody}>
            {/* Başlık */}
            <Text style={styles.detailTitle}>{selected.recipe_name}</Text>

            {/* Tags */}
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom:16 }}>
              {selected.recipe_categories.filter(Boolean).map((c) => (
                <View key={c} style={styles.catChip}>
                  <Text style={styles.catChipText}>{c}</Text>
                </View>
              ))}
            </ScrollView>

            {/* Süre/Kişi */}
            <View style={styles.metaBarRow}>
              {selected.preparation_time_min > 0 && (
                <View style={styles.metaBarItem}>
                  <Ionicons name="time-outline" size={20} color="#10B981" />
                  <Text style={styles.metaBarLabel}>Hazırlık</Text>
                  <Text style={styles.metaBarValue}>{selected.preparation_time_min} dk</Text>
                </View>
              )}
              {selected.cooking_time_min > 0 && (
                <View style={styles.metaBarItem}>
                  <Ionicons name="flame-outline" size={20} color="#EF4444" />
                  <Text style={styles.metaBarLabel}>Pişirme</Text>
                  <Text style={styles.metaBarValue}>{selected.cooking_time_min} dk</Text>
                </View>
              )}
              <View style={styles.metaBarItem}>
                <Ionicons name="people-outline" size={20} color="#6B7280" />
                <Text style={styles.metaBarLabel}>Porsiyon</Text>
                <Text style={styles.metaBarValue}>{selected.number_of_servings}</Text>
              </View>
            </View>

            {/* Besin Değerleri (porsiyon başına) */}
            <View style={styles.sectionCard}>
              <Text style={styles.sectionTitle}>🍽️ Porsiyon Başına Besin Değerleri</Text>
              <View style={styles.nutritionGrid}>
                {[
                  { label:'Kalori',      val:`${Math.round(selected.serving_nutrition.calories)}`, unit:'kcal', color:'#6B7280' },
                  { label:'Karbonhidrat',val:`${selected.serving_nutrition.carbs.toFixed(1)}`,     unit:'g',    color:'#F59E0B' },
                  { label:'Protein',     val:`${selected.serving_nutrition.protein.toFixed(1)}`,   unit:'g',    color:'#10B981' },
                  { label:'Yağ',         val:`${selected.serving_nutrition.fat.toFixed(1)}`,        unit:'g',    color:'#EF4444' },
                  { label:'Lif',         val:`${selected.serving_nutrition.fiber.toFixed(1)}`,     unit:'g',    color:'#8B5CF6' },
                  { label:'Şeker',       val:`${selected.serving_nutrition.sugar.toFixed(1)}`,     unit:'g',    color:'#F59E0B' },
                ].map((n) => (
                  <View key={n.label} style={styles.nutritionItem}>
                    <Text style={[styles.nutritionValue, { color: n.color }]}>{n.val}<Text style={styles.nutritionUnit}>{n.unit}</Text></Text>
                    <Text style={styles.nutritionLabel}>{n.label}</Text>
                  </View>
                ))}
              </View>
            </View>

            {/* Malzemeler */}
            {selected.ingredients.length > 0 && (
              <View style={styles.sectionCard}>
                <Text style={styles.sectionTitle}>🛒 Malzemeler</Text>
                {selected.ingredients.map((ing, i) => (
                  <View key={i} style={styles.ingRow}>
                    <View style={styles.ingDot} />
                    <Text style={styles.ingText}>{ing.ingredient_description}</Text>
                  </View>
                ))}
              </View>
            )}

            {/* Açıklama */}
            {selected.recipe_description.length > 0 && (
              <View style={styles.sectionCard}>
                <Text style={styles.sectionTitle}>📖 Hakkında</Text>
                <Text style={styles.descText}>{selected.recipe_description}</Text>
              </View>
            )}

            {/* Tam Tarife Git */}
            {selected.recipe_url.length > 0 && (
              <TouchableOpacity
                style={styles.externalBtn}
                onPress={() => Linking.openURL(selected.recipe_url)}
              >
                <Ionicons name="open-outline" size={18} color="#fff" />
                <Text style={styles.externalBtnText}>FatSecret'ta Tam Tarifi Gör</Text>
              </TouchableOpacity>
            )}
          </View>
        </ScrollView>
      </View>
    );
  }

  // ── Liste Görünümü ─────────────────────────────────────────
  return (
    <View style={{ flex:1, backgroundColor:'#F4F4F4' }}>
      {/* Header */}
      <LinearGradient
        colors={['#064E3B','#10B981']}
        style={{ paddingTop: insets.top + 20, paddingBottom: 24, paddingHorizontal: 24 }}
      >
        <View style={styles.headerRow}>
          <TouchableOpacity onPress={() => nav.goBack()}>
            <Ionicons name="arrow-back" size={24} color="#fff" />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>🥗 Tarifler</Text>
          <View style={{ width:24 }} />
        </View>

        <View style={styles.searchBar}>
          <Ionicons name="search" size={20} color={query ? '#10B981' : '#9CA3AF'} />
          <TextInput
            style={styles.searchInput}
            placeholder="Tarif ara (tavuk, çorba, pilav...)"
            placeholderTextColor="#9CA3AF"
            value={query}
            onChangeText={setQuery}
            onSubmitEditing={handleSearch}
            returnKeyType="search"
          />
          {query.length > 0 && (
            <TouchableOpacity onPress={() => { setQuery(''); setTab('popular'); }}>
              <Ionicons name="close-circle" size={20} color="#9CA3AF" />
            </TouchableOpacity>
          )}
        </View>

        <View style={styles.tabRow}>
          {(['popular','search'] as TabKey[]).map((t) => (
            <TouchableOpacity
              key={t}
              onPress={() => { setTab(t); if (t==='search') handleSearch(); }}
              style={[styles.tabBtn, tab===t && styles.tabBtnActive]}
            >
              <Text style={[styles.tabBtnText, tab===t && styles.tabBtnTextActive]}>
                {t === 'popular' ? '⭐ Popüler' : '🔍 Arama'}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </LinearGradient>

      {/* Liste */}
      {isLoading ? (
        <View style={styles.centered}>
          <ActivityIndicator size="large" color="#10B981" />
          <Text style={styles.loadingText}>Tarifler yükleniyor...</Text>
        </View>
      ) : (
        <FlatList
          data={recipes}
          keyExtractor={(item) => item.recipe_id}
          renderItem={({ item }) => <RecipeCard item={item} />}
          numColumns={2}
          contentContainerStyle={{ padding:16, gap:12 }}
          columnWrapperStyle={{ gap:12 }}
          showsVerticalScrollIndicator={false}
          ListEmptyComponent={
            <View style={styles.centered}>
              <Ionicons name="restaurant-outline" size={56} color="#D1FAE5" />
              <Text style={styles.emptyText}>Tarif bulunamadı</Text>
            </View>
          }
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  centered:      { flex:1, alignItems:'center', justifyContent:'center', minHeight:200 },
  loadingText:   { marginTop:12, fontSize:16, color:'#6B7280', fontWeight:'600' },
  emptyText:     { marginTop:12, fontSize:18, fontWeight:'700', color:'#6B7280' },
  backBtnAlt:    { marginTop:16, padding:12 },

  headerRow:     { flexDirection:'row', alignItems:'center', justifyContent:'space-between', marginBottom:16 },
  headerTitle:   { fontSize:22, fontWeight:'900', color:'#fff' },

  searchBar:     { flexDirection:'row', alignItems:'center', backgroundColor:'#fff', borderRadius:18, paddingHorizontal:16, minHeight:50, gap:10, marginBottom:14 },
  searchInput:   { flex:1, fontSize:15, color:'#1A1A1A' },

  tabRow:        { flexDirection:'row', gap:10 },
  tabBtn:        { paddingHorizontal:18, paddingVertical:8, borderRadius:14, backgroundColor:'rgba(255,255,255,0.15)' },
  tabBtnActive:  { backgroundColor:'#fff' },
  tabBtnText:    { fontSize:13, fontWeight:'700', color:'rgba(255,255,255,0.8)' },
  tabBtnTextActive:{ color:'#10B981' },

  card:          { flex:1, backgroundColor:'#fff', borderRadius:20, overflow:'hidden', shadowColor:'#000', shadowOffset:{width:0,height:4}, shadowOpacity:0.06, shadowRadius:10, elevation:3 },
  cardImg:       { width:'100%', height:130 },
  cardImgPlaceholder: { backgroundColor:'#1F2937', alignItems:'center', justifyContent:'center' },
  cardBody:      { padding:12 },
  cardTitle:     { fontSize:14, fontWeight:'800', color:'#1A1A1A', marginBottom:6, lineHeight:20 },

  ratingRow:     { flexDirection:'row', alignItems:'center', gap:2, marginBottom:6 },
  ratingText:    { fontSize:11, color:'#F59E0B', fontWeight:'700', marginLeft:4 },

  metaRow:       { flexDirection:'row', gap:6, marginBottom:8, flexWrap:'wrap' },
  metaChip:      { flexDirection:'row', alignItems:'center', gap:3, backgroundColor:'#F3F4F6', borderRadius:8, paddingHorizontal:8, paddingVertical:4 },
  metaText:      { fontSize:11, color:'#6B7280', fontWeight:'600' },

  miniMacro:     { flexDirection:'row', alignItems:'center', gap:4 },
  miniMacroText: { fontSize:11, fontWeight:'700' },
  miniDot:       { fontSize:11, color:'#D1D5DB' },

  // Detail
  heroImg:           { width:'100%', height:260 },
  heroPlaceholder:   { width:'100%', height:260, alignItems:'center', justifyContent:'center' },
  heroBackBtn:       { position:'absolute', left:20, width:40, height:40, borderRadius:20, backgroundColor:'rgba(0,0,0,0.5)', alignItems:'center', justifyContent:'center' },
  detailBody:        { padding:20 },
  detailTitle:       { fontSize:28, fontWeight:'900', color:'#1A1A1A', marginBottom:12, lineHeight:34 },
  catChip:           { backgroundColor:'#D1FAE5', borderRadius:12, paddingHorizontal:14, paddingVertical:6, marginRight:8 },
  catChipText:       { fontSize:12, fontWeight:'700', color:'#065F46' },
  metaBarRow:        { flexDirection:'row', backgroundColor:'#fff', borderRadius:20, padding:16, marginBottom:16, gap:8 },
  metaBarItem:       { flex:1, alignItems:'center', gap:4 },
  metaBarLabel:      { fontSize:11, color:'#9CA3AF', fontWeight:'600' },
  metaBarValue:      { fontSize:16, fontWeight:'900', color:'#1A1A1A' },
  sectionCard:       { backgroundColor:'#fff', borderRadius:20, padding:18, marginBottom:16 },
  sectionTitle:      { fontSize:16, fontWeight:'800', color:'#1A1A1A', marginBottom:14 },
  nutritionGrid:     { flexDirection:'row', flexWrap:'wrap', gap:12 },
  nutritionItem:     { width:'30%', alignItems:'center' },
  nutritionValue:    { fontSize:18, fontWeight:'900' },
  nutritionUnit:     { fontSize:11, fontWeight:'600' },
  nutritionLabel:    { fontSize:11, color:'#9CA3AF', marginTop:2, fontWeight:'600' },
  ingRow:            { flexDirection:'row', alignItems:'flex-start', gap:10, marginBottom:10 },
  ingDot:            { width:6, height:6, borderRadius:3, backgroundColor:'#10B981', marginTop:6 },
  ingText:           { flex:1, fontSize:14, color:'#374151', lineHeight:20 },
  descText:          { fontSize:14, color:'#6B7280', lineHeight:22 },
  externalBtn:       { flexDirection:'row', alignItems:'center', justifyContent:'center', gap:8, backgroundColor:'#10B981', borderRadius:18, paddingVertical:16 },
  externalBtnText:   { fontSize:15, fontWeight:'800', color:'#fff' },
});
