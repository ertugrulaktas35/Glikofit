// ============================================================
// 📐 Tasarım Sabitleri — Turkuaz & Nane Yeşili Tema
// ============================================================
// Baskın: Koyu Turkuaz (#008A79)
// Aksan:  Açık Nane (#F2FAF9)
// Zemin:  Nötr Gri (#F4F4F4)
// Kart:   Saf Beyaz (#FFFFFF)
// Font:   Urbanist / Poppins tarzı sans-serif
// ============================================================

export const COLORS = {
  // ── Ana Marka Renkleri ─────────────────────────────────────
  primary:       '#008A79',  // Koyu canlı turkuaz — başlık & birincil buton
  primaryDark:   '#006B5E',  // Daha koyu turkuaz — basılı durum
  primaryLight:  '#00A68E',  // Parlak turkuaz — hover/aktif
  accent:        '#F2FAF9',  // Açık nane yeşili — vurgu arka planı
  accentMedium:  '#E0F2F0',  // Orta nane — seçili chip/badge

  // ── Trafik Lambası ─────────────────────────────────────────
  trafficGreen:      '#10B981',
  trafficGreenBg:    '#ECFDF5',
  trafficGreenLight: '#D1FAE5',
  trafficYellow:     '#F59E0B',
  trafficYellowBg:   '#FFFBEB',
  trafficYellowLight:'#FEF3C7',
  trafficRed:        '#F43F5E',
  trafficRedBg:      '#FFF1F2',
  trafficRedLight:   '#FFE4E6',

  // ── Yüzey & Arka Plan ─────────────────────────────────────
  background:  '#F4F4F4',   // Ana arka plan — nötr gri
  card:        '#FFFFFF',   // Kart arka planı — saf beyaz
  border:      '#E8E8E8',   // Kart kenarları
  borderLight: '#F0F0F0',   // Hafif ayırıcı

  // ── Metin ──────────────────────────────────────────────────
  textPrimary:   '#212121',   // Başlık — koyu gri
  textSecondary: '#6B6B6B',   // Gövde metni
  textMuted:     '#A0A0A0',   // Placeholder & ipucu metni
  textOnPrimary: '#FFFFFF',   // Turkuaz zemin üzerinde beyaz metin

  // ── Premium ────────────────────────────────────────────────
  premiumGold:      '#F59E0B',
  premiumGoldLight: '#FEF3C7',

  // ── Temel ──────────────────────────────────────────────────
  white: '#FFFFFF',
  black: '#000000',
} as const;

export const SPACING = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  '2xl': 24,
  '3xl': 32,
  '4xl': 40,
  '5xl': 48,
  touch: 48,
  touchLg: 56,
} as const;

export const FONT_SIZE = {
  xs: 14,
  sm: 16,
  base: 18,
  lg: 20,
  xl: 24,
  '2xl': 28,
  '3xl': 32,
  '4xl': 36,
} as const;

export const BORDER_RADIUS = {
  sm: 8,
  md: 12,
  lg: 16,   // Standart kart/buton/input köşe
  xl: 20,
  pill: 9999,
} as const;

/**
 * Trafik lambası rengine göre renk seti döner
 */
export function getTrafficLightColors(level: 'green' | 'yellow' | 'red') {
  const map = {
    green: {
      main: COLORS.trafficGreen,
      bg: COLORS.trafficGreenBg,
      light: COLORS.trafficGreenLight,
      label: 'Güvenli',
      emoji: '🟢',
    },
    yellow: {
      main: COLORS.trafficYellow,
      bg: COLORS.trafficYellowBg,
      light: COLORS.trafficYellowLight,
      label: 'Dikkat',
      emoji: '🟡',
    },
    red: {
      main: COLORS.trafficRed,
      bg: COLORS.trafficRedBg,
      light: COLORS.trafficRedLight,
      label: 'Riskli',
      emoji: '🔴',
    },
  };
  return map[level];
}
