import { create } from 'zustand';

// ============================================================
// 📦 Zustand Store — Uygulama Durum Yönetimi
// ============================================================

// ── Tip Tanımları ────────────────────────────────────────────

/** Trafik Lambası risk seviyesi */
export type TrafficLight = 'green' | 'yellow' | 'red';

/** Besin verisi */
export interface FoodItem {
  id: string;
  name: string;
  /** 100g başına Glisemik İndeks */
  glycemicIndex: number;
  /** 100g başına karbonhidrat (gram) */
  carbsPer100g: number;
  /** Trafik lambası rengi */
  trafficLight: TrafficLight;
  /** Porsiyon miktarı (gram) */
  servingSize: number;
  /** Besin kategorisi */
  category: string;
  /** Besin açıklaması */
  description?: string;
}

export type MealType = 'kahvalti' | 'ogle' | 'aksam' | 'ara';
export type MealCategory = 'tabak' | 'icecek' | 'meyve' | 'diger';

/** Günlük kayıt */
export interface DailyLogEntry {
  id: string;
  foodId: string;
  foodName: string;
  /** Tüketilen porsiyon (gram) */
  portion: number;
  /** Seçili olan formata göre metin (Örn: 2 Dilim veya 150g) */
  portionText?: string;
  /** Hesaplanan Glisemik Yük */
  glycemicLoad: number;
  /** Trafik lambası rengi */
  trafficLight: TrafficLight;
  /** Kayıt zamanı */
  timestamp: Date;
  /** Öğün tipi */
  mealType?: MealType;
  /** Öğün kategorisi */
  mealCategory?: MealCategory;
}

/** Koç önerisi (Premium) */
export interface CoachSuggestion {
  riskyFood: FoodItem;
  suggestedPairings: FoodItem[];
  explanation: string;
}

// ── Store Arayüzü ────────────────────────────────────────────

interface AppState {
  // ── Kullanıcı Durumu ─────────────────────────────
  isPremium: boolean;
  setIsPremium: (value: boolean) => void;

  // ── Arama ve Besin Seçimi ────────────────────────
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  selectedFood: FoodItem | null;
  setSelectedFood: (food: FoodItem | null) => void;

  // ── Porsiyon ve Glisemik Yük ─────────────────────
  currentPortion: number;
  setCurrentPortion: (portion: number) => void;
  /** Anlık Glisemik Yük hesaplaması */
  calculateGlycemicLoad: () => number;

  // ── Günlük Kayıtlar ─────────────────────────────
  dailyLog: DailyLogEntry[];
  addToDailyLog: (entry: Omit<DailyLogEntry, 'id' | 'timestamp'>) => void;
  clearDailyLog: () => void;

  // ── Koç Önerileri (Premium) ──────────────────────
  coachSuggestion: CoachSuggestion | null;
  setCoachSuggestion: (suggestion: CoachSuggestion | null) => void;

  // ── Yükleme Durumu ──────────────────────────────
  isLoading: boolean;
  setIsLoading: (value: boolean) => void;
}

// ── Store Oluşturma ──────────────────────────────────────────

export const useAppStore = create<AppState>((set, get) => ({
  // ── Kullanıcı Durumu ─────────────────────────────
  isPremium: false,
  setIsPremium: (value) => set({ isPremium: value }),

  // ── Arama ve Besin Seçimi ────────────────────────
  searchQuery: '',
  setSearchQuery: (query) => set({ searchQuery: query }),
  selectedFood: null,
  setSelectedFood: (food) =>
    set({
      selectedFood: food,
      currentPortion: food ? food.servingSize : 0,
    }),

  // ── Porsiyon ve Glisemik Yük ─────────────────────
  currentPortion: 0,
  setCurrentPortion: (portion) => set({ currentPortion: portion }),

  /**
   * Glisemik Yük Formülü:
   * GL = (GI × Karbonhidrat miktarı porsiyon başına) / 100
   *
   * Karbonhidrat miktarı porsiyon başına:
   * = (carbsPer100g / 100) × currentPortion
   *
   * Sonuç:
   * GL = (GI × carbsPer100g × portion) / 10000
   */
  calculateGlycemicLoad: () => {
    const { selectedFood, currentPortion } = get();
    if (!selectedFood || currentPortion <= 0) return 0;

    const gl =
      (selectedFood.glycemicIndex *
        selectedFood.carbsPer100g *
        currentPortion) /
      10000;

    return Math.round(gl * 10) / 10; // 1 ondalık basamağa yuvarla
  },

  // ── Günlük Kayıtlar ─────────────────────────────
  dailyLog: [],
  addToDailyLog: (entry) =>
    set((state) => ({
      dailyLog: [
        ...state.dailyLog,
        {
          ...entry,
          id: `${Date.now()}-${Math.random().toString(36).substring(7)}`,
          timestamp: new Date(),
        },
      ],
    })),
  clearDailyLog: () => set({ dailyLog: [] }),

  // ── Koç Önerileri (Premium) ──────────────────────
  coachSuggestion: null,
  setCoachSuggestion: (suggestion) => set({ coachSuggestion: suggestion }),

  // ── Yükleme Durumu ──────────────────────────────
  isLoading: false,
  setIsLoading: (value) => set({ isLoading: value }),
}));

export default useAppStore;
