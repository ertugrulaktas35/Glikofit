import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import type {
  DiabetesType,
  ActivityLevel,
  Gender,
  UserHealthProfile,
} from '../utils/healthCalculations';
import {
  calculateBMI,
  calculateDailyCarbLimit,
  getPersonalizedGlThresholds,
} from '../utils/healthCalculations';

// ============================================================
// 👤 Kullanıcı Profil Store — Kişisel Sağlık Verileri
// ============================================================

export interface UserProfileState {
  // ── Profil Verisi ──────────────────────────────────────────
  isOnboarded: boolean;
  profile: UserHealthProfile | null;

  // ── Hesaplanmış Değerler ───────────────────────────────────
  bmi: number;
  dailyCarbLimit: number;
  glThresholds: { yellowThreshold: number; redThreshold: number };

  // ── Aksiyonlar ─────────────────────────────────────────────
  setProfile: (profile: UserHealthProfile) => void;
  updateProfile: (updates: Partial<UserHealthProfile>) => void;
  completeOnboarding: (profile: UserHealthProfile) => void;
  resetProfile: () => void;
}

const DEFAULT_GL_THRESHOLDS = { yellowThreshold: 10, redThreshold: 20 };

export const useUserStore = create<UserProfileState>()(
  persist(
    (set, get) => ({
      isOnboarded: false,
      profile: null,
      bmi: 0,
      dailyCarbLimit: 200,
      glThresholds: DEFAULT_GL_THRESHOLDS,

      setProfile: (profile) => {
        const bmi = calculateBMI(profile.weightKg, profile.heightCm);
        const dailyCarbLimit = calculateDailyCarbLimit(profile);
        const glThresholds = getPersonalizedGlThresholds(
          profile.diabetesType,
          profile.hba1c
        );
        set({ profile, bmi, dailyCarbLimit, glThresholds });
      },

      updateProfile: (updates) => {
        const current = get().profile;
        if (!current) return;
        const updated = { ...current, ...updates };
        const bmi = calculateBMI(updated.weightKg, updated.heightCm);
        const dailyCarbLimit = calculateDailyCarbLimit(updated);
        const glThresholds = getPersonalizedGlThresholds(
          updated.diabetesType,
          updated.hba1c
        );
        set({ profile: updated, bmi, dailyCarbLimit, glThresholds });
      },

      completeOnboarding: (profile) => {
        const bmi = calculateBMI(profile.weightKg, profile.heightCm);
        const dailyCarbLimit = calculateDailyCarbLimit(profile);
        const glThresholds = getPersonalizedGlThresholds(
          profile.diabetesType,
          profile.hba1c
        );
        set({
          isOnboarded: true,
          profile,
          bmi,
          dailyCarbLimit,
          glThresholds,
        });
      },

      resetProfile: () => {
        set({
          isOnboarded: false,
          profile: null,
          bmi: 0,
          dailyCarbLimit: 200,
          glThresholds: DEFAULT_GL_THRESHOLDS,
        });
      },
    }),
    {
      name: 'glikofit-user-profile',
      storage: createJSONStorage(() => AsyncStorage),
    }
  )
);

export default useUserStore;
