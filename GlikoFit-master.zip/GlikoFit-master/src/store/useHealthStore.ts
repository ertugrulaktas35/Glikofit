import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { supabase } from '../lib/supabase';
import type {
  MoodLog, MoodLogInsert,
  SleepLog, SleepLogInsert,
  WaterLog, WaterLogInsert,
  CaffeineLog, CaffeineLogInsert,
  ExerciseLog, ExerciseLogInsert,
  ConsumptionLogWithFood,
} from '../types/database';
import {
  calculateHealthScore,
  DEFAULT_METRICS,
  type DailyMetrics,
  type HealthScoreResult,
} from '../utils/healthScore';
import type { DiabetesType } from '../utils/healthCalculations';

// ============================================================
// 🏥 Sağlık Takip Store — GlikoFit v2
// ============================================================
// Mood, uyku, su, kafein verilerini yönetir ve
// gerçek zamanlı Health Score hesaplar.
// ============================================================

export interface HealthState {
  // ── Bugünkü Veriler ────────────────────────────────────────
  todayMoodEntries: MoodLog[];
  todaySleepLog: SleepLog | null;
  todayWaterMl: number;
  todayWaterEntries: WaterLog[];
  todayCaffeineMg: number;
  todayCaffeineEntries: CaffeineLog[];
  todayExerciseLogs: ExerciseLog[];
  totalCaloriesBurned: number;

  // ── Hesaplanmış Skor ───────────────────────────────────────
  healthScore: HealthScoreResult | null;
  lastScoreDate: string | null;

  // ── Yükleme Durumu ─────────────────────────────────────────
  isLoading: boolean;

  // ── Aksiyonlar ─────────────────────────────────────────────

  // Su
  addWater: (userId: string, amountMl: number) => Promise<void>;
  
  // Kafein
  addCaffeine: (userId: string, entry: Omit<CaffeineLogInsert, 'user_id'>) => Promise<void>;

  // Mood
  logMood: (entry: MoodLogInsert) => Promise<void>;

  // Uyku
  logSleep: (entry: SleepLogInsert) => Promise<void>;

  // Egzersiz
  addExercise: (userId: string, entry: ExerciseLogInsert) => Promise<void>;

  // Günlük verileri yükle
  loadTodayData: (userId: string) => Promise<void>;

  // Health Score yeniden hesapla
  recalculateHealthScore: (
    consumptionEntries: ConsumptionLogWithFood[],
    dailyCarbLimit: number,
    diabetesType: DiabetesType,
    bmi: number,
    weightKg: number,
  ) => void;

  // Reset
  resetHealth: () => void;
}

// ── Yardımcı: Bugünün tarihini al ───────────────────────────

function getTodayStr(): string {
  return new Date().toISOString().split('T')[0]; // YYYY-MM-DD
}

// ── Store ────────────────────────────────────────────────────

export const useHealthStore = create<HealthState>()(
  persist(
    (set, get) => ({
      // Başlangıç değerleri
      todayMoodEntries: [],
      todaySleepLog: null,
      todayWaterMl: 0,
      todayWaterEntries: [],
      todayCaffeineMg: 0,
      todayCaffeineEntries: [],
      todayExerciseLogs: [],
      totalCaloriesBurned: 0,
      healthScore: null,
      lastScoreDate: null,
      isLoading: false,

      // ── Su Ekleme ─────────────────────────────────────────
      addWater: async (userId, amountMl) => {
        const today = getTodayStr();

        const { data, error } = await supabase
          .from('water_logs')
          .insert({ user_id: userId, amount_ml: amountMl, log_date: today })
          .select()
          .single();

        if (!error && data) {
          set((state) => ({
            todayWaterMl: state.todayWaterMl + amountMl,
            todayWaterEntries: [...state.todayWaterEntries, data as WaterLog],
          }));
        }
      },

      // ── Kafein Ekleme ─────────────────────────────────────
      addCaffeine: async (userId, entry) => {
        const today = getTodayStr();

        const { data, error } = await supabase
          .from('caffeine_logs')
          .insert({
            user_id: userId,
            beverage_type: entry.beverage_type,
            caffeine_mg: entry.caffeine_mg,
            volume_ml: entry.volume_ml,
            log_date: today,
          })
          .select()
          .single();

        if (!error && data) {
          set((state) => ({
            todayCaffeineMg: state.todayCaffeineMg + entry.caffeine_mg,
            todayCaffeineEntries: [...state.todayCaffeineEntries, data as CaffeineLog],
          }));
        }
      },

      // ── Mood Kayıt ────────────────────────────────────────
      logMood: async (entry) => {
        const { data, error } = await supabase
          .from('mood_logs')
          .insert(entry)
          .select()
          .single();

        if (!error && data) {
          set((state) => ({
            todayMoodEntries: [...state.todayMoodEntries, data as MoodLog],
          }));
        }
      },

      // ── Uyku Kayıt ────────────────────────────────────────
      logSleep: async (entry) => {
        const { data, error } = await supabase
          .from('sleep_logs')
          .insert(entry)
          .select()
          .single();

        if (!error && data) {
          set({ todaySleepLog: data as SleepLog });
        }
      },

      // ── Egzersiz Kayıt ────────────────────────────────────
      addExercise: async (userId, entry) => {
        const { data, error } = await supabase
          .from('exercise_logs')
          .insert(entry)
          .select()
          .single();

        if (!error && data) {
          const log = data as ExerciseLog;
          set((state) => ({
            todayExerciseLogs: [...state.todayExerciseLogs, log],
            totalCaloriesBurned: state.totalCaloriesBurned + log.calories_burned,
          }));
        }
      },

      // ── Günlük Verileri Yükle ──────────────────────────────
      loadTodayData: async (userId) => {
        set({ isLoading: true });
        const today = getTodayStr();

        try {
          // Paralel çağrılar (5 tablo)
          const [waterRes, caffeineRes, moodRes, sleepRes, exerciseRes] = await Promise.all([
            supabase
              .from('water_logs')
              .select('*')
              .eq('user_id', userId)
              .eq('log_date', today),
            supabase
              .from('caffeine_logs')
              .select('*')
              .eq('user_id', userId)
              .eq('log_date', today),
            supabase
              .from('mood_logs')
              .select('*')
              .eq('user_id', userId)
              .gte('recorded_at', `${today}T00:00:00`)
              .lte('recorded_at', `${today}T23:59:59`),
            supabase
              .from('sleep_logs')
              .select('*')
              .eq('user_id', userId)
              .eq('sleep_date', today)
              .maybeSingle(),
            supabase
              .from('exercise_logs')
              .select('*')
              .eq('user_id', userId)
              .eq('log_date', today),
          ]);

          const waterEntries    = (waterRes.data || []) as WaterLog[];
          const caffeineEntries = (caffeineRes.data || []) as CaffeineLog[];
          const moodEntries     = (moodRes.data || []) as MoodLog[];
          const sleepLog        = sleepRes.data as SleepLog | null;
          const exerciseLogs    = (exerciseRes.data || []) as ExerciseLog[];

          set({
            todayWaterEntries:    waterEntries,
            todayWaterMl:         waterEntries.reduce((sum, w) => sum + w.amount_ml, 0),
            todayCaffeineEntries: caffeineEntries,
            todayCaffeineMg:      caffeineEntries.reduce((sum, c) => sum + c.caffeine_mg, 0),
            todayMoodEntries:     moodEntries,
            todaySleepLog:        sleepLog,
            todayExerciseLogs:    exerciseLogs,
            totalCaloriesBurned:  exerciseLogs.reduce((sum, e) => sum + e.calories_burned, 0),
            isLoading: false,
          });
        } catch (err) {
          console.error('loadTodayData error:', err);
          set({ isLoading: false });
        }
      },

      // ── Health Score Hesapla ────────────────────────────────
      recalculateHealthScore: (
        consumptionEntries,
        dailyCarbLimit,
        diabetesType,
        bmi,
        weightKg,
      ) => {
        const state = get();

        // Beslenme metrikleri
        const totalFoods = consumptionEntries.length;
        const avgGI = totalFoods > 0
          ? consumptionEntries.reduce((s, e) => s + e.food.gi_value, 0) / totalFoods
          : DEFAULT_METRICS.avgGI;
        const totalGL = consumptionEntries.reduce((s, e) => s + e.calculated_gl, 0);
        const totalCarbs = consumptionEntries.reduce(
          (s, e) => s + (e.food.carbs_per_100g * e.portion_grams) / 100,
          0,
        );
        const redCount = consumptionEntries.filter(
          (e) => e.food.color_code === 'RED',
        ).length;
        const greenCount = consumptionEntries.filter(
          (e) => e.food.color_code === 'GREEN',
        ).length;
        const greenRatio = totalFoods > 0 ? greenCount / totalFoods : 0.5;

        // Mood metrikleri
        const moodEntries = state.todayMoodEntries;
        const avgMood = moodEntries.length > 0
          ? moodEntries.reduce((s, e) => s + e.mood_score, 0) / moodEntries.length
          : DEFAULT_METRICS.avgMood;
        const avgStress = moodEntries.length > 0
          ? moodEntries.reduce((s, e) => s + (e.stress_level ?? 5), 0) / moodEntries.length
          : DEFAULT_METRICS.avgStress;
        const avgEnergy = moodEntries.length > 0
          ? moodEntries.reduce((s, e) => s + (e.energy_level ?? 5), 0) / moodEntries.length
          : DEFAULT_METRICS.avgEnergy;

        // Uyku metrikleri
        const sleepDuration = state.todaySleepLog?.duration_minutes
          ?? DEFAULT_METRICS.sleepDurationMinutes;
        const sleepQuality = state.todaySleepLog?.quality_score
          ?? DEFAULT_METRICS.sleepQuality;

        // Hidrasyon
        const waterTarget = weightKg * 30; // 30ml per kg

        const metrics: DailyMetrics = {
          avgGI,
          totalGL,
          carbRatio: dailyCarbLimit > 0 ? totalCarbs / dailyCarbLimit : 0,
          redFoodCount: redCount,
          greenFoodRatio: greenRatio,
          avgMood,
          avgStress,
          avgEnergy,
          sleepDurationMinutes: sleepDuration,
          sleepQuality: sleepQuality,
          waterMl: state.todayWaterMl,
          waterTarget,
          caffeineMg: state.todayCaffeineMg,
          diabetesType,
          bmi,
        };

        const result = calculateHealthScore(metrics);

        set({
          healthScore: result,
          lastScoreDate: getTodayStr(),
        });
      },

      // ── Reset ──────────────────────────────────────────────
      resetHealth: () => {
        set({
          todayMoodEntries: [],
          todaySleepLog: null,
          todayWaterMl: 0,
          todayWaterEntries: [],
          todayCaffeineMg: 0,
          todayCaffeineEntries: [],
          todayExerciseLogs: [],
          totalCaloriesBurned: 0,
          healthScore: null,
          lastScoreDate: null,
        });
      },
    }),
    {
      name: 'glikofit-health',
      storage: createJSONStorage(() => AsyncStorage),
      // Skor ve gün içi verileri persist et
      partialize: (state) => ({
        healthScore: state.healthScore,
        lastScoreDate: state.lastScoreDate,
        todayWaterMl: state.todayWaterMl,
        todayCaffeineMg: state.todayCaffeineMg,
        totalCaloriesBurned: state.totalCaloriesBurned,
      }),
    },
  ),
);

export default useHealthStore;
