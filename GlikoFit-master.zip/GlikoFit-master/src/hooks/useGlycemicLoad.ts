import { useMemo } from 'react';

export type GlStatus = 'green' | 'yellow' | 'red';

export interface UseGlycemicLoadResult {
  instantCarbs: number;
  glValue: number;
  glStatus: GlStatus;
  glColor: string;
}

export function useGlycemicLoad(
  giValue: number,
  carbs100: number | null,
  portion: number
): UseGlycemicLoadResult {
  return useMemo(() => {
    let carbs = 0;
    let gl = 0;
    
    if (carbs100 !== null && carbs100 > 0) {
      carbs = (carbs100 / 100) * portion;
      gl = (giValue * carbs) / 100;
    }
    
    const roundedGL = Math.round(gl * 10) / 10;
    const roundedCarbs = Math.round(carbs * 10) / 10;

    let color = '#1DB87A'; // Güvenli (Yeşil)
    let status: GlStatus = 'green';

    if (roundedGL >= 20) {
      color = '#E8453C'; // Kırmızı (Risk)
      status = 'red';
    } else if (roundedGL >= 10) {
      color = '#F5A623'; // Sarı (Dikkat)
      status = 'yellow';
    }

    return { 
      instantCarbs: roundedCarbs, 
      glValue: roundedGL, 
      glStatus: status, 
      glColor: color 
    };
  }, [portion, carbs100, giValue]);
}
