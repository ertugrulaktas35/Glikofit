// ============================================================
// 🧭 Navigasyon Tipleri
// ============================================================

import type { Food } from '../types/database';

// ── Bottom Tab Navigasyonu ───────────────────────────────────
export type BottomTabParamList = {
  Home: undefined;
  Search: undefined;
  DailyLog: undefined;
  Profile: undefined;
};

// ── Stack Navigasyonu ────────────────────────────────────────
export type RootStackParamList = {
  Login: undefined;
  Onboarding: undefined;
  MainTabs: undefined;
  FoodDetail: { food: Food };
  Premium: undefined;
  Coach: { foodId: number };
  Charts: undefined;
};

// Type-safe navigation için yardımcı
declare global {
  namespace ReactNavigation {
    interface RootParamList extends RootStackParamList {}
  }
}
