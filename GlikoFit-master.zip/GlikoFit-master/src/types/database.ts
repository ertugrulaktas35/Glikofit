// ============================================================
// 🗄️ Veritabanı TypeScript Tipleri — GlikoFit v2
// ============================================================
// Supabase şemasına birebir uyumlu tip tanımlamaları.
// supabase.from('table').select() sorgularında kullanılır.
// ============================================================

// ── Ortak Enumlar ────────────────────────────────────────────

/** Trafik Lambası Renk Kodu */
export type ColorCode = 'GREEN' | 'YELLOW' | 'RED';

/** Veri kaynağı */
export type FoodSource = 'manual' | 'fatsecret' | 'gemini_vision' | 'usda';

/** Kullanıcı rolü */
export type UserRole = 'client' | 'dietitian' | 'admin';

/** Diyetisyen-Danışan ilişki durumu */
export type AssignmentStatus = 'pending' | 'active' | 'paused' | 'terminated';

/** Fotoğraf analiz durumu */
export type PhotoAnalysisStatus = 'pending' | 'processing' | 'completed' | 'failed' | 'reviewed';

/** İçecek türü */
export type BeverageType =
  | 'turk_kahvesi' | 'filtre_kahve' | 'espresso'
  | 'siyah_cay' | 'yesil_cay' | 'enerji_icecegi' | 'kola' | 'diger';

/** Mood etiketleri */
export type MoodTag =
  | 'mutlu' | 'kaygili' | 'stresli' | 'sakin'
  | 'sinirli' | 'enerjik' | 'yorgun' | 'odaklanmis';


// ══════════════════════════════════════════════════════════════
// 1. USERS
// ══════════════════════════════════════════════════════════════

/** users tablosundan SELECT ile dönen satır tipi */
export interface User {
  id: string;                 // UUID — auth.users PK
  email: string;
  goal: string;               // Kullanıcı hedefi
  is_premium: boolean;         // Premium üyelik durumu
  role: UserRole;              // Kullanıcı rolü
  created_at: string;          // ISO 8601 timestamp
}

/** users tablosuna INSERT için gerekli alanlar */
export interface UserInsert {
  id: string;                  // auth.uid()
  email: string;
  goal?: string;
  is_premium?: boolean;
  role?: UserRole;
}

/** users tablosunda UPDATE için değiştirilebilir alanlar */
export interface UserUpdate {
  email?: string;
  goal?: string;
  is_premium?: boolean;
  role?: UserRole;
}


// ══════════════════════════════════════════════════════════════
// 2. FOODS
// ══════════════════════════════════════════════════════════════

/** foods tablosundan SELECT ile dönen satır tipi */
export interface Food {
  id: number;                  // BIGINT identity PK
  name: string;                // Besin adı
  category: string;            // Besin kategorisi
  gi_value: number;            // Glisemik İndeks (0-100)
  carbs_per_100g: number;      // 100g başına karbonhidrat (gram)
  protein_per_100g: number;    // 100g başına protein (gram)
  fat_per_100g: number;        // 100g başına yağ (gram)
  calories_per_100g: number;   // 100g başına kalori (kcal)
  fiber_per_100g: number;      // 100g başına lif (gram)
  color_code: ColorCode;       // Trafik lambası rengi
  source: FoodSource;          // Veri kaynağı
  created_at: string;          // ISO 8601 timestamp
  image_url?: string;          // Supabase foods tablosundaki fotoğraf URL'si
}

/** foods tablosuna INSERT için gerekli alanlar */
export interface FoodInsert {
  name: string;
  category?: string;
  gi_value: number;
  carbs_per_100g: number;
  protein_per_100g?: number;
  fat_per_100g?: number;
  calories_per_100g?: number;
  fiber_per_100g?: number;
  color_code: ColorCode;
  source?: FoodSource;
}

/** foods tablosunda UPDATE için değiştirilebilir alanlar */
export interface FoodUpdate {
  name?: string;
  category?: string;
  gi_value?: number;
  carbs_per_100g?: number;
  protein_per_100g?: number;
  fat_per_100g?: number;
  calories_per_100g?: number;
  fiber_per_100g?: number;
  color_code?: ColorCode;
  source?: FoodSource;
}


// ══════════════════════════════════════════════════════════════
// 3. CONSUMPTION_LOGS
// ══════════════════════════════════════════════════════════════

/** consumption_logs tablosundan SELECT ile dönen satır tipi */
export interface ConsumptionLog {
  id: number;                  // BIGINT identity PK
  user_id: string;             // UUID — users FK
  food_id: number;             // BIGINT — foods FK
  portion_grams: number;       // Tüketilen porsiyon (gram)
  calculated_gl: number;       // Hesaplanan Glisemik Yük
  consumed_at: string;         // ISO 8601 timestamp
}

/** consumption_logs tablosuna INSERT için gerekli alanlar */
export interface ConsumptionLogInsert {
  user_id: string;
  food_id: number;
  portion_grams: number;
  calculated_gl: number;
  consumed_at?: string;        // Belirtilmezse now() kullanılır
}

/** consumption_logs tablosunda UPDATE için değiştirilebilir alanlar */
export interface ConsumptionLogUpdate {
  portion_grams?: number;
  calculated_gl?: number;
  consumed_at?: string;
}


// ══════════════════════════════════════════════════════════════
// 4. COACH_PAIRINGS
// ══════════════════════════════════════════════════════════════

/** coach_pairings tablosundan SELECT ile dönen satır tipi */
export interface CoachPairing {
  id: number;                  // BIGINT identity PK
  high_risk_category: string;  // Riskli besin kategorisi
  balancer_category: string;   // Dengeleyici besin kategorisi
  advice_text: string;         // Koç tavsiye metni
  created_at: string;          // ISO 8601 timestamp
}

/** coach_pairings tablosuna INSERT için gerekli alanlar */
export interface CoachPairingInsert {
  high_risk_category: string;
  balancer_category: string;
  advice_text: string;
}


// ══════════════════════════════════════════════════════════════
// 5. USER_HEALTH_PROFILES
// ══════════════════════════════════════════════════════════════

/** user_health_profiles tablosundan SELECT ile dönen satır tipi */
export interface UserHealthProfileRow {
  id: number;
  user_id: string;
  full_name: string;
  birth_year: number;
  gender: 'erkek' | 'kadin';
  height_cm: number;
  weight_kg: number;
  diabetes_type: 'tip1' | 'tip2' | 'prediyabet' | 'gestasyonel' | 'yok';
  hba1c: number | null;
  fasting_glucose: number | null;
  activity_level: 'sedanter' | 'hafif_aktif' | 'aktif' | 'cok_aktif';
  bmi: number;                 // GENERATED ALWAYS — PostgreSQL otomatik hesaplar
  updated_at: string;
  created_at: string;
}

/** user_health_profiles tablosuna INSERT */
export interface UserHealthProfileInsert {
  user_id: string;
  full_name: string;
  birth_year: number;
  gender: 'erkek' | 'kadin';
  height_cm: number;
  weight_kg: number;
  diabetes_type?: string;
  hba1c?: number | null;
  fasting_glucose?: number | null;
  activity_level?: string;
}

/** user_health_profiles tablosunda UPDATE */
export interface UserHealthProfileUpdate {
  full_name?: string;
  birth_year?: number;
  gender?: 'erkek' | 'kadin';
  height_cm?: number;
  weight_kg?: number;
  diabetes_type?: string;
  hba1c?: number | null;
  fasting_glucose?: number | null;
  activity_level?: string;
}


// ══════════════════════════════════════════════════════════════
// 6. MOOD_LOGS
// ══════════════════════════════════════════════════════════════

/** mood_logs tablosundan SELECT ile dönen satır tipi */
export interface MoodLog {
  id: number;
  user_id: string;
  consumption_log_id: number | null;
  mood_score: number;          // 1-10
  stress_level: number | null; // 1-10
  energy_level: number | null; // 1-10
  mood_tags: MoodTag[];
  notes: string | null;
  recorded_at: string;
}

/** mood_logs tablosuna INSERT */
export interface MoodLogInsert {
  user_id: string;
  consumption_log_id?: number | null;
  mood_score: number;
  stress_level?: number | null;
  energy_level?: number | null;
  mood_tags?: MoodTag[];
  notes?: string | null;
  recorded_at?: string;
}

/** mood_logs tablosunda UPDATE */
export interface MoodLogUpdate {
  mood_score?: number;
  stress_level?: number | null;
  energy_level?: number | null;
  mood_tags?: MoodTag[];
  notes?: string | null;
}


// ══════════════════════════════════════════════════════════════
// 7. SLEEP_LOGS
// ══════════════════════════════════════════════════════════════

/** sleep_logs tablosundan SELECT ile dönen satır tipi */
export interface SleepLog {
  id: number;
  user_id: string;
  sleep_date: string;          // YYYY-MM-DD
  bed_time: string;            // ISO 8601 timestamp
  wake_time: string;           // ISO 8601 timestamp
  duration_minutes: number;    // GENERATED ALWAYS
  quality_score: number | null;// 1-10
  interruptions: number;
  notes: string | null;
  created_at: string;
}

/** sleep_logs tablosuna INSERT */
export interface SleepLogInsert {
  user_id: string;
  sleep_date: string;
  bed_time: string;
  wake_time: string;
  quality_score?: number | null;
  interruptions?: number;
  notes?: string | null;
}

/** sleep_logs tablosunda UPDATE */
export interface SleepLogUpdate {
  bed_time?: string;
  wake_time?: string;
  quality_score?: number | null;
  interruptions?: number;
  notes?: string | null;
}


// ══════════════════════════════════════════════════════════════
// 8. WATER_LOGS
// ══════════════════════════════════════════════════════════════

/** water_logs tablosundan SELECT ile dönen satır tipi */
export interface WaterLog {
  id: number;
  user_id: string;
  amount_ml: number;
  log_date: string;
  logged_at: string;
}

/** water_logs tablosuna INSERT */
export interface WaterLogInsert {
  user_id: string;
  amount_ml: number;
  log_date?: string;
}


// ══════════════════════════════════════════════════════════════
// 9. CAFFEINE_LOGS
// ══════════════════════════════════════════════════════════════

/** caffeine_logs tablosundan SELECT ile dönen satır tipi */
export interface CaffeineLog {
  id: number;
  user_id: string;
  beverage_type: BeverageType;
  caffeine_mg: number;
  volume_ml: number | null;
  log_date: string;
  logged_at: string;
}

/** caffeine_logs tablosuna INSERT */
export interface CaffeineLogInsert {
  user_id: string;
  beverage_type: BeverageType;
  caffeine_mg: number;
  volume_ml?: number;
  log_date?: string;
}


// ══════════════════════════════════════════════════════════════
// 10. PHOTO_ANALYSES
// ══════════════════════════════════════════════════════════════

/** Fotoğrafta tespit edilen tek bir besin */
export interface DetectedFoodItem {
  name: string;
  estimated_grams: number;
  confidence: number;          // 0-1
  macros: {
    calories: number;
    carbs: number;
    protein: number;
    fat: number;
    fiber: number;
  };
  gi_value: number | null;
  gi_source: 'local_db' | 'estimated' | 'category_estimate' | null;
}

/** photo_analyses tablosundan SELECT ile dönen satır tipi */
export interface PhotoAnalysis {
  id: number;
  user_id: string;
  image_url: string;
  image_hash: string | null;
  detected_items: DetectedFoodItem[];
  total_calories: number;
  total_carbs: number;
  total_protein: number;
  total_fat: number;
  total_gi_load: number;
  processing_time_ms: number | null;
  model_version: string;
  status: PhotoAnalysisStatus;
  error_message: string | null;
  reviewed_by: string | null;
  review_notes: string | null;
  analyzed_at: string;
}

/** photo_analyses tablosuna INSERT */
export interface PhotoAnalysisInsert {
  user_id: string;
  image_url: string;
  image_hash?: string;
  detected_items: DetectedFoodItem[];
  total_calories?: number;
  total_carbs?: number;
  total_protein?: number;
  total_fat?: number;
  total_gi_load?: number;
  processing_time_ms?: number;
  model_version?: string;
  status?: PhotoAnalysisStatus;
  error_message?: string;
}


// ══════════════════════════════════════════════════════════════
// 11. EXERCISE_LOGS
// ══════════════════════════════════════════════════════════════

export interface ExerciseLog {
  id: number;
  user_id: string;
  exercise_name: string;
  exercise_category: string;
  fatsecret_exercise_id: number | null;
  duration_minutes: number;
  intensity: ExerciseIntensity | null;
  calories_burned: number;
  met_value: number | null;
  log_date: string;
  logged_at: string;
}

export interface ExerciseLogInsert {
  user_id: string;
  exercise_name: string;
  exercise_category?: string;
  fatsecret_exercise_id?: number | null;
  duration_minutes: number;
  intensity?: ExerciseIntensity;
  calories_burned: number;
  met_value?: number | null;
  log_date?: string;
}

// ══════════════════════════════════════════════════════════════
// 12. DIETITIAN_ASSIGNMENTS
// ══════════════════════════════════════════════════════════════

/** dietitian_assignments tablosundan SELECT ile dönen satır tipi */
export interface DietitianAssignment {
  id: number;
  dietitian_id: string;
  client_id: string;
  status: AssignmentStatus;
  assigned_at: string;
  activated_at: string | null;
}

/** dietitian_assignments tablosuna INSERT */
export interface DietitianAssignmentInsert {
  dietitian_id: string;
  client_id: string;
  status?: AssignmentStatus;
}


// ══════════════════════════════════════════════════════════════
// 12. SUPABASE DATABASE TİPLERİ (Genel Şema)
// ══════════════════════════════════════════════════════════════
// supabase-js client'ında generic tip olarak kullanılır:
// const supabase = createClient<Database>(url, key)

export interface Database {
  public: {
    Tables: {
      users: {
        Row: User;
        Insert: UserInsert;
        Update: UserUpdate;
        Relationships: [];
      };
      foods: {
        Row: Food;
        Insert: FoodInsert;
        Update: FoodUpdate;
        Relationships: [];
      };
      consumption_logs: {
        Row: ConsumptionLog;
        Insert: ConsumptionLogInsert;
        Update: ConsumptionLogUpdate;
        Relationships: [
          {
            foreignKeyName: 'consumption_logs_user_id_fkey';
            columns: ['user_id'];
            isOneToOne: false;
            referencedRelation: 'users';
            referencedColumns: ['id'];
          },
          {
            foreignKeyName: 'consumption_logs_food_id_fkey';
            columns: ['food_id'];
            isOneToOne: false;
            referencedRelation: 'foods';
            referencedColumns: ['id'];
          },
        ];
      };
      coach_pairings: {
        Row: CoachPairing;
        Insert: CoachPairingInsert;
        Update: CoachPairingInsert;
        Relationships: [];
      };
      user_health_profiles: {
        Row: UserHealthProfileRow;
        Insert: UserHealthProfileInsert;
        Update: UserHealthProfileUpdate;
        Relationships: [
          {
            foreignKeyName: 'user_health_profiles_user_id_fkey';
            columns: ['user_id'];
            isOneToOne: true;
            referencedRelation: 'users';
            referencedColumns: ['id'];
          },
        ];
      };
      mood_logs: {
        Row: MoodLog;
        Insert: MoodLogInsert;
        Update: MoodLogUpdate;
        Relationships: [
          {
            foreignKeyName: 'mood_logs_user_id_fkey';
            columns: ['user_id'];
            isOneToOne: false;
            referencedRelation: 'users';
            referencedColumns: ['id'];
          },
          {
            foreignKeyName: 'mood_logs_consumption_log_id_fkey';
            columns: ['consumption_log_id'];
            isOneToOne: false;
            referencedRelation: 'consumption_logs';
            referencedColumns: ['id'];
          },
        ];
      };
      sleep_logs: {
        Row: SleepLog;
        Insert: SleepLogInsert;
        Update: SleepLogUpdate;
        Relationships: [
          {
            foreignKeyName: 'sleep_logs_user_id_fkey';
            columns: ['user_id'];
            isOneToOne: false;
            referencedRelation: 'users';
            referencedColumns: ['id'];
          },
        ];
      };
      water_logs: {
        Row: WaterLog;
        Insert: WaterLogInsert;
        Update: WaterLogInsert;
        Relationships: [
          {
            foreignKeyName: 'water_logs_user_id_fkey';
            columns: ['user_id'];
            isOneToOne: false;
            referencedRelation: 'users';
            referencedColumns: ['id'];
          },
        ];
      };
      caffeine_logs: {
        Row: CaffeineLog;
        Insert: CaffeineLogInsert;
        Update: CaffeineLogInsert;
        Relationships: [
          {
            foreignKeyName: 'caffeine_logs_user_id_fkey';
            columns: ['user_id'];
            isOneToOne: false;
            referencedRelation: 'users';
            referencedColumns: ['id'];
          },
        ];
      };
      photo_analyses: {
        Row: PhotoAnalysis;
        Insert: PhotoAnalysisInsert;
        Update: Partial<PhotoAnalysisInsert>;
        Relationships: [
          {
            foreignKeyName: 'photo_analyses_user_id_fkey';
            columns: ['user_id'];
            isOneToOne: false;
            referencedRelation: 'users';
            referencedColumns: ['id'];
          },
        ];
      };
      dietitian_assignments: {
        Row: DietitianAssignment;
        Insert: DietitianAssignmentInsert;
        Update: Partial<DietitianAssignmentInsert>;
        Relationships: [
          {
            foreignKeyName: 'dietitian_assignments_dietitian_id_fkey';
            columns: ['dietitian_id'];
            isOneToOne: false;
            referencedRelation: 'users';
            referencedColumns: ['id'];
          },
          {
            foreignKeyName: 'dietitian_assignments_client_id_fkey';
            columns: ['client_id'];
            isOneToOne: false;
            referencedRelation: 'users';
            referencedColumns: ['id'];
          },
        ];
      };
    };
    Views: {
      daily_water_summary: {
        Row: {
          user_id: string;
          log_date: string;
          total_ml: number;
          entry_count: number;
        };
      };
      daily_caffeine_summary: {
        Row: {
          user_id: string;
          log_date: string;
          total_caffeine_mg: number;
          entry_count: number;
          daily_status: 'NORMAL' | 'DİKKAT' | 'UYARI';
        };
      };
      daily_mood_summary: {
        Row: {
          user_id: string;
          log_date: string;
          avg_mood: number;
          avg_stress: number;
          avg_energy: number;
          entry_count: number;
        };
      };
      mood_glucose_correlation: {
        Row: {
          user_id: string;
          log_date: string;
          mood_score: number;
          stress_level: number | null;
          energy_level: number | null;
          mood_tags: string[];
          consumed_at: string | null;
          calculated_gl: number | null;
          gi_value: number | null;
          food_name: string | null;
          color_code: string | null;
          cortisol_risk_score: number | null;
          minutes_after_meal: number | null;
        };
      };
    };
    Functions: {
      fuzzy_food_search: {
        Args: {
          search_term: string;
          similarity_threshold?: number;
          max_results?: number;
        };
        Returns: {
          id: number;
          name: string;
          category: string;
          gi_value: number;
          carbs_per_100g: number;
          protein_per_100g: number;
          fat_per_100g: number;
          calories_per_100g: number;
          color_code: string;
          similarity: number;
        }[];
      };
      estimate_gi_from_macros: {
        Args: {
          carbs: number;
          fiber?: number;
          fat?: number;
          protein?: number;
        };
        Returns: number;
      };
      is_my_dietitian: {
        Args: { target_user_id: string };
        Returns: boolean;
      };
    };
    Enums: {
      color_code: ColorCode;
    };
    CompositeTypes: {
      [_ in never]: never;
    };
  };
}


// ══════════════════════════════════════════════════════════════
// 13. YARDIMCI TİPLER
// ══════════════════════════════════════════════════════════════

/** consumption_logs + foods join sonucu */
export interface ConsumptionLogWithFood extends ConsumptionLog {
  food: Food;
}

/** Glisemik Yük seviyesi */
export type GlycemicLoadLevel = 'low' | 'medium' | 'high';

/**
 * GL seviyesini belirler:
 * - low: GL ≤ 10
 * - medium: 11 ≤ GL ≤ 19
 * - high: GL ≥ 20
 */
export function getGlycemicLoadLevel(gl: number): GlycemicLoadLevel {
  if (gl <= 10) return 'low';
  if (gl <= 19) return 'medium';
  return 'high';
}

/**
 * ColorCode'u trafik lambası etiketine çevirir.
 */
export function getColorCodeLabel(code: ColorCode): string {
  const labels: Record<ColorCode, string> = {
    GREEN: 'Güvenli',
    YELLOW: 'Dikkat',
    RED: 'Riskli',
  };
  return labels[code];
}

/**
 * ColorCode'u emoji'ye çevirir.
 */
export function getColorCodeEmoji(code: ColorCode): string {
  const emojis: Record<ColorCode, string> = {
    GREEN: '🟢',
    YELLOW: '🟡',
    RED: '🔴',
  };
  return emojis[code];
}

/** Yaygın kafeinli içeceklerin varsayılan mg değerleri */
export const CAFFEINE_DEFAULTS: Record<BeverageType, { label: string; mg: number; ml: number }> = {
  turk_kahvesi:    { label: 'Türk Kahvesi',      mg: 50,  ml: 65  },
  filtre_kahve:    { label: 'Filtre Kahve',       mg: 95,  ml: 240 },
  espresso:        { label: 'Espresso',           mg: 63,  ml: 30  },
  siyah_cay:       { label: 'Siyah Çay',          mg: 47,  ml: 240 },
  yesil_cay:       { label: 'Yeşil Çay',          mg: 28,  ml: 240 },
  enerji_icecegi:  { label: 'Enerji İçeceği',     mg: 80,  ml: 250 },
  kola:            { label: 'Kola',               mg: 34,  ml: 330 },
  diger:           { label: 'Diğer',              mg: 40,  ml: 200 },
};
