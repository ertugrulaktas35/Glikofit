// ============================================================
// 💎 Premium Kontrol — Basit Supabase Tabanlı
// ============================================================
// RevenueCat kaldırıldı. Premium kontrol artık users tablosundaki
// is_premium boolean alanı üzerinden yapılıyor.
// ============================================================

import { supabase } from './supabase';

/**
 * Kullanıcının premium üye olup olmadığını Supabase'den kontrol eder.
 * @param userId — Kullanıcı UUID'si (auth.uid())
 * @returns true ise premium kullanıcı
 */
export async function checkIsPremium(userId: string): Promise<boolean> {
  try {
    const { data, error } = await supabase
      .from('users')
      .select('is_premium')
      .eq('id', userId)
      .single();

    if (error) {
      console.warn('⚠️ Premium kontrol hatası:', error.message);
      return false;
    }

    const userData = data as { is_premium: boolean } | null;
    return userData?.is_premium ?? false;
  } catch (err) {
    console.error('❌ Premium kontrol beklenmeyen hata:', err);
    return false;
  }
}
