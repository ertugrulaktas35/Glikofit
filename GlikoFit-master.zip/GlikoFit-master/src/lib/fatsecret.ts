// ============================================================
// 🥗 FatSecret API — Tam Entegrasyon Kütüphanesi
// ============================================================
// Tüm FatSecret API uç noktalarını kapsayan servis.
// Besinler · Barkodlar · Tarifler · Egzersizler · Restoranlar
//
// Mimari: Edge Function (güvenli) → fallback (doğrudan API)
// ============================================================

import { supabase } from './supabase';
import type { ColorCode } from '../types/database';

// ── Temel Yardımcılar ─────────────────────────────────────────

const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
function btoaSafe(input: string): string {
  let str = String(input);
  let output = '';
  for (
    let block = 0, charCode, idx = 0, map = chars;
    str.charAt(idx | 0) || ((map = '='), idx % 1);
    output += map.charAt(63 & (block >> (8 - (idx % 1) * 8)))
  ) {
    charCode = str.charCodeAt((idx += 3 / 4));
    if (charCode > 0xff) throw new Error('btoa: Latin1 aralığı dışı karakter');
    block = (block << 8) | charCode;
  }
  return output;
}

// API sabitleri
const CLIENT_ID     = process.env.EXPO_PUBLIC_FATSECRET_CLIENT_ID;
const CLIENT_SECRET = process.env.EXPO_PUBLIC_FATSECRET_CLIENT_SECRET;
const BASE_URL      = 'https://platform.fatsecret.com/rest/server.api';
const TOKEN_URL     = 'https://oauth.fatsecret.com/connect/token';

let _cachedToken: string | null = null;
let _tokenExpiry  = 0;

async function getToken(): Promise<string> {
  if (_cachedToken && Date.now() < _tokenExpiry) return _cachedToken;
  if (!CLIENT_ID || !CLIENT_SECRET) throw new Error('FatSecret API anahtarları eksik!');

  const res = await fetch(TOKEN_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
      Authorization: `Basic ${btoaSafe(`${CLIENT_ID}:${CLIENT_SECRET}`)}`,
    },
    body: 'grant_type=client_credentials&scope=basic',
  });

  if (!res.ok) throw new Error('FatSecret token alınamadı');
  const data = await res.json();
  _cachedToken = data.access_token;
  _tokenExpiry = Date.now() + data.expires_in * 1000 - 60_000;
  return _cachedToken!;
}

async function fsGet(params: Record<string, string | number>): Promise<any> {
  const token = await getToken();
  const query = new URLSearchParams({
    format: 'json',
    ...Object.fromEntries(Object.entries(params).map(([k, v]) => [k, String(v)])),
  });
  const res = await fetch(`${BASE_URL}?${query}`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  if (!res.ok) throw new Error(`FatSecret API hatası: ${res.status}`);
  return res.json();
}

// ── GI Renk Kodu ────────────────────────────────────────────

function giToColor(gi: number): ColorCode {
  if (gi <= 55) return 'GREEN';
  if (gi <= 69) return 'YELLOW';
  return 'RED';
}

// ══════════════════════════════════════════════════════════════
// 1. BESİN ARAMA VE DETAY
// ══════════════════════════════════════════════════════════════

export interface FsNutrition {
  calories:       number;
  carbs:          number;
  protein:        number;
  fat:            number;
  fiber:          number;
  sugar:          number;
  sodium:         number;
  potassium:      number;
  cholesterol:    number;
  saturated_fat:  number;
  vitamin_c:      number;
  iron:           number;
}

export interface FsFood {
  food_id:     string;
  food_name:   string;
  brand_name?: string;
  food_type:   'Generic' | 'Brand';
  category?:   string;
  description: string;
  nutrition:   FsNutrition;           // 100g başına
  serving_description?: string;
  gi_value:    number | null;
  gi_source:   string;
  color_code:  ColorCode;
}

function parseServing(serving: any): FsNutrition {
  const n = (key: string) => parseFloat(serving?.[key] ?? '0') || 0;
  return {
    calories:      n('calories'),
    carbs:         n('carbohydrate'),
    protein:       n('protein'),
    fat:           n('fat'),
    fiber:         n('fiber'),
    sugar:         n('sugar'),
    sodium:        n('sodium'),
    potassium:     n('potassium'),
    cholesterol:   n('cholesterol'),
    saturated_fat: n('saturated_fat'),
    vitamin_c:     n('vitamin_c'),
    iron:          n('iron'),
  };
}

function normalize100g(serving: any): FsNutrition {
  const amount = parseFloat(serving?.metric_serving_amount ?? '100') || 100;
  const raw = parseServing(serving);
  const factor = 100 / amount;
  return {
    calories:      Math.round(raw.calories * factor * 10) / 10,
    carbs:         Math.round(raw.carbs * factor * 10) / 10,
    protein:       Math.round(raw.protein * factor * 10) / 10,
    fat:           Math.round(raw.fat * factor * 10) / 10,
    fiber:         Math.round(raw.fiber * factor * 10) / 10,
    sugar:         Math.round(raw.sugar * factor * 10) / 10,
    sodium:        Math.round(raw.sodium * factor),
    potassium:     Math.round(raw.potassium * factor),
    cholesterol:   Math.round(raw.cholesterol * factor),
    saturated_fat: Math.round(raw.saturated_fat * factor * 10) / 10,
    vitamin_c:     Math.round(raw.vitamin_c * factor * 10) / 10,
    iron:          Math.round(raw.iron * factor * 10) / 10,
  };
}

async function enrichWithLocalGI(name: string, carbs: number, fat: number, protein: number): Promise<{ gi: number; source: string }> {
  try {
    const { data } = await supabase.rpc('fuzzy_food_search', {
      search_term: name,
      similarity_threshold: 0.3,
      max_results: 1,
    });
    if (data?.[0]) return { gi: data[0].gi_value, source: 'local_db' };
  } catch {}

  // Makro tabanlı tahmin
  const { data } = await supabase.rpc('estimate_gi_from_macros', {
    carbs, fiber: 0, fat, protein,
  });
  return { gi: data ?? 50, source: 'macro_estimate' };
}

/** Besin araması — isim ile */
export async function searchFoods(
  query: string,
  maxResults = 10,
  region = 'TR',
): Promise<FsFood[]> {
  try {
    const data = await fsGet({
      method:            'foods.search',
      search_expression: query,
      max_results:       maxResults,
      region,
      language:          'tr',
    });

    const foodList = data?.foods?.food ?? [];
    const arr = Array.isArray(foodList) ? foodList : [foodList];

    const results: FsFood[] = [];
    for (const f of arr) {
      const desc = f.food_description ?? '';
      const parsedCarbs  = parseFloat(desc.match(/Carbs:\s*([\d.]+)g/)?.[1] ?? '0') || 0;
      const parsedFat    = parseFloat(desc.match(/Fat:\s*([\d.]+)g/)?.[1] ?? '0') || 0;
      const parsedProt   = parseFloat(desc.match(/Prot:\s*([\d.]+)g/)?.[1] ?? '0') || 0;
      const parsedCal    = parseFloat(desc.match(/Calories:\s*([\d.]+)/)?.[1] ?? '0') || 0;

      const { gi, source } = await enrichWithLocalGI(f.food_name, parsedCarbs, parsedFat, parsedProt);

      results.push({
        food_id:     f.food_id,
        food_name:   f.food_name,
        brand_name:  f.brand_name,
        food_type:   f.food_type ?? 'Generic',
        description: desc,
        nutrition: {
          calories:      parsedCal,
          carbs:         parsedCarbs,
          protein:       parsedProt,
          fat:           parsedFat,
          fiber:         0,
          sugar:         0,
          sodium:        0,
          potassium:     0,
          cholesterol:   0,
          saturated_fat: 0,
          vitamin_c:     0,
          iron:          0,
        },
        gi_value:   gi,
        gi_source:  source,
        color_code: giToColor(gi),
      });
    }
    return results;
  } catch (err) {
    console.error('searchFoods error:', err);
    return [];
  }
}

/** Besin detayı — food_id ile tam mikro besin (100g başına) */
export async function getFoodDetail(foodId: string): Promise<FsFood | null> {
  try {
    const data = await fsGet({ method: 'food.get.v2', food_id: foodId });
    const food = data?.food;
    if (!food) return null;

    const servings = food.servings?.serving;
    const arr = Array.isArray(servings) ? servings : [servings];

    // Önce 100g servisini bul, yoksa normalize et
    const s100 = arr.find((s: any) =>
      s.metric_serving_amount === '100.000' ||
      s.serving_description === '100 g',
    ) ?? arr.find((s: any) => s.metric_serving_amount) ?? arr[0];

    const nutrition  = normalize100g(s100);
    const { gi, source } = await enrichWithLocalGI(
      food.food_name,
      nutrition.carbs,
      nutrition.fat,
      nutrition.protein,
    );

    return {
      food_id:             String(food.food_id),
      food_name:           food.food_name,
      brand_name:          food.brand_name,
      food_type:           food.food_type ?? 'Generic',
      description:         food.food_description ?? '',
      nutrition,
      serving_description: s100?.serving_description,
      gi_value:            gi,
      gi_source:           source,
      color_code:          giToColor(gi),
    };
  } catch (err) {
    console.error('getFoodDetail error:', err);
    return null;
  }
}

/** Popüler besinler */
export async function getPopularFoods(maxResults = 15): Promise<FsFood[]> {
  try {
    const data = await fsGet({ method: 'foods.get_most_popular', max_results: maxResults });
    const list = data?.foods?.food ?? [];
    const arr  = Array.isArray(list) ? list : [list];
    return Promise.all(
      arr.map((f: any) => getFoodDetail(String(f.food_id))),
    ).then((results) => results.filter(Boolean) as FsFood[]);
  } catch (err) {
    console.error('getPopularFoods error:', err);
    return [];
  }
}

/** Oto-tamamlama önerileri */
export async function autocompleteFoods(query: string, maxResults = 7): Promise<string[]> {
  try {
    const data = await fsGet({
      method:      'foods.autocomplete',
      expression:  query,
      max_results: maxResults,
    });
    const suggestions = data?.suggestions?.suggestion ?? [];
    return Array.isArray(suggestions) ? suggestions : [suggestions];
  } catch {
    return [];
  }
}


// ══════════════════════════════════════════════════════════════
// 2. BARKOD ARAMA
// ══════════════════════════════════════════════════════════════

export interface BarcodeResult {
  barcode:    string;
  food:       FsFood | null;
  from_cache: boolean;
}

/** UPC/EAN barkod ile besin bul */
export async function findFoodByBarcode(barcode: string): Promise<BarcodeResult> {
  // Önce yerel cache'e bak
  const { data: cached } = await supabase
    .from('barcode_cache')
    .select('*')
    .eq('barcode', barcode)
    .single();

  if (cached?.fatsecret_id) {
    const food = await getFoodDetail(cached.fatsecret_id);
    return { barcode, food, from_cache: true };
  }

  // FatSecret'ta ara
  try {
    const data = await fsGet({
      method:     'food.find_id_for_barcode',
      barcode,
    });

    const foodId = data?.food_id?.value;
    if (!foodId) return { barcode, food: null, from_cache: false };

    const food = await getFoodDetail(String(foodId));

    // Cache'e kaydet
    await supabase.from('barcode_cache').upsert({
      barcode,
      fatsecret_id: String(foodId),
      food_name:    food?.food_name,
      brand:        food?.brand_name,
    });

    return { barcode, food, from_cache: false };
  } catch (err) {
    console.error('findFoodByBarcode error:', err);
    return { barcode, food: null, from_cache: false };
  }
}


// ══════════════════════════════════════════════════════════════
// 3. TARİF ARAMA VE DETAY
// ══════════════════════════════════════════════════════════════

export interface FsRecipeIngredient {
  ingredient_description: string;
  food_id:                string;
  food_name:              string;
  num_servings:           number;
  measurement_description: string;
  calories:               number;
  carbs:                  number;
  protein:                number;
  fat:                    number;
}

export interface FsRecipe {
  recipe_id:          string;
  recipe_name:        string;
  recipe_description: string;
  recipe_url:         string;
  recipe_categories:  string[];
  rating:             number;
  preparation_time_min: number;
  cooking_time_min:   number;
  number_of_servings: number;
  ingredients:        FsRecipeIngredient[];
  serving_nutrition:  FsNutrition;       // Porsiyon başına
  image_url?:         string;
}

/** Tarif araması */
export async function searchRecipes(
  query: string,
  maxResults = 10,
): Promise<Omit<FsRecipe, 'ingredients'>[]> {
  try {
    const data = await fsGet({
      method:            'recipes.search',
      search_expression: query,
      max_results:       maxResults,
    });

    const list = data?.recipes?.recipe ?? [];
    const arr  = Array.isArray(list) ? list : [list];

    return arr.map((r: any) => ({
      recipe_id:            String(r.recipe_id),
      recipe_name:          r.recipe_name,
      recipe_description:   r.recipe_description ?? '',
      recipe_url:           r.recipe_url ?? '',
      recipe_categories:    [r.recipe_category_name ?? 'Genel'],
      rating:               parseFloat(r.recipe_rating ?? '0'),
      preparation_time_min: parseInt(r.preparation_time_min ?? '0'),
      cooking_time_min:     parseInt(r.cooking_time_min ?? '0'),
      number_of_servings:   parseFloat(r.number_of_servings ?? '1'),
      serving_nutrition: {
        calories:      parseFloat(r.recipe_nutrition?.calories ?? '0'),
        carbs:         parseFloat(r.recipe_nutrition?.carbohydrate ?? '0'),
        protein:       parseFloat(r.recipe_nutrition?.protein ?? '0'),
        fat:           parseFloat(r.recipe_nutrition?.fat ?? '0'),
        fiber:         parseFloat(r.recipe_nutrition?.fiber ?? '0'),
        sugar:         0,
        sodium:        0,
        potassium:     0,
        cholesterol:   0,
        saturated_fat: 0,
        vitamin_c:     0,
        iron:          0,
      },
      image_url: r.recipe_image ?? undefined,
      ingredients: [],
    }));
  } catch (err) {
    console.error('searchRecipes error:', err);
    return [];
  }
}

/** Popüler tarifler */
export async function getPopularRecipes(maxResults = 12): Promise<Omit<FsRecipe, 'ingredients'>[]> {
  try {
    const data = await fsGet({
      method:      'recipes.get_most_popular',
      max_results: maxResults,
    });
    const list = data?.recipes?.recipe ?? [];
    const arr  = Array.isArray(list) ? list : [list];
    return arr.map((r: any) => ({
      recipe_id:            String(r.recipe_id),
      recipe_name:          r.recipe_name,
      recipe_description:   r.recipe_description ?? '',
      recipe_url:           r.recipe_url ?? '',
      recipe_categories:    [r.recipe_category_name ?? 'Genel'],
      rating:               parseFloat(r.recipe_rating ?? '0'),
      preparation_time_min: parseInt(r.preparation_time_min ?? '0'),
      cooking_time_min:     parseInt(r.cooking_time_min ?? '0'),
      number_of_servings:   parseFloat(r.number_of_servings ?? '1'),
      serving_nutrition: {
        calories:      parseFloat(r.recipe_nutrition?.calories ?? '0'),
        carbs:         parseFloat(r.recipe_nutrition?.carbohydrate ?? '0'),
        protein:       parseFloat(r.recipe_nutrition?.protein ?? '0'),
        fat:           parseFloat(r.recipe_nutrition?.fat ?? '0'),
        fiber:         parseFloat(r.recipe_nutrition?.fiber ?? '0'),
        sugar:         0, sodium:0, potassium:0, cholesterol:0,
        saturated_fat:0, vitamin_c:0, iron:0,
      },
      image_url:  r.recipe_image ?? undefined,
      ingredients:[],
    }));
  } catch {
    return [];
  }
}

/** Tarif detayı — malzeme listesi + tam besin değeri */
export async function getRecipeDetail(recipeId: string): Promise<FsRecipe | null> {
  try {
    const data = await fsGet({ method: 'recipe.get', recipe_id: recipeId });
    const r = data?.recipe;
    if (!r) return null;

    const ingList  = r.ingredients?.ingredient ?? [];
    const ingArr   = Array.isArray(ingList) ? ingList : [ingList];

    const ingredients: FsRecipeIngredient[] = ingArr.map((i: any) => ({
      ingredient_description:  i.ingredient_description ?? '',
      food_id:                 String(i.food_id),
      food_name:               i.food_name ?? '',
      num_servings:            parseFloat(i.number_of_units ?? '1'),
      measurement_description: i.measurement_description ?? '',
      calories:                parseFloat(i.calories ?? '0'),
      carbs:                   parseFloat(i.carbohydrate ?? '0'),
      protein:                 parseFloat(i.protein ?? '0'),
      fat:                     parseFloat(i.fat ?? '0'),
    }));

    const sn = r.serving_sizes?.serving;
    const snArr = Array.isArray(sn) ? sn : [sn];
    const snFirst = snArr?.[0] ?? {};

    return {
      recipe_id:            String(r.recipe_id),
      recipe_name:          r.recipe_name,
      recipe_description:   r.recipe_description ?? '',
      recipe_url:           r.recipe_url ?? '',
      recipe_categories:    (Array.isArray(r.recipe_categories?.recipe_category)
        ? r.recipe_categories.recipe_category
        : [r.recipe_categories?.recipe_category]).map((c: any) => c?.recipe_category_name ?? ''),
      rating:               parseFloat(r.recipe_rating ?? '0'),
      preparation_time_min: parseInt(r.preparation_time_min ?? '0'),
      cooking_time_min:     parseInt(r.cooking_time_min ?? '0'),
      number_of_servings:   parseFloat(r.number_of_servings ?? '1'),
      ingredients,
      serving_nutrition: {
        calories:      parseFloat(snFirst.calories ?? '0'),
        carbs:         parseFloat(snFirst.carbohydrate ?? '0'),
        protein:       parseFloat(snFirst.protein ?? '0'),
        fat:           parseFloat(snFirst.fat ?? '0'),
        fiber:         parseFloat(snFirst.fiber ?? '0'),
        sugar:         parseFloat(snFirst.sugar ?? '0'),
        sodium:        parseFloat(snFirst.sodium ?? '0'),
        potassium:     parseFloat(snFirst.potassium ?? '0'),
        cholesterol:   parseFloat(snFirst.cholesterol ?? '0'),
        saturated_fat: parseFloat(snFirst.saturated_fat ?? '0'),
        vitamin_c:     parseFloat(snFirst.vitamin_c ?? '0'),
        iron:          parseFloat(snFirst.iron ?? '0'),
      },
      image_url: r.recipe_image ?? undefined,
    };
  } catch (err) {
    console.error('getRecipeDetail error:', err);
    return null;
  }
}


// ══════════════════════════════════════════════════════════════
// 4. EGZERSİZ
// ══════════════════════════════════════════════════════════════

export interface FsExercise {
  exercise_id:       number;
  exercise_name:     string;
  category:          string;
  /** 65kg referans ağırlık için dakika başına kalori */
  calories_per_min:  number;
  /** MET değeri (tahmini) */
  met_value:         number;
}

export interface ExerciseCategoryGroup {
  category:  string;
  exercises: FsExercise[];
}

let _exerciseCache: ExerciseCategoryGroup[] | null = null;

/** Tüm egzersiz listesini FatSecret'tan çek */
export async function getExercises(): Promise<ExerciseCategoryGroup[]> {
  if (_exerciseCache) return _exerciseCache;

  try {
    const data  = await fsGet({ method: 'exercises.get' });
    const cats  = data?.exercise_categories?.exercise_category ?? [];
    const cArr  = Array.isArray(cats) ? cats : [cats];

    const groups: ExerciseCategoryGroup[] = cArr.map((cat: any) => {
      const types = cat.exercise_types?.exercise_type ?? [];
      const tArr  = Array.isArray(types) ? types : [types];

      const exercises: FsExercise[] = tArr.map((t: any) => {
        const cpm = parseFloat(t.calories_per_hour_per_kg ?? '0') / 60;
        return {
          exercise_id:      parseInt(t.exercise_type_id ?? '0'),
          exercise_name:    t.exercise_type_name ?? 'Bilinmeyen',
          category:         cat.exercise_category_name ?? 'Genel',
          calories_per_min: cpm,
          met_value:        cpm / 0.0175, // MET = kcal/min / (0.0175 × kg) → normalize for 1kg
        };
      });

      return { category: cat.exercise_category_name ?? 'Genel', exercises };
    });

    _exerciseCache = groups;
    return groups;
  } catch (err) {
    console.error('getExercises error:', err);
    return FALLBACK_EXERCISES;
  }
}

/**
 * Kalori yakımı hesapla
 * @param caloriesPerMin - FatSecret'tan gelen dakika başına kalori (65kg için)
 * @param durationMin    - Süre (dakika)
 * @param weightKg       - Kullanıcı ağırlığı
 */
export function calculateCaloriesBurned(
  caloriesPerMin: number,
  durationMin:    number,
  weightKg:       number,
): number {
  // FatSecret referans ağırlığı 65kg — kullanıcı ağırlığına göre oranla
  const scaled = caloriesPerMin * (weightKg / 65) * durationMin;
  return Math.round(scaled);
}

/** Egzersiz listesi çekilemezse kullanılacak temel egzersizler */
const FALLBACK_EXERCISES: ExerciseCategoryGroup[] = [
  {
    category: 'Yürüyüş / Koşu',
    exercises: [
      { exercise_id:1,  exercise_name:'Yavaş Yürüyüş',     category:'Yürüyüş / Koşu', calories_per_min:3.0,  met_value:2.5 },
      { exercise_id:2,  exercise_name:'Tempolu Yürüyüş',   category:'Yürüyüş / Koşu', calories_per_min:4.2,  met_value:3.5 },
      { exercise_id:3,  exercise_name:'Hafif Koşu',        category:'Yürüyüş / Koşu', calories_per_min:7.0,  met_value:6.0 },
      { exercise_id:4,  exercise_name:'Orta Koşu',         category:'Yürüyüş / Koşu', calories_per_min:9.0,  met_value:8.0 },
      { exercise_id:5,  exercise_name:'Hızlı Koşu',        category:'Yürüyüş / Koşu', calories_per_min:12.0, met_value:10.0},
    ],
  },
  {
    category: 'Bisiklet',
    exercises: [
      { exercise_id:10, exercise_name:'Hafif Bisiklet',    category:'Bisiklet', calories_per_min:5.0,  met_value:4.0 },
      { exercise_id:11, exercise_name:'Orta Bisiklet',     category:'Bisiklet', calories_per_min:7.5,  met_value:6.5 },
      { exercise_id:12, exercise_name:'Hızlı Bisiklet',    category:'Bisiklet', calories_per_min:10.5, met_value:9.0 },
    ],
  },
  {
    category: 'Yüzme',
    exercises: [
      { exercise_id:20, exercise_name:'Hafif Yüzme',       category:'Yüzme', calories_per_min:6.0,  met_value:5.0 },
      { exercise_id:21, exercise_name:'Serbest Stil',      category:'Yüzme', calories_per_min:9.0,  met_value:8.0 },
    ],
  },
  {
    category: 'Ağırlık / Güç',
    exercises: [
      { exercise_id:30, exercise_name:'Hafif Ağırlık',     category:'Ağırlık / Güç', calories_per_min:4.0,  met_value:3.5 },
      { exercise_id:31, exercise_name:'Ağırlık Antrenmanı',category:'Ağırlık / Güç', calories_per_min:6.0,  met_value:5.0 },
    ],
  },
  {
    category: 'Dans / Aerobik',
    exercises: [
      { exercise_id:40, exercise_name:'Yoga',              category:'Dans / Aerobik', calories_per_min:2.5,  met_value:2.0 },
      { exercise_id:41, exercise_name:'Pilates',           category:'Dans / Aerobik', calories_per_min:3.0,  met_value:2.5 },
      { exercise_id:42, exercise_name:'Aerobik Dans',      category:'Dans / Aerobik', calories_per_min:6.0,  met_value:5.0 },
      { exercise_id:43, exercise_name:'Zumba',             category:'Dans / Aerobik', calories_per_min:7.0,  met_value:6.0 },
    ],
  },
  {
    category: 'Ev & Günlük',
    exercises: [
      { exercise_id:50, exercise_name:'Ev İşleri',         category:'Ev & Günlük', calories_per_min:2.5,  met_value:2.0 },
      { exercise_id:51, exercise_name:'Bahçe İşleri',      category:'Ev & Günlük', calories_per_min:3.5,  met_value:3.0 },
      { exercise_id:52, exercise_name:'Merdiven Çıkma',    category:'Ev & Günlük', calories_per_min:8.0,  met_value:7.0 },
    ],
  },
];


// ══════════════════════════════════════════════════════════════
// 5. RESTORAN / MARKA ARAMA
// ══════════════════════════════════════════════════════════════

export interface FsBrandFood {
  food_id:   string;
  food_name: string;
  brand:     string;
  calories:  number;
  carbs:     number;
  protein:   number;
  fat:       number;
  color_code: ColorCode;
}

/** Marka veya restoran adıyla arama */
export async function searchBrandFoods(
  brandName: string,
  maxResults = 10,
): Promise<FsBrandFood[]> {
  try {
    const results = await searchFoods(`${brandName}`, maxResults);
    return results
      .filter((f) => f.food_type === 'Brand' || f.brand_name)
      .map((f) => ({
        food_id:   f.food_id,
        food_name: f.food_name,
        brand:     f.brand_name ?? brandName,
        calories:  f.nutrition.calories,
        carbs:     f.nutrition.carbs,
        protein:   f.nutrition.protein,
        fat:       f.nutrition.fat,
        color_code: f.color_code,
      }));
  } catch (err) {
    console.error('searchBrandFoods error:', err);
    return [];
  }
}


// ══════════════════════════════════════════════════════════════
// 6. OTO-POPULATE — Mevcut Besinlerin Makrolarını Doldurma
// ══════════════════════════════════════════════════════════════

/**
 * Supabase foods tablosundaki 'manual' kayıtları FatSecret'tan
 * arayıp makro değerlerini günceller.
 * Bu fonksiyon bir kez çalıştırılmalıdır (admin / geliştirici tarafından).
 */
export async function autoPopulateFoodMacros(
  onProgress?: (current: number, total: number, name: string) => void,
): Promise<{ updated: number; failed: string[] }> {
  const { data: foods, error } = await supabase
    .from('foods')
    .select('id, name')
    .eq('source', 'manual');

  if (error || !foods) return { updated: 0, failed: [] };

  let updated = 0;
  const failed: string[] = [];

  for (let i = 0; i < foods.length; i++) {
    const food = foods[i];
    onProgress?.(i + 1, foods.length, food.name);

    try {
      const results = await searchFoods(food.name, 3);
      if (results.length === 0) {
        failed.push(food.name);
        continue;
      }

      // En yakın sonucu seç
      const best = results[0];
      const detail = await getFoodDetail(best.food_id);
      if (!detail) {
        failed.push(food.name);
        continue;
      }

      await supabase.from('foods').update({
        protein_per_100g:   detail.nutrition.protein,
        fat_per_100g:       detail.nutrition.fat,
        calories_per_100g:  detail.nutrition.calories,
        fiber_per_100g:     detail.nutrition.fiber,
        sodium_mg:          detail.nutrition.sodium,
        potassium_mg:       detail.nutrition.potassium,
        vitamin_c_mg:       detail.nutrition.vitamin_c,
        iron_mg:            detail.nutrition.iron,
        cholesterol_mg:     detail.nutrition.cholesterol,
        saturated_fat_g:    detail.nutrition.saturated_fat,
        sugar_g:            detail.nutrition.sugar,
        fatsecret_id:       detail.food_id,
        serving_description:detail.serving_description,
        source:             'fatsecret',
      }).eq('id', food.id);

      updated++;

      // Rate limiting — FatSecret API'ye çok hızlı istek atmayalım
      await new Promise((r) => setTimeout(r, 300));
    } catch {
      failed.push(food.name);
    }
  }

  return { updated, failed };
}


// ══════════════════════════════════════════════════════════════
// 7. GERİYE UYUMLULUK — Eski API signature'ları
// ══════════════════════════════════════════════════════════════

/** @deprecated searchFoods kullanın */
export async function searchFoodsFatSecret(
  query: string,
  maxResults = 5,
): Promise<{ food_id: string; food_name: string; carbs_per_100g: number }[]> {
  const results = await searchFoods(query, maxResults);
  return results.map((r) => ({
    food_id:        r.food_id,
    food_name:      r.food_name,
    carbs_per_100g: r.nutrition.carbs,
  }));
}

/** @deprecated getFoodDetail kullanın */
export async function getCarbsPer100g(query: string): Promise<number | null> {
  const results = await searchFoods(query, 1);
  return results[0]?.nutrition.carbs ?? null;
}

export { getToken as getFatSecretToken };
