import 'react-native-url-polyfill/auto';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { createClient } from '@supabase/supabase-js';
import { Database } from '../types/database';

// ============================================================
// 🔑 Supabase Bağlantı Konfigürasyonu
// ============================================================
// .env dosyasından Supabase URL ve anon key'inizi alır.
//
// ⚠️ ÖNEMLİ:
// Aşağıdaki değerleri kendi Supabase projenizden alarak .env
// dosyanıza yapıştırın:
//   EXPO_PUBLIC_SUPABASE_URL=https://your-project-id.supabase.co
//   EXPO_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOi...
// ============================================================

const supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL || '';
const supabaseAnonKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY || '';

if (!supabaseUrl || !supabaseAnonKey) {
  console.warn(
    '⚠️ Supabase URL veya Anon Key tanımlı değil!\n' +
    '.env dosyanızda EXPO_PUBLIC_SUPABASE_URL ve EXPO_PUBLIC_SUPABASE_ANON_KEY ' +
    'değişkenlerini tanımlayın.'
  );
}

/**
 * Type-safe Supabase client.
 * Database generic tipi sayesinde tüm sorgular otomatik tiplendirilir:
 *   const { data } = await supabase.from('foods').select('*');
 *   // data tipi: Food[] | null
 */
export const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey, {
  auth: {
    storage: AsyncStorage,
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false,
  },
});

export default supabase;
