// ============================================================
// 📸 Fotoğraf Analiz Servisi — GlikoFit v2
// ============================================================
// Expo ImagePicker/Camera → Optimize → Edge Function → Sonuç
// ============================================================

import * as ImageManipulator from 'expo-image-manipulator';
import * as FileSystem from 'expo-file-system';
import { supabase } from '../lib/supabase';
import type { PhotoAnalysis, DetectedFoodItem } from '../types/database';

// ── Sabitler ─────────────────────────────────────────────────

const MAX_IMAGE_WIDTH = 1024;
const MAX_IMAGE_HEIGHT = 1024;
const JPEG_QUALITY = 0.7;

// ── Fotoğraf Optimizasyonu ───────────────────────────────────

/**
 * Fotoğrafı boyutlandırıp sıkıştırır (~150-300KB çıktı).
 * Bu adım, Gemini Vision için gereksiz büyük dosyaları engeller
 * ve mobil veri kullanımını minimize eder.
 */
export async function optimizeImage(uri: string): Promise<string> {
  const manipResult = await ImageManipulator.manipulateAsync(
    uri,
    [{ resize: { width: MAX_IMAGE_WIDTH, height: MAX_IMAGE_HEIGHT } }],
    {
      compress: JPEG_QUALITY,
      format: ImageManipulator.SaveFormat.JPEG,
    },
  );

  return manipResult.uri;
}

/**
 * Fotoğrafı base64'e çevirir (Edge Function'a gönderilmek üzere).
 */
export async function imageToBase64(uri: string): Promise<string> {
  const base64 = await FileSystem.readAsStringAsync(uri, {
    encoding: FileSystem.EncodingType.Base64,
  });
  return base64;
}

// ── Ana Analiz Pipeline'ı ────────────────────────────────────

export interface AnalyzePhotoResult {
  success: boolean;
  analysis?: PhotoAnalysis;
  error?: string;
}

/**
 * Tam fotoğraf analiz pipeline'ı:
 * 1) Fotoğrafı optimize et
 * 2) Base64'e dönüştür
 * 3) Edge Function'a gönder (Gemini Vision + GI zenginleştirme)
 * 4) Sonucu döndür
 *
 * Edge Function henüz deploy edilmediyse, doğrudan Gemini API'yi kullanır (fallback).
 */
export async function analyzePhotoFood(imageUri: string): Promise<AnalyzePhotoResult> {
  try {
    // 1. Optimize
    const optimizedUri = await optimizeImage(imageUri);

    // 2. Base64'e dönüştür
    const base64 = await imageToBase64(optimizedUri);

    // 3. Edge Function çağrısı
    const { data, error } = await supabase.functions.invoke('analyze-food-photo', {
      body: { image_base64: base64 },
    });

    if (error) {
      console.warn('Edge Function hatası, fallback kullanılıyor:', error.message);
      // Fallback: Doğrudan Gemini API (geçici çözüm)
      return await analyzeWithGeminiFallback(base64);
    }

    return {
      success: true,
      analysis: data as PhotoAnalysis,
    };
  } catch (err: any) {
    console.error('Photo analysis error:', err);
    return {
      success: false,
      error: err.message || 'Fotoğraf analiz edilemedi.',
    };
  }
}

// ── Fallback: Doğrudan Gemini Vision ─────────────────────────

const GEMINI_API_KEY = process.env.EXPO_PUBLIC_GEMINI_API_KEY;
const GEMINI_VISION_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${GEMINI_API_KEY}`;

const ANALYZE_PROMPT = `
Bu tabak fotoğrafını analiz et. Her yiyeceği tanı ve tahmini porsiyon miktarını gram cinsinden belirt.

Her yiyecek için şu değerleri hesapla (100g bazında):
- Kalori (kcal)
- Karbonhidrat (g)
- Protein (g)
- Yağ (g)
- Lif (g)
- Tahmini Glisemik İndeks (GI)

Yanıt olarak SADECE JSON döndür, başka metin yazma:
{
  "items": [
    {
      "name": "Besin adı (Türkçe)",
      "estimated_grams": 150,
      "confidence": 0.92,
      "macros": {
        "calories": 195,
        "carbs": 42,
        "protein": 3.5,
        "fat": 0.5,
        "fiber": 0.4
      },
      "gi_value": 73
    }
  ]
}
`;

async function analyzeWithGeminiFallback(base64: string): Promise<AnalyzePhotoResult> {
  if (!GEMINI_API_KEY) {
    return { success: false, error: 'Gemini API key tanımlı değil.' };
  }

  try {
    const response = await fetch(GEMINI_VISION_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [
          {
            parts: [
              { text: ANALYZE_PROMPT },
              {
                inlineData: {
                  mimeType: 'image/jpeg',
                  data: base64,
                },
              },
            ],
          },
        ],
        generationConfig: {
          temperature: 0.2,
        },
      }),
    });

    const data = await response.json();
    const rawText = data?.candidates?.[0]?.content?.parts?.[0]?.text;

    if (!rawText) {
      return { success: false, error: 'Gemini yanıt döndürmedi.' };
    }

    // JSON parse
    const jsonStart = rawText.indexOf('{');
    const jsonEnd = rawText.lastIndexOf('}');
    const cleanJson = rawText.substring(jsonStart, jsonEnd + 1);
    const parsed = JSON.parse(cleanJson);

    const items: DetectedFoodItem[] = (parsed.items || []).map((item: any) => ({
      name: item.name || 'Bilinmeyen',
      estimated_grams: item.estimated_grams || 100,
      confidence: item.confidence || 0.5,
      macros: {
        calories: item.macros?.calories || 0,
        carbs: item.macros?.carbs || 0,
        protein: item.macros?.protein || 0,
        fat: item.macros?.fat || 0,
        fiber: item.macros?.fiber || 0,
      },
      gi_value: item.gi_value || null,
      gi_source: 'estimated',
    }));

    // Toplamları hesapla (porsiyon oranına göre)
    let totalCalories = 0;
    let totalCarbs = 0;
    let totalProtein = 0;
    let totalFat = 0;
    let totalGiLoad = 0;

    for (const item of items) {
      const factor = item.estimated_grams / 100;
      totalCalories += item.macros.calories * factor;
      totalCarbs += item.macros.carbs * factor;
      totalProtein += item.macros.protein * factor;
      totalFat += item.macros.fat * factor;

      if (item.gi_value) {
        // GL = (GI × Carbs in serving) / 100
        totalGiLoad += (item.gi_value * item.macros.carbs * factor) / 100;
      }
    }

    const analysis: PhotoAnalysis = {
      id: 0,
      user_id: '',
      image_url: '',
      image_hash: null,
      detected_items: items,
      total_calories: Math.round(totalCalories),
      total_carbs: Math.round(totalCarbs * 10) / 10,
      total_protein: Math.round(totalProtein * 10) / 10,
      total_fat: Math.round(totalFat * 10) / 10,
      total_gi_load: Math.round(totalGiLoad * 10) / 10,
      processing_time_ms: null,
      model_version: 'gemini-1.5-flash',
      status: 'completed',
      error_message: null,
      reviewed_by: null,
      review_notes: null,
      analyzed_at: new Date().toISOString(),
    };

    return { success: true, analysis };
  } catch (err: any) {
    console.error('Gemini fallback error:', err);
    return { success: false, error: err.message || 'Gemini analiz hatası.' };
  }
}

// ── GI Zenginleştirme (Yerel DB) ────────────────────────────

/**
 * Analiz sonucundaki besinleri yerel foods tablosuyla eşleştirip
 * GI değerlerini zenginleştirir.
 */
export async function enrichWithLocalGI(
  items: DetectedFoodItem[],
): Promise<DetectedFoodItem[]> {
  const enriched = [...items];

  for (let i = 0; i < enriched.length; i++) {
    const item = enriched[i];

    // Supabase fuzzy search
    const { data } = await supabase.rpc('fuzzy_food_search', {
      search_term: item.name,
      similarity_threshold: 0.3,
      max_results: 1,
    });

    if (data && data.length > 0) {
      const match = data[0];
      enriched[i] = {
        ...item,
        gi_value: match.gi_value,
        gi_source: 'local_db',
        macros: {
          ...item.macros,
          carbs: match.carbs_per_100g ?? item.macros.carbs,
          protein: match.protein_per_100g ?? item.macros.protein,
          fat: match.fat_per_100g ?? item.macros.fat,
          calories: match.calories_per_100g ?? item.macros.calories,
        },
      };
    }
  }

  return enriched;
}
