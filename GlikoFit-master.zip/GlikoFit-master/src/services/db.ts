import { supabase } from '../lib/supabase';
import type { CoachPairing } from '../types/database';

export const getCoachAdvice = async (highRiskCategory: string): Promise<CoachPairing | null> => {
  try {
    const { data, error } = await supabase
      .from('coach_pairings')
      .select('*')
      .eq('high_risk_category', highRiskCategory);

    if (error) {
      console.error('getCoachAdvice error:', error);
      return null;
    }

    if (data && data.length > 0) {
      // Bir kategoride birden fazla tavsiye varsa rastgele birini göster, monotonluğu kır
      const randomIndex = Math.floor(Math.random() * data.length);
      return data[randomIndex];
    }
    
    return null;
  } catch (err) {
    console.error('getCoachAdvice exception:', err);
    return null;
  }
};
