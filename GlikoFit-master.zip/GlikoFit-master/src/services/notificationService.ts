import * as Notifications from 'expo-notifications';

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
});

export async function requestNotificationPermissions() {
  const { status: existingStatus } = await Notifications.getPermissionsAsync();
  let finalStatus = existingStatus;
  
  if (existingStatus !== 'granted') {
    const { status } = await Notifications.requestPermissionsAsync();
    finalStatus = status;
  }
  
  return finalStatus === 'granted';
}

export async function cancelAllNotifications() {
  await Notifications.cancelAllScheduledNotificationsAsync();
}

export async function scheduleHighGLNotification() {
  const hasPermission = await requestNotificationPermissions();
  if (!hasPermission) return;

  // 2 hours in seconds
  const seconds = 2 * 60 * 60;

  await Notifications.scheduleNotificationAsync({
    content: {
      title: "Kan Şekerinizi Dinleyin 🩸",
      body: "2 saat önce kan şekerini hızlı yükselten bir besin tükettiniz. Şu an enerjiniz düşüyor olabilir, bir bardak su için veya hafif bir protein (örn. ayran, kuruyemiş) atıştırın.",
      sound: true,
    },
    trigger: {
      seconds,
    },
  });
}
