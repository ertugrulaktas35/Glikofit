import { supabase } from '../lib/supabase';
import type { Food, CoachPairing } from '../types/database';
import type { UserHealthProfile } from '../utils/healthCalculations';
import { calculateBMI, getBmiCategory, DIABETES_TYPE_LABELS, ACTIVITY_LEVEL_LABELS } from '../utils/healthCalculations';

// ============================================================
// 🧠 AI Servis Katmanı — GlikoFit v2
// ============================================================
// Edge Function üzerinden güvenli Gemini API erişimi sağlar.
// Fallback olarak doğrudan API çağrısı yapabilir (geliştirme modunda).
// ============================================================

const GEMINI_API_KEY = process.env.EXPO_PUBLIC_GEMINI_API_KEY || process.env.GEMINI_API_KEY;
const API_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${GEMINI_API_KEY}`;

/**
 * Kişiselleştirilmiş Akıllı Koç Tavsiyesi
 * 
 * Önce Supabase Edge Function'ı dener (güvenli).
 * Başarısız olursa fallback olarak doğrudan Gemini API kullanır.
 */
export async function getSmartCoachAdvice(
  food: Food,
  portion: number,
  userProfile?: UserHealthProfile | null,
): Promise<CoachPairing | null> {

  // ── Yol 1: Edge Function (Güvenli — Tercih edilen) ────────
  try {
    const { data, error } = await supabase.functions.invoke('smart-coach', {
      body: {
        food: {
          name: food.name,
          category: food.category,
          gi_value: food.gi_value,
          carbs_per_100g: food.carbs_per_100g,
        },
        portion,
        userProfile: userProfile
          ? {
              birth_year: userProfile.birthYear,
              gender: userProfile.gender,
              height_cm: userProfile.heightCm,
              weight_kg: userProfile.weightKg,
              diabetes_type: userProfile.diabetesType,
              hba1c: userProfile.hba1c,
              fasting_glucose: userProfile.fastingGlucose,
              activity_level: userProfile.activityLevel,
            }
          : null,
      },
    });

    if (!error && data) {
      return {
        id: data.id || Math.floor(Math.random() * 100000),
        high_risk_category: data.high_risk_category,
        balancer_category: data.balancer_category,
        advice_text: data.advice_text,
        created_at: data.created_at || new Date().toISOString(),
      };
    }

    console.warn('Edge Function hatası, fallback kullanılıyor:', error?.message);
  } catch (edgeFnErr) {
    console.warn('Edge Function erişilemedi, fallback kullanılıyor:', edgeFnErr);
  }

  // ── Yol 2: Doğrudan Gemini API (Fallback — Geliştirme) ───
  return getSmartCoachAdviceFallback(food, portion, userProfile);
}

/**
 * Fallback: Doğrudan Gemini API çağrısı.
 * ⚠️ Bu yol API key'i client-side'da açığa çıkarır.
 * Sadece Edge Function deploy edilene kadar kullanılmalıdır.
 */
async function getSmartCoachAdviceFallback(
  food: Food,
  portion: number,
  userProfile?: UserHealthProfile | null,
): Promise<CoachPairing | null> {
  if (!GEMINI_API_KEY) {
    console.warn("Gemini API key is missing. Using fallback logic.");
    return null;
  }

  // Kişisel bağlam oluştur
  let personalContext = '';
  if (userProfile) {
    const bmi = calculateBMI(userProfile.weightKg, userProfile.heightCm);
    const bmiInfo = getBmiCategory(bmi);
    const age = new Date().getFullYear() - userProfile.birthYear;

    personalContext = `
KULLANICININ KİŞİSEL PROFİLİ:
- Yaş: ${age}, Cinsiyet: ${userProfile.gender === 'erkek' ? 'Erkek' : 'Kadın'}
- Boy: ${userProfile.heightCm}cm, Kilo: ${userProfile.weightKg}kg
- VKİ: ${bmi} (${bmiInfo.label})
- Diyabet Durumu: ${DIABETES_TYPE_LABELS[userProfile.diabetesType]}
${userProfile.hba1c ? `- Son HbA1c: %${userProfile.hba1c}` : ''}
${userProfile.fastingGlucose ? `- Açlık Kan Şekeri: ${userProfile.fastingGlucose} mg/dL` : ''}
- Aktivite: ${ACTIVITY_LEVEL_LABELS[userProfile.activityLevel]}

Bu kişinin durumuna ÖZEL tavsiye ver. Örneğin:
- Tip 2 diyabet hastasıysa insülin direncini azaltacak öneriler sun.
- VKİ yüksekse porsiyon küçültme veya düşük kalorili alternatif öner.
- HbA1c yüksekse daha sıkı kontrol mesajları ver.
- Gestasyonel diyabetse hamileliğe uygun güvenli alternatiflere yönlendir.
- Sedanterse yemek sonrası hafif yürüyüş önerebilirsin.
`;
  }

  const prompt = `
Sen "GlikoFit" uygulamasının uzman diyetisyeni ve kişisel koçusun. Sıcakkanlı, empatik ve bilgi dolu bir yaklaşımın var.
${personalContext}
Kullanıcı şu yiyeceği kaydetti ve sistem KIRMIZI alarm verdi:
- Besin: ${food.name}
- Kategori: ${food.category}
- Glisemik İndeks: ${food.gi_value}
- 100g Karbonhidrat: ${food.carbs_per_100g}g
- Yenilen Porsiyon: ${portion} gram

GÖREV: Bu besini hayatından çıkarmasını söyleme. Kan şekerini akıllıca dengeleyebileceği çok spesifik, kişiye özel ve kısa bir tavsiye ver (en fazla 2-3 cümle). Yanına ekleyebileceği dengeleyici bir besin veya kategori öner. Adını kullanma. Asla kendini yapay zeka/asistan olarak tanıtma.

JSON formatında hiçbir dış metin bırakmadan SADECE şu yapıyı döndür:
{
  "high_risk_category": "${food.category}",
  "balancer_category": "Örn: Ceviz, Ayran, Yoğurt, Çiğ Badem, Yürüyüş vb.",
  "advice_text": "Kişiye özel, empatik ve pratik tavsiye metni."
}
`;

  try {
    const response = await fetch(API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: { temperature: 0.7 },
      }),
    });

    const data = await response.json();
    if (data.candidates && data.candidates[0]?.content?.parts[0]?.text) {
      const rawText = data.candidates[0].content.parts[0].text;
      const jsonStart = rawText.indexOf('{');
      const jsonEnd = rawText.lastIndexOf('}');
      const cleanJson = rawText.substring(jsonStart, jsonEnd + 1);
      
      const parsed = JSON.parse(cleanJson);
      return {
        id: Math.floor(Math.random() * 100000),
        high_risk_category: parsed.high_risk_category || food.category,
        balancer_category: parsed.balancer_category || "Protein/Yağ",
        advice_text: parsed.advice_text || "Bu porsiyonun yanına kan şekerini dengeleyecek bir miktar protein veya sağlıklı yağ eklemeyi unutma.",
        created_at: new Date().toISOString()
      };
    }
    return null;
  } catch (error) {
    console.error("Gemini AI API Error:", error);
    return null;
  }
}
