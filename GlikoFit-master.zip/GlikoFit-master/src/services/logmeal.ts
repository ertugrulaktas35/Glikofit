// ============================================================
// 📸 LogMeal API v2 — Gerçek Response Yapısına Göre Düzeltilmiş
// ============================================================
// Segmentation: /v2/image/segmentation/complete
//   → segmentation_results[].recognition_results[] { name, prob }
//   → imageId (top-level)
//
// Nutrition: /v2/nutrition/recipe/nutritionalInfo
//   → nutritional_info.calories (float)
//   → nutritional_info.totalNutrients { CHOCDF, PROCNT, FAT, FIBTG, SUGAR, ... }
//   → serving_size (float)
//
// GI: LogMeal vermez → Supabase foods tablosundan eşleştir
// ============================================================

import { supabase } from '../lib/supabase';

const API_KEY  = process.env.EXPO_PUBLIC_LOGMEAL_API_KEY ?? '';
const BASE_URL = 'https://api.logmeal.com/v2';

// ── Tip Tanımları ────────────────────────────────────────────

export interface LogMealFood {
  name: string;
  confidence: number;  // 0-1
  imageId: number;
  classId?: number;
}

export interface LogMealNutrition {
  calories:    number;
  carbs:       number;
  protein:     number;
  fat:         number;
  fiber:       number;
  sugar:       number;
  servingSize: number;  // gram
}

export interface LogMealResult {
  foods:     LogMealFood[];
  nutrition: LogMealNutrition;
  gi:        number;        // Supabase veya tahminle hesaplanır
  rawFood:   string;
  occasion?: string;        // breakfast | lunch | dinner | snack
}

// ── Nutrient code → quantity çekme ───────────────────────────

function nutrientQ(totalNutrients: any, code: string): number {
  const v = totalNutrients?.[code]?.quantity;
  return typeof v === 'number' && !isNaN(v) ? Math.round(v * 10) / 10 : 0;
}

// ── Supabase'ten GI Arama ────────────────────────────────────

async function lookupGI(foodName: string): Promise<number | null> {
  if (!foodName) return null;
  try {
    // Tam eşleşme dene
    const { data: exact } = await supabase
      .from('foods')
      .select('gi_value')
      .ilike('name', foodName)
      .limit(1)
      .single();
    const exactRow = exact as { gi_value: number } | null;
    if (exactRow?.gi_value) return exactRow.gi_value;

    // İlk kelimeyle dene
    const keyword = foodName.split(/[\s,]/)[0];
    if (keyword && keyword.length > 2) {
      const { data: fuzzy } = await supabase
        .from('foods')
        .select('gi_value')
        .ilike('name', `%${keyword}%`)
        .order('gi_value', { ascending: true })
        .limit(1)
        .single();
      const fuzzyRow = fuzzy as { gi_value: number } | null;
      if (fuzzyRow?.gi_value) return fuzzyRow.gi_value;
    }
  } catch { /* yok */ }
  return null;
}

// ── GI Tahmini (Supabase'te bulunamazsa) ─────────────────────

export function estimateGI(foodName: string): number {
  const n = (foodName ?? '').toLowerCase();

  // Düşük GI (≤55) — protein/yağ ağırlıklı
  if (/salad|salata|egg|yumurta|meat|beef|et|chicken|tavuk|fish|balık|seafood|deniz/.test(n)) return 35;
  if (/cheese|peynir|yogurt|yoğurt|milk|süt|nuts?|fındık|ceviz|badem|kaju/.test(n)) return 30;
  if (/lentil|mercimek|bean|fasulye|chickpea|nohut|legume|baklagil/.test(n)) return 40;
  if (/broccoli|brokoli|spinach|ıspanak|lettuce|marul|cucumber|salatalık|tomato|domates/.test(n)) return 20;

  // Orta GI (56-69)
  if (/rice|pilav|pasta|makarna|noodle/.test(n)) return 60;
  if (/bread|ekmek|pita|pide|toast|tost/.test(n)) return 65;
  if (/potato|patates|corn|mısır|soup|çorba/.test(n)) return 62;
  if (/pizza|burger|sandwich|sandviç/.test(n)) return 60;
  if (/fruit|meyve|apple|elma|orange|portakal|banana|muz|grape|üzüm/.test(n)) return 52;
  if (/oat|yulaf|muesli|müsli|granola/.test(n)) return 55;

  // Yüksek GI (≥70)
  if (/sweet|candy|şeker|chocolate|çikolata|cake|kek|cookie|kurabiye/.test(n)) return 75;
  if (/soda|cola|juice|meyve suyu|ice cream|dondurma|waffle/.test(n)) return 78;
  if (/white rice|beyaz pirinç|cornflakes/.test(n)) return 80;

  return 55; // varsayılan orta GI
}

// ── 1. Fotoğraf → Yemek Tanıma ───────────────────────────────

export async function recognizeFood(imageUri: string): Promise<{
  foods: LogMealFood[];
  occasion?: string;
}> {
  if (!API_KEY) throw new Error('LogMeal API anahtarı eksik. .env dosyasını kontrol edin.');

  const formData = new FormData();
  formData.append('image', {
    uri:  imageUri,
    type: 'image/jpeg',
    name: 'food.jpg',
  } as any);

  const response = await fetch(`${BASE_URL}/image/segmentation/complete`, {
    method:  'POST',
    headers: { Authorization: `Bearer ${API_KEY}` },
    body:    formData,
  });

  if (response.status === 401) throw new Error('API anahtarı geçersiz veya süresi dolmuş.');
  if (response.status === 429) throw new Error('API istek limiti aşıldı. Birkaç saniye bekleyin.');
  if (!response.ok) {
    const txt = await response.text().catch(() => '');
    throw new Error(`Sunucu hatası (${response.status})${txt ? ': ' + txt.slice(0, 120) : ''}`);
  }

  const data = await response.json();

  // top-level imageId
  const imageId: number = data?.imageId ?? data?.image_id ?? 0;
  const occasion: string | undefined = data?.occasion;
  const foods: LogMealFood[] = [];

  // Birincil format: segmentation_results[].recognition_results[]
  if (Array.isArray(data?.segmentation_results) && data.segmentation_results.length > 0) {
    for (const seg of data.segmentation_results) {
      const recs: any[] = seg?.recognition_results ?? [];
      for (const rec of recs) {
        const name = rec?.name ?? rec?.class_name ?? rec?.dish_name;
        if (name) {
          foods.push({
            name,
            confidence: rec?.prob ?? rec?.probability ?? 0,
            imageId,
            classId: rec?.id,
          });
        }
      }
    }
  }
  // Fallback: foodName array (eski format)
  else if (Array.isArray(data?.foodName) && data.foodName.length > 0) {
    data.foodName.forEach((name: string, i: number) => {
      foods.push({
        name,
        confidence: Array.isArray(data.probs) ? (data.probs[i] ?? 0) : 0,
        imageId,
      });
    });
  }

  if (foods.length === 0) {
    throw new Error('Yemek tespit edilemedi. Daha yakından ve iyi aydınlatılmış bir fotoğraf deneyin.');
  }

  return {
    foods: foods.sort((a, b) => b.confidence - a.confidence),
    occasion,
  };
}

// ── 2. imageId → Besin Değerleri ─────────────────────────────

export async function getNutrition(imageId: number): Promise<LogMealNutrition> {
  if (!API_KEY) throw new Error('LogMeal API anahtarı eksik.');

  const response = await fetch(`${BASE_URL}/nutrition/recipe/nutritionalInfo`, {
    method:  'POST',
    headers: {
      Authorization:  `Bearer ${API_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ imageId }),
  });

  if (response.status === 402) throw new Error('Bu özellik için plan yükseltmesi gerekiyor.');
  if (!response.ok) {
    const txt = await response.text().catch(() => '');
    throw new Error(`Besin bilgisi alınamadı (${response.status})${txt ? ': ' + txt.slice(0, 120) : ''}`);
  }

  const data = await response.json();

  // Gerçek response yapısı:
  // nutritional_info.calories (float)
  // nutritional_info.totalNutrients.CHOCDF.quantity  → karbonhidrat
  // nutritional_info.totalNutrients.PROCNT.quantity  → protein
  // nutritional_info.totalNutrients.FAT.quantity     → yağ
  // nutritional_info.totalNutrients.FIBTG.quantity   → lif
  // nutritional_info.totalNutrients.SUGAR.quantity   → şeker
  // serving_size (float, gram)

  const info    = data?.nutritional_info ?? data?.nutritional_info_per_item?.[0]?.nutritional_info ?? {};
  const totN    = info?.totalNutrients ?? {};
  const serving = data?.serving_size ?? data?.nutritional_info_per_item?.[0]?.serving_size ?? 200;

  // ENERC_KCAL veya calories direkt olabilir
  const calories = typeof info?.calories === 'number'
    ? info.calories
    : nutrientQ(totN, 'ENERC_KCAL');

  return {
    calories:    Math.round(calories * 10) / 10,
    carbs:       nutrientQ(totN, 'CHOCDF'),
    protein:     nutrientQ(totN, 'PROCNT'),
    fat:         nutrientQ(totN, 'FAT'),
    fiber:       nutrientQ(totN, 'FIBTG'),
    sugar:       nutrientQ(totN, 'SUGAR'),
    servingSize: typeof serving === 'number' ? Math.round(serving) : 200,
  };
}

// ── 3. Tam Analiz: Fotoğraf → Sonuç ──────────────────────────

export async function analyzeFoodPhoto(imageUri: string): Promise<LogMealResult> {
  // Adım 1: Yemek tanı
  const { foods, occasion } = await recognizeFood(imageUri);
  const topFood = foods[0];

  // Adım 2: Makro değerler
  let nutrition: LogMealNutrition;
  try {
    nutrition = await getNutrition(topFood.imageId);
  } catch (err: any) {
    // Makro alınamazsa sıfırla — UI'da uyarı gösterilir
    console.warn('LogMeal nutrition error:', err?.message);
    nutrition = { calories: 0, carbs: 0, protein: 0, fat: 0, fiber: 0, sugar: 0, servingSize: 200 };
  }

  // Adım 3: GI — önce Supabase, sonra tahmin
  let gi = await lookupGI(topFood.name);
  if (!gi) gi = estimateGI(topFood.name);

  return { foods, nutrition, gi, rawFood: topFood.name, occasion };
}
