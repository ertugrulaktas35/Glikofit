// ============================================================
// 🧩 Bileşenler — Barrel Export
// ============================================================
// Bu klasör yeniden kullanılabilir UI bileşenleri için ayrılmıştır.
// Örnek: TrafficLightBadge, PortionSlider, PremiumBanner, FoodCard
// ============================================================

export {};
