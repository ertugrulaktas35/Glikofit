import React, { useEffect, useState } from 'react';
import { View, Text, Dimensions, StyleSheet, ActivityIndicator } from 'react-native';
import { BarChart } from 'react-native-chart-kit';
import { supabase } from '../../lib/supabase';

const screenWidth = Dimensions.get('window').width;

const DAY_LABELS = ['Pzt', 'Sal', 'Çar', 'Per', 'Cum', 'Cmt', 'Paz'];

function getLast7Days(): { date: string; label: string }[] {
  const days: { date: string; label: string }[] = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const iso = d.toISOString().split('T')[0];
    const dayIdx = d.getDay();
    const label = i === 0 ? 'Bugün' : DAY_LABELS[(dayIdx + 6) % 7];
    days.push({ date: iso, label });
  }
  return days;
}

export function GlTrendChart() {
  const [glByDay, setGlByDay] = useState<number[]>([]);
  const [labels, setLabels] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;

    async function fetchWeeklyGL() {
      const days = getLast7Days();
      const startDate = days[0].date;

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) { setLoading(false); return; }

      const { data } = await supabase
        .from('consumption_logs')
        .select('calculated_gl, logged_at')
        .eq('user_id', user.id)
        .gte('logged_at', `${startDate}T00:00:00`)
        .order('logged_at', { ascending: true });

      if (!mounted) return;

      const totals: Record<string, number> = {};
      days.forEach(d => { totals[d.date] = 0; });

      (data ?? []).forEach((row: { calculated_gl: number; logged_at: string }) => {
        const day = row.logged_at.split('T')[0];
        if (totals[day] !== undefined) {
          totals[day] += row.calculated_gl;
        }
      });

      setLabels(days.map(d => d.label));
      setGlByDay(days.map(d => Math.round(totals[d.date] * 10) / 10));
      setLoading(false);
    }

    fetchWeeklyGL();
    return () => { mounted = false; };
  }, []);

  if (loading) {
    return (
      <View style={[styles.container, { alignItems: 'center', paddingVertical: 32 }]}>
        <ActivityIndicator size="small" color="#10B981" />
      </View>
    );
  }

  const hasData = glByDay.some(v => v > 0);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Haftalık Glisemik Yük (GL)</Text>
      {hasData ? (
        <View style={styles.chartContainer}>
          <BarChart
            data={{ labels, datasets: [{ data: glByDay }] }}
            width={screenWidth - 48}
            height={200}
            yAxisLabel=""
            yAxisSuffix=""
            chartConfig={chartConfig}
            verticalLabelRotation={0}
            fromZero
            withInnerLines
            showBarTops={false}
            style={styles.chart}
          />
        </View>
      ) : (
        <View style={[styles.chartContainer, { alignItems: 'center', justifyContent: 'center', height: 120 }]}>
          <Text style={{ fontSize: 14, color: '#A0A0A0', textAlign: 'center' }}>
            Henüz bu haftaya ait veri yok.{'\n'}Besin ekledikçe grafik dolacak.
          </Text>
        </View>
      )}
    </View>
  );
}

const chartConfig = {
  backgroundGradientFrom: '#FFFFFF',
  backgroundGradientTo: '#FFFFFF',
  color: (opacity = 1) => `rgba(13, 110, 91, ${opacity})`,
  labelColor: (opacity = 1) => `rgba(102, 102, 102, ${opacity})`,
  strokeWidth: 2,
  barPercentage: 0.6,
  useShadowColorFromDataset: false,
  fillShadowGradientOpacity: 1,
  fillShadowGradientFrom: '#0D6E5B',
  fillShadowGradientTo: '#059669',
  decimalPlaces: 0,
};

const styles = StyleSheet.create({
  container: {
    marginTop: 20,
    width: '100%',
  },
  title: {
    fontSize: 17,
    fontWeight: '800',
    color: '#1A1A1A',
    marginBottom: 12,
  },
  chartContainer: {
    backgroundColor: '#FFF',
    borderRadius: 16,
    paddingVertical: 16,
    paddingRight: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 3,
  },
  chart: {
    borderRadius: 16,
  },
});
