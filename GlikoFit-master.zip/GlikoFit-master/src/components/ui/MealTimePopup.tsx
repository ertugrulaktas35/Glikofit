import React, { useEffect, useRef } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet,
  Animated, Easing, Dimensions,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

const { width: SW } = Dimensions.get('window');

// ── Öğün Vakti Hesaplama ──────────────────────────────────────

interface MealHint {
  icon: string;
  title: string;
  message: string;
  gradient: [string, string];
  accent: string;
}

function getMealHint(hour: number): MealHint | null {
  // Gece — popup gösterme
  if (hour < 6 || hour >= 23) return null;

  if (hour >= 6 && hour < 9) return {
    icon: '🌅',
    title: 'Kahvaltı Vakti!',
    message: 'Güne doğru başla. Kahvaltını kaydettikten sonra kan şekeri takibini yapalım.',
    gradient: ['#F59E0B', '#D97706'],
    accent: '#FEF3C7',
  };
  if (hour >= 9 && hour < 11) return {
    icon: '☀️',
    title: 'Kahvaltı Yaptın mı?',
    message: 'Kahvaltını henüz kaydetmediysen Öğünler sayfasına geç, unutma!',
    gradient: ['#F97316', '#EA580C'],
    accent: '#FFF7ED',
  };
  if (hour >= 11 && hour < 13) return {
    icon: '🍽️',
    title: 'Öğle Yaklaşıyor!',
    message: 'Öğle yemeğine ne yemek istiyorsun? Glisemik yükü düşük seçeneklere bak.',
    gradient: ['#10B981', '#059669'],
    accent: '#ECFDF5',
  };
  if (hour >= 13 && hour < 15) return {
    icon: '☀️',
    title: 'Öğle Yemekleri Zamanı!',
    message: 'Yediğin yemekleri kaydet. Günlük GL takibin devam etsin.',
    gradient: ['#0D7A6B', '#065F46'],
    accent: '#F0FDF4',
  };
  if (hour >= 15 && hour < 17) return {
    icon: '🫖',
    title: 'Ara Öğün Molası',
    message: 'Kan şekerini dengede tutmak için sağlıklı bir ara öğün iyi olabilir.',
    gradient: ['#8B5CF6', '#7C3AED'],
    accent: '#EDE9FE',
  };
  if (hour >= 17 && hour < 19) return {
    icon: '🌆',
    title: 'Akşam Yemeği Hazırlığı',
    message: 'Akşam yemeği için diyabet dostu tariflerimize göz at.',
    gradient: ['#6366F1', '#4F46E5'],
    accent: '#EEF2FF',
  };
  if (hour >= 19 && hour < 21) return {
    icon: '🌙',
    title: 'Akşam Yemeği Vakti!',
    message: 'Ne yiyorsun bu akşam? Yemeklerini kaydetmeyi unutma.',
    gradient: ['#1E3A5F', '#2563EB'],
    accent: '#EFF6FF',
  };
  if (hour >= 21 && hour < 23) return {
    icon: '📝',
    title: 'Günü Tamamla',
    message: 'Akşam yemeğini kaydettiysen harika! Günlük raporunu görmek ister misin?',
    gradient: ['#374151', '#1F2937'],
    accent: '#F9FAFB',
  };
  return null;
}

// ── Bileşen ───────────────────────────────────────────────────

interface Props {
  visible: boolean;
  onClose: () => void;
  onNavigate: () => void;
}

export default function MealTimePopup({ visible, onClose, onNavigate }: Props) {
  const insets  = useSafeAreaInsets();
  const slideY  = useRef(new Animated.Value(-200)).current;
  const opacity = useRef(new Animated.Value(0)).current;
  const scale   = useRef(new Animated.Value(0.8)).current;

  const hour = new Date().getHours();
  const hint = getMealHint(hour);

  useEffect(() => {
    if (visible && hint) {
      Animated.parallel([
        Animated.spring(slideY, {
          toValue: 0,
          tension: 65,
          friction: 10,
          useNativeDriver: true,
        }),
        Animated.timing(opacity, {
          toValue: 1,
          duration: 300,
          easing: Easing.out(Easing.cubic),
          useNativeDriver: true,
        }),
        Animated.spring(scale, {
          toValue: 1,
          tension: 65,
          friction: 10,
          useNativeDriver: true,
        }),
      ]).start();

      // 6 saniye sonra otomatik kapat
      const timer = setTimeout(() => {
        hidePopup();
      }, 6000);
      return () => clearTimeout(timer);
    } else {
      slideY.setValue(-200);
      opacity.setValue(0);
      scale.setValue(0.8);
    }
  }, [visible]);

  const hidePopup = () => {
    Animated.parallel([
      Animated.timing(slideY, {
        toValue: -200,
        duration: 250,
        easing: Easing.in(Easing.cubic),
        useNativeDriver: true,
      }),
      Animated.timing(opacity, {
        toValue: 0,
        duration: 200,
        useNativeDriver: true,
      }),
    ]).start(() => onClose());
  };

  if (!visible || !hint) return null;

  return (
    <Animated.View
      style={[
        styles.container,
        {
          top: insets.top + 10,
          right: 16,
          opacity,
          transform: [{ translateY: slideY }, { scale }],
        },
      ]}
      pointerEvents="box-none"
    >
      {/* Yarım daire dekoratif arka plan */}
      <View style={styles.halfCircle} pointerEvents="none" />

      <LinearGradient
        colors={hint.gradient}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.card}
      >
        {/* Kapat butonu */}
        <TouchableOpacity onPress={hidePopup} style={styles.closeBtn} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
          <Ionicons name="close" size={14} color="rgba(255,255,255,0.9)" />
        </TouchableOpacity>

        {/* İkon */}
        <View style={styles.iconWrap}>
          <Text style={{ fontSize: 28 }}>{hint.icon}</Text>
        </View>

        {/* Başlık */}
        <Text style={styles.title}>{hint.title}</Text>

        {/* Mesaj */}
        <Text style={styles.message}>{hint.message}</Text>

        {/* Buton */}
        <TouchableOpacity
          onPress={() => { hidePopup(); onNavigate(); }}
          style={styles.actionBtn}
          activeOpacity={0.85}
        >
          <Text style={styles.actionBtnText}>Öğüne Git</Text>
          <Ionicons name="arrow-forward" size={14} color={hint.gradient[0]} style={{ marginLeft: 4 }} />
        </TouchableOpacity>
      </LinearGradient>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    right: 16,
    zIndex: 9999,
    width: SW * 0.72,
    maxWidth: 300,
  },
  halfCircle: {
    position: 'absolute',
    top: -30,
    right: -30,
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: 'rgba(255,255,255,0.12)',
    zIndex: -1,
  },
  card: {
    borderRadius: 24,
    padding: 18,
    paddingTop: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 12 },
    shadowOpacity: 0.25,
    shadowRadius: 20,
    elevation: 16,
    overflow: 'hidden',
  },
  closeBtn: {
    position: 'absolute',
    top: 12,
    right: 12,
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: 'rgba(0,0,0,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 1,
  },
  iconWrap: {
    width: 52,
    height: 52,
    borderRadius: 26,
    backgroundColor: 'rgba(255,255,255,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  title: {
    fontSize: 16,
    fontWeight: '900',
    color: '#FFFFFF',
    marginBottom: 6,
    lineHeight: 20,
  },
  message: {
    fontSize: 12,
    fontWeight: '500',
    color: 'rgba(255,255,255,0.85)',
    lineHeight: 17,
    marginBottom: 14,
  },
  actionBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 12,
  },
  actionBtnText: {
    fontSize: 13,
    fontWeight: '800',
    color: '#0F172A',
  },
});
