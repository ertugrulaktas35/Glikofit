import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import type { CoachPairing } from '../../types/database';

interface Props {
  advice: CoachPairing;
}

export function CoachAdviceCard({ advice }: Props) {
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View style={styles.iconContainer}>
          <Ionicons name="bulb" size={24} color="#F5A623" />
        </View>
        <Text style={styles.title}>Akıllı Dengeleyici Koç</Text>
      </View>
      <Text style={styles.text}>{advice.advice_text}</Text>
      <View style={styles.badgeContainer}>
        <Text style={styles.badgeText}>Dengeleyici: {advice.balancer_category}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#FFF8E1',
    borderRadius: 16,
    padding: 20,
    marginTop: 0,
    marginBottom: 14,
    borderWidth: 1,
    borderColor: '#FFD54F',
    shadowColor: '#FFD54F',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 3,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  iconContainer: {
    backgroundColor: '#FFE082',
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  title: {
    fontSize: 18,
    fontWeight: '800',
    color: '#E65100',
  },
  text: {
    fontSize: 16,
    color: '#5D4037',
    lineHeight: 24,
    marginBottom: 12,
  },
  badgeContainer: {
    backgroundColor: '#1DB87A',
    alignSelf: 'flex-start',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 12,
  },
  badgeText: {
    color: '#FFF',
    fontWeight: '700',
    fontSize: 14,
  },
});
