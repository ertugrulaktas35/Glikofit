import React, { useEffect, useRef, useState } from 'react';
import {
  View, Text, Modal, TouchableOpacity, StyleSheet,
  Animated, Easing, ScrollView, TextInput, Dimensions,
  KeyboardAvoidingView, Platform,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Svg, {
  Defs, ClipPath, Path, Rect, Ellipse,
  LinearGradient as SvgLinearGradient, Stop, G,
} from 'react-native-svg';
import { useHealthStore } from '../../store/useHealthStore';

const AnimatedRect = Animated.createAnimatedComponent(Rect);

const { width: SW } = Dimensions.get('window');

// ── Sabitler ─────────────────────────────────────────────────

const QUICK_AMOUNTS = [
  { label: 'Yudum',  ml: 75,  emoji: '💧' },
  { label: 'Bardak', ml: 200, emoji: '🥛' },
  { label: 'Büyük',  ml: 350, emoji: '🫗' },
  { label: 'Şişe',   ml: 500, emoji: '🍶' },
];

const HYDRATION_TIPS = [
  { icon: '🩸', text: 'Su içmek kan şekerini seyreltir ve böbreklerin glukozu atmasına yardımcı olur.' },
  { icon: '💊', text: 'Dehidrasyon insülin direncini artırır — her saat başı bir yudum alışkanlık edinin.' },
  { icon: '🧠', text: 'Vücudunuzun %2\'si bile su kaybetse bilişsel performansınız düşer.' },
  { icon: '🏃', text: 'Egzersiz öncesi 400ml, sonrası 500ml içmek kas glikozunun kullanımını optimize eder.' },
  { icon: '🌡️', text: 'Sıcak havalarda su ihtiyacınız %30-40 artar. Idrar rengi en iyi göstergedir.' },
  { icon: '🍋', text: 'Suya limon eklemek GI\'yi sıfır tutarak tatlandırır ve metabolizmayı destekler.' },
];

function getMotiMessage(pct: number, target: number): { title: string; sub: string; emoji: string } {
  if (pct >= 100) return { emoji: '🏆', title: 'Hedefe ulaştın!', sub: `${(target / 1000).toFixed(1)}L tamamlandı. Muhteşem bir gün!` };
  if (pct >= 75)  return { emoji: '💪', title: 'Neredeyse tamam!', sub: 'Son düzlüğe girdin. Biraz daha!' };
  if (pct >= 50)  return { emoji: '⚡', title: 'Yarı yoldasın!', sub: 'İyi gidiyorsun, devam et.' };
  if (pct >= 25)  return { emoji: '🌱', title: 'Güzel başlangıç!', sub: 'Düzenli içmeye devam et.' };
  return { emoji: '💧', title: 'Su içme zamanı!', sub: 'Kan şekerini dengelemek için su iç.' };
}

// ── SVG Bardak (WaterGlassWidget ile aynı tasarım, modal için büyük) ───

// WaterGlassWidget ile aynı path'ler
const OUTER = `M5,0 L57,0 L53,78 Q53,88 45,88 L17,88 Q9,88 9,78 L5,0 Z`;
const INNER = `M9,0 L53,0 L49,76 Q49,82 43,82 L19,82 Q13,82 13,76 L9,0 Z`;
const VW = 62;
const VH = 88;
const WATER_TOP    = 2;
const WATER_BOTTOM = 82;
const WATER_MAX_H  = WATER_BOTTOM - WATER_TOP;

// Modal'da büyük render boyutu (viewBox aynı kalır, SVG scale yapar)
const MODAL_W = 96;
const MODAL_H = 136;

function WaterGlass({ pct }: { pct: number }) {
  const fillAnim = useRef(new Animated.Value(0)).current;
  const waveAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.timing(fillAnim, {
      toValue: Math.min(pct, 100) / 100,
      duration: 1000,
      easing: Easing.out(Easing.exp),
      useNativeDriver: false,
    }).start();
  }, [pct]);

  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(waveAnim, { toValue: 1, duration: 2000, easing: Easing.inOut(Easing.sin), useNativeDriver: false }),
        Animated.timing(waveAnim, { toValue: 0, duration: 2000, easing: Easing.inOut(Easing.sin), useNativeDriver: false }),
      ])
    ).start();
  }, []);

  const fillH = fillAnim.interpolate({ inputRange: [0, 1], outputRange: [0, WATER_MAX_H] });
  const fillY = fillAnim.interpolate({ inputRange: [0, 1], outputRange: [WATER_BOTTOM, WATER_TOP] });
  const waveX = waveAnim.interpolate({ inputRange: [0, 1], outputRange: [0, 5] });

  const waterTopColor    = pct >= 80 ? '#38BDF8' : pct >= 50 ? '#7DD3FC' : '#BAE6FD';
  const waterBottomColor = pct >= 80 ? '#0284C7' : pct >= 50 ? '#0EA5E9' : '#38BDF8';

  return (
    <View style={{ alignItems: 'center', marginBottom: 8 }}>
      <View style={{ width: MODAL_W, height: MODAL_H, position: 'relative' }}>
        <Svg width={MODAL_W} height={MODAL_H} viewBox={`0 0 ${VW} ${VH}`}>
          <Defs>
            <ClipPath id="modalInner">
              <Path d={INNER} />
            </ClipPath>
            <SvgLinearGradient id="mwg" x1="0" y1="0" x2="0" y2="1">
              <Stop offset="0" stopColor={waterTopColor}    stopOpacity="0.9" />
              <Stop offset="1" stopColor={waterBottomColor} stopOpacity="1"   />
            </SvgLinearGradient>
            <SvgLinearGradient id="mbg" x1="0" y1="0" x2="1" y2="0">
              <Stop offset="0"    stopColor="#6AAEE8" stopOpacity="1" />
              <Stop offset="0.45" stopColor="#4A8ED4" stopOpacity="1" />
              <Stop offset="1"    stopColor="#3578C0" stopOpacity="1" />
            </SvgLinearGradient>
            <SvgLinearGradient id="mig" x1="0" y1="0" x2="1" y2="0">
              <Stop offset="0" stopColor="#5BA3E2" stopOpacity="1" />
              <Stop offset="1" stopColor="#4490D5" stopOpacity="1" />
            </SvgLinearGradient>
          </Defs>

          {/* Dış cam gövdesi */}
          <Path d={OUTER} fill="url(#mbg)" />

          {/* İç arka plan */}
          <G clipPath="url(#modalInner)">
            <Rect x="0" y="0" width={VW} height={VH} fill="url(#mig)" />
          </G>

          {/* Animasyonlu su */}
          <G clipPath="url(#modalInner)">
            <AnimatedRect x="0" y={fillY} width={VW} height={fillH} fill="url(#mwg)" />
            <AnimatedRect x={waveX} y={fillY} width={VW} height="3.5" rx="1.5" fill="rgba(255,255,255,0.48)" />
          </G>

          {/* Sol yansıma şeridi */}
          <G clipPath="url(#modalInner)">
            <Ellipse cx="18" cy="41" rx="6"   ry="34" fill="rgba(255,255,255,0.50)" />
            <Ellipse cx="16" cy="40" rx="2.5" ry="27" fill="rgba(255,255,255,0.30)" />
          </G>

          {/* Sağ kenar gölgesi */}
          <G clipPath="url(#modalInner)">
            <Ellipse cx="47" cy="44" rx="4" ry="36" fill="rgba(0,0,0,0.18)" />
          </G>

          {/* Üst ağız parlaması */}
          <Path d="M9,0 L53,0 L51,7 L11,7 Z" fill="rgba(255,255,255,0.08)" />

          {/* Dış kontur */}
          <Path d={OUTER} fill="none" stroke="rgba(255,255,255,0.22)" strokeWidth="1.2" />
        </Svg>

        {/* Yüzde overlay */}
        <View style={styles.glassPctWrap} pointerEvents="none">
          <View style={styles.glassPctPill}>
            <Text style={styles.glassPct}>
              {pct >= 100 ? '✓' : `${Math.round(pct)}%`}
            </Text>
          </View>
        </View>
      </View>

      <Text style={{ fontSize: 12, fontWeight: '700', color: '#64748B', marginTop: 8 }}>
        Doluluk Seviyesi
      </Text>
    </View>
  );
}

// ── Ana Modal Bileşeni ────────────────────────────────────────

interface Props {
  visible: boolean;
  onClose: () => void;
  userId: string;
  weightKg: number;
}

export default function WaterModal({ visible, onClose, userId, weightKg }: Props) {
  const insets = useSafeAreaInsets();
  const { todayWaterMl, todayWaterEntries, addWater } = useHealthStore();
  const [adding, setAdding]       = useState(false);
  const [customMl, setCustomMl]   = useState('');
  const [tipIndex, setTipIndex]   = useState(0);
  const slideY = useRef(new Animated.Value(600)).current;

  const dailyTarget = Math.round(weightKg * 30);
  const pct         = Math.min(100, (todayWaterMl / dailyTarget) * 100);
  const moti        = getMotiMessage(pct, dailyTarget);
  const tip         = HYDRATION_TIPS[tipIndex % HYDRATION_TIPS.length];

  useEffect(() => {
    if (visible) {
      Animated.spring(slideY, {
        toValue: 0,
        tension: 55,
        friction: 10,
        useNativeDriver: true,
      }).start();
      const t = setInterval(() => setTipIndex(i => i + 1), 5000);
      return () => clearInterval(t);
    } else {
      slideY.setValue(600);
    }
  }, [visible]);

  const handleClose = () => {
    Animated.timing(slideY, {
      toValue: 600,
      duration: 280,
      easing: Easing.in(Easing.cubic),
      useNativeDriver: true,
    }).start(() => onClose());
  };

  const handleAdd = async (ml: number) => {
    if (adding || ml <= 0) return;
    setAdding(true);
    await addWater(userId, ml);
    setAdding(false);
    setCustomMl('');
  };

  const handleCustomAdd = () => {
    const ml = parseInt(customMl, 10);
    if (!isNaN(ml) && ml > 0) handleAdd(ml);
  };

  // Saate göre hedef uyarısı
  const hour = new Date().getHours();
  let timeHint = '';
  if (hour >= 6  && hour < 9)  timeHint = '☀️ Sabah 1-2 bardak içmek metabolizmayı hemen aktive eder.';
  if (hour >= 12 && hour < 14) timeHint = '🍽️ Öğle yemeği öncesi 1 bardak içmen kan şekeri yükselişini yavaşlatır.';
  if (hour >= 15 && hour < 17) timeHint = '⚡ Öğleden sonra enerjini canlı tut — bir bardak su iç!';
  if (hour >= 18 && hour < 20) timeHint = '🌙 Akşam yemeği öncesi su içmek gece açlığını azaltır.';

  return (
    <Modal visible={visible} transparent animationType="none" onRequestClose={handleClose}>
      {/* Arka plan */}
      <TouchableOpacity style={styles.backdrop} activeOpacity={1} onPress={handleClose} />

      <Animated.View style={[styles.sheet, { paddingBottom: insets.bottom + 16, transform: [{ translateY: slideY }] }]}>
        {/* Tutamaç */}
        <View style={styles.handle} />

        <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
          <ScrollView showsVerticalScrollIndicator={false} bounces={false}>

            {/* ── Başlık ── */}
            <View style={styles.sheetHeader}>
              <View>
                <Text style={styles.sheetTitle}>💧 Su Takibi</Text>
                <Text style={styles.sheetSub}>Günlük hedef: {(dailyTarget / 1000).toFixed(1)} L</Text>
              </View>
              <TouchableOpacity onPress={handleClose} style={styles.closeBtn}>
                <Ionicons name="close" size={20} color="#64748B" />
              </TouchableOpacity>
            </View>

            {/* ── Bardak + Motivasyon ── */}
            <View style={styles.topRow}>
              <WaterGlass pct={pct} />

              <View style={{ flex: 1, paddingLeft: 20, justifyContent: 'center' }}>
                <View style={[styles.motiBadge, { backgroundColor: pct >= 100 ? '#ECFDF5' : '#EFF6FF' }]}>
                  <Text style={{ fontSize: 28 }}>{moti.emoji}</Text>
                  <View style={{ flex: 1, marginLeft: 10 }}>
                    <Text style={[styles.motiTitle, { color: pct >= 100 ? '#065F46' : '#1E3A5F' }]}>
                      {moti.title}
                    </Text>
                    <Text style={styles.motiSub}>{moti.sub}</Text>
                  </View>
                </View>

                {/* ml sayacı */}
                <View style={styles.mlCounter}>
                  <Text style={styles.mlCurrent}>{todayWaterMl}</Text>
                  <Text style={styles.mlUnit}> / {dailyTarget} ml</Text>
                </View>

                {/* Progress bar */}
                <View style={styles.progressBg}>
                  <Animated.View
                    style={[
                      styles.progressFill,
                      {
                        width: `${pct}%` as any,
                        backgroundColor: pct >= 80 ? '#0369A1' : pct >= 50 ? '#0EA5E9' : '#38BDF8',
                      },
                    ]}
                  />
                </View>
              </View>
            </View>

            {/* ── Zaman ipucu ── */}
            {timeHint ? (
              <View style={styles.timeHint}>
                <Text style={styles.timeHintText}>{timeHint}</Text>
              </View>
            ) : null}

            {/* ── Hızlı Ekle ── */}
            <Text style={styles.sectionTitle}>Hızlı Ekle</Text>
            <View style={styles.quickGrid}>
              {QUICK_AMOUNTS.map(a => (
                <TouchableOpacity
                  key={a.ml}
                  onPress={() => handleAdd(a.ml)}
                  disabled={adding}
                  style={[styles.quickBtn, adding && { opacity: 0.5 }]}
                  activeOpacity={0.75}
                >
                  <LinearGradient
                    colors={['#EFF6FF', '#DBEAFE']}
                    style={styles.quickBtnInner}
                  >
                    <Text style={{ fontSize: 26, marginBottom: 4 }}>{a.emoji}</Text>
                    <Text style={styles.quickBtnLabel}>{a.label}</Text>
                    <Text style={styles.quickBtnMl}>+{a.ml} ml</Text>
                  </LinearGradient>
                </TouchableOpacity>
              ))}
            </View>

            {/* ── Özel Miktar ── */}
            <View style={styles.customRow}>
              <TextInput
                style={styles.customInput}
                placeholder="Özel miktar (ml)"
                placeholderTextColor="#94A3B8"
                keyboardType="numeric"
                value={customMl}
                onChangeText={setCustomMl}
                onSubmitEditing={handleCustomAdd}
                returnKeyType="done"
              />
              <TouchableOpacity
                onPress={handleCustomAdd}
                disabled={adding || !customMl}
                style={[styles.customAddBtn, (!customMl || adding) && { opacity: 0.4 }]}
              >
                <LinearGradient
                  colors={['#0A5748', '#0D7A6B']}
                  start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
                  style={styles.customAddBtnInner}
                >
                  <Ionicons name="add" size={20} color="#FFF" />
                  <Text style={styles.customAddBtnText}>Ekle</Text>
                </LinearGradient>
              </TouchableOpacity>
            </View>

            {/* ── Sağlık İpucu (dönen) ── */}
            <View style={styles.tipCard}>
              <Text style={{ fontSize: 22, marginBottom: 6 }}>{tip.icon}</Text>
              <Text style={styles.tipText}>{tip.text}</Text>
            </View>

            {/* ── Bugünkü kayıtlar ── */}
            {todayWaterEntries.length > 0 && (
              <View style={{ marginTop: 4 }}>
                <Text style={styles.sectionTitle}>Bugünkü Kayıtlar</Text>
                <View style={styles.historyCard}>
                  {[...todayWaterEntries].reverse().slice(0, 6).map((e, i) => {
                    const t = new Date(e.logged_at ?? Date.now());
                    const timeStr = `${t.getHours().toString().padStart(2,'0')}:${t.getMinutes().toString().padStart(2,'0')}`;
                    return (
                      <View
                        key={e.id ?? i}
                        style={[
                          styles.historyRow,
                          i < Math.min(todayWaterEntries.length, 6) - 1 && styles.historyRowBorder,
                        ]}
                      >
                        <View style={styles.historyDot} />
                        <Text style={styles.historyTime}>{timeStr}</Text>
                        <Text style={styles.historyAmount}>+{e.amount_ml} ml</Text>
                        <View style={[styles.historyBar, { width: (e.amount_ml / 500) * 80 }]} />
                      </View>
                    );
                  })}
                </View>
              </View>
            )}

            {/* ── Diyabet & Su bağlantısı ── */}
            <LinearGradient
              colors={['#0A5748', '#0D7A6B']}
              start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
              style={styles.diabetesCard}
            >
              <Text style={styles.diabetesTitle}>Diyabet & Hidrasyon</Text>
              <Text style={styles.diabetesText}>
                Yüksek kan şekeri böbreklerin daha fazla su kullanmasına neden olur.
                Yeterli su içmek glisemik kontrolü destekler ve HbA1c değerini iyileştirebilir.
              </Text>
              <View style={{ flexDirection: 'row', gap: 16, marginTop: 12 }}>
                {[
                  { val: '30ml', lbl: 'kg başına\ngünlük' },
                  { val: '8x',   lbl: 'günlük\nbardak' },
                  { val: '%↓',   lbl: 'kan şekeri\nseyreltir' },
                ].map(s => (
                  <View key={s.val} style={{ flex: 1, alignItems: 'center' }}>
                    <Text style={{ fontSize: 22, fontWeight: '900', color: '#FFF' }}>{s.val}</Text>
                    <Text style={{ fontSize: 10, color: 'rgba(255,255,255,0.7)', textAlign: 'center', lineHeight: 14, marginTop: 2 }}>{s.lbl}</Text>
                  </View>
                ))}
              </View>
            </LinearGradient>

          </ScrollView>
        </KeyboardAvoidingView>
      </Animated.View>
    </Modal>
  );
}

// ── Stiller ───────────────────────────────────────────────────

const styles = StyleSheet.create({
  backdrop: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.45)',
  },
  sheet: {
    position: 'absolute',
    bottom: 0, left: 0, right: 0,
    backgroundColor: '#F8FAFC',
    borderTopLeftRadius: 32,
    borderTopRightRadius: 32,
    maxHeight: '92%',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -8 },
    shadowOpacity: 0.15,
    shadowRadius: 20,
    elevation: 24,
  },
  handle: {
    width: 42, height: 4, borderRadius: 2,
    backgroundColor: '#CBD5E1',
    alignSelf: 'center', marginTop: 12, marginBottom: 4,
  },
  sheetHeader: {
    flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between',
    paddingHorizontal: 22, paddingTop: 14, paddingBottom: 10,
  },
  sheetTitle: { fontSize: 22, fontWeight: '900', color: '#0F172A' },
  sheetSub:   { fontSize: 13, color: '#64748B', fontWeight: '600', marginTop: 2 },
  closeBtn: {
    width: 36, height: 36, borderRadius: 18,
    backgroundColor: '#F1F5F9', alignItems: 'center', justifyContent: 'center',
  },

  topRow: { flexDirection: 'row', paddingHorizontal: 22, paddingVertical: 14, alignItems: 'center' },

  glassPctWrap: { ...StyleSheet.absoluteFillObject, alignItems: 'center', justifyContent: 'center' },
  glassPctPill: {
    paddingHorizontal: 10, paddingVertical: 4, borderRadius: 10,
  },
  glassPct: {
    fontSize: 16, fontWeight: '900', color: '#FFF',
    textShadowColor: 'rgba(0,0,0,0.6)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 3,
  },

  motiBadge: {
    flexDirection: 'row', alignItems: 'center',
    borderRadius: 16, padding: 12, marginBottom: 14,
  },
  motiTitle: { fontSize: 14, fontWeight: '900', marginBottom: 2 },
  motiSub:   { fontSize: 11, color: '#64748B', fontWeight: '500', lineHeight: 15 },

  mlCounter:   { flexDirection: 'row', alignItems: 'baseline', marginBottom: 8 },
  mlCurrent:   { fontSize: 30, fontWeight: '900', color: '#0369A1' },
  mlUnit:      { fontSize: 14, fontWeight: '600', color: '#94A3B8' },
  progressBg:  { height: 8, backgroundColor: '#E0F2FE', borderRadius: 4, overflow: 'hidden' },
  progressFill:{ height: '100%', borderRadius: 4 },

  timeHint: {
    marginHorizontal: 22, marginBottom: 10,
    backgroundColor: '#FFF7ED', borderRadius: 14,
    paddingHorizontal: 14, paddingVertical: 10,
    borderWidth: 1, borderColor: '#FED7AA',
  },
  timeHintText: { fontSize: 12, color: '#92400E', fontWeight: '600', lineHeight: 18 },

  sectionTitle: {
    fontSize: 13, fontWeight: '800', color: '#64748B',
    textTransform: 'uppercase', letterSpacing: 0.6,
    paddingHorizontal: 22, marginTop: 6, marginBottom: 10,
  },

  quickGrid: { flexDirection: 'row', paddingHorizontal: 16, gap: 8, marginBottom: 14 },
  quickBtn:  { flex: 1, borderRadius: 18, overflow: 'hidden', elevation: 2, shadowColor: '#0EA5E9', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.12, shadowRadius: 6 },
  quickBtnInner: { paddingVertical: 14, alignItems: 'center', borderRadius: 18 },
  quickBtnLabel: { fontSize: 11, fontWeight: '800', color: '#0369A1', marginBottom: 2 },
  quickBtnMl:    { fontSize: 13, fontWeight: '900', color: '#0C4A6E' },

  customRow:     { flexDirection: 'row', marginHorizontal: 16, gap: 10, marginBottom: 16 },
  customInput:   { flex: 1, height: 52, backgroundColor: '#FFF', borderRadius: 16, paddingHorizontal: 16, fontSize: 16, fontWeight: '700', color: '#0F172A', borderWidth: 1.5, borderColor: '#BAE6FD' },
  customAddBtn:  { borderRadius: 16, overflow: 'hidden' },
  customAddBtnInner: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 20, height: 52, justifyContent: 'center' },
  customAddBtnText:  { fontSize: 15, fontWeight: '800', color: '#FFF' },

  tipCard: {
    marginHorizontal: 16, marginBottom: 16,
    backgroundColor: '#F0F9FF', borderRadius: 18,
    padding: 16, alignItems: 'center',
    borderWidth: 1, borderColor: '#BAE6FD',
  },
  tipText: { fontSize: 13, color: '#0C4A6E', textAlign: 'center', lineHeight: 20, fontWeight: '500' },

  historyCard: { marginHorizontal: 16, marginBottom: 16, backgroundColor: '#FFF', borderRadius: 18, overflow: 'hidden', borderWidth: 1, borderColor: '#E2E8F0' },
  historyRow:  { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 12, gap: 10 },
  historyRowBorder: { borderBottomWidth: 1, borderBottomColor: '#F1F5F9' },
  historyDot:  { width: 8, height: 8, borderRadius: 4, backgroundColor: '#38BDF8' },
  historyTime: { fontSize: 13, fontWeight: '700', color: '#64748B', width: 40 },
  historyAmount: { fontSize: 15, fontWeight: '800', color: '#0369A1', flex: 1 },
  historyBar:  { height: 4, backgroundColor: '#BAE6FD', borderRadius: 2, maxWidth: 80 },

  diabetesCard: { marginHorizontal: 16, marginBottom: 20, borderRadius: 22, padding: 20 },
  diabetesTitle:{ fontSize: 16, fontWeight: '900', color: '#FFF', marginBottom: 8 },
  diabetesText: { fontSize: 12, color: 'rgba(255,255,255,0.82)', lineHeight: 18, fontWeight: '500' },
});
