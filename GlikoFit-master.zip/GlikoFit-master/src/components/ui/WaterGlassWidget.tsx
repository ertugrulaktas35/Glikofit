/**
 * WaterGlassWidget — Fotoğraftaki bardak ile aynı görünüm
 * Koyu lacivert cam · Sol yansıma şeridi · Animasyonlu su dolumu
 * react-native-svg ile gerçek şekil, arka plan yok
 */
import React, { useEffect, useRef } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, Animated, Easing,
} from 'react-native';
import Svg, {
  Defs, ClipPath, Path, Rect, Ellipse,
  LinearGradient as SvgLinearGradient, Stop, G,
} from 'react-native-svg';

// AnimatedRect — y ve height SVG prop'larını animate eder
const AnimatedRect = Animated.createAnimatedComponent(Rect);

// ── SVG boyutları ─────────────────────────────────────────────
const VW = 62;   // viewBox genişliği
const VH = 88;   // viewBox yüksekliği

// Dış cam sınırı — fotoğraftaki gibi geniş üst, dar alt tumbler
const OUTER = `M5,0 L57,0 L53,78 Q53,88 45,88 L17,88 Q9,88 9,78 L5,0 Z`;

// İç alan — cam duvarı (4px) kadar küçük
const INNER = `M9,0 L53,0 L49,76 Q49,82 43,82 L19,82 Q13,82 13,76 L9,0 Z`;

const WATER_TOP    = 2;
const WATER_BOTTOM = 82;
const WATER_MAX_H  = WATER_BOTTOM - WATER_TOP;

// ── Props ─────────────────────────────────────────────────────
interface Props {
  pct: number;
  waterMl: number;
  shakeAnim: Animated.Value;
  onPress: () => void;
  bottomOffset?: number;
}

export default function WaterGlassWidget({
  pct, waterMl, shakeAnim, onPress, bottomOffset = 120,
}: Props) {

  const fillAnim = useRef(new Animated.Value(0)).current;
  const waveAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.timing(fillAnim, {
      toValue: Math.min(pct, 100) / 100,
      duration: 1300,
      easing: Easing.out(Easing.exp),
      useNativeDriver: false,
    }).start();
  }, [pct]);

  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(waveAnim, { toValue: 1, duration: 2000, easing: Easing.inOut(Easing.sin), useNativeDriver: false }),
        Animated.timing(waveAnim, { toValue: 0, duration: 2000, easing: Easing.inOut(Easing.sin), useNativeDriver: false }),
      ])
    ).start();
  }, []);

  const fillH = fillAnim.interpolate({ inputRange: [0, 1], outputRange: [0, WATER_MAX_H] });
  const fillY = fillAnim.interpolate({ inputRange: [0, 1], outputRange: [WATER_BOTTOM, WATER_TOP] });
  const waveX = waveAnim.interpolate({ inputRange: [0, 1], outputRange: [0, 5] });

  const waterTopColor    = pct >= 80 ? '#38BDF8' : pct >= 50 ? '#7DD3FC' : '#BAE6FD';
  const waterBottomColor = pct >= 80 ? '#0284C7' : pct >= 50 ? '#0EA5E9' : '#38BDF8';

  const litersText = waterMl >= 1000
    ? `${(waterMl / 1000).toFixed(1)}L`
    : `${waterMl}ml`;

  return (
    <Animated.View
      style={[styles.root, { bottom: bottomOffset, transform: [{ translateX: shakeAnim }] }]}
      pointerEvents="box-none"
    >
      <TouchableOpacity onPress={onPress} activeOpacity={0.82} style={styles.hit}>

        {/* Dış yumuşak gölge */}
        <View style={styles.shadow} />

        <Svg width={VW} height={VH} viewBox={`0 0 ${VW} ${VH}`}>
          <Defs>
            <ClipPath id="glassInner">
              <Path d={INNER} />
            </ClipPath>

            {/* Su renk gradyanı */}
            <SvgLinearGradient id="wg" x1="0" y1="0" x2="0" y2="1">
              <Stop offset="0" stopColor={waterTopColor}    stopOpacity="0.9" />
              <Stop offset="1" stopColor={waterBottomColor} stopOpacity="1"   />
            </SvgLinearGradient>

            {/* Cam gövde — açık mavi, yandan hafif koyulaşır */}
            <SvgLinearGradient id="bg" x1="0" y1="0" x2="1" y2="0">
              <Stop offset="0"    stopColor="#6AAEE8" stopOpacity="1" />
              <Stop offset="0.45" stopColor="#4A8ED4" stopOpacity="1" />
              <Stop offset="1"    stopColor="#3578C0" stopOpacity="1" />
            </SvgLinearGradient>

            {/* İç arka plan — biraz daha açık */}
            <SvgLinearGradient id="ig" x1="0" y1="0" x2="1" y2="0">
              <Stop offset="0"  stopColor="#5BA3E2" stopOpacity="1" />
              <Stop offset="1"  stopColor="#4490D5" stopOpacity="1" />
            </SvgLinearGradient>
          </Defs>

          {/* 1 — Dış lacivert cam gövdesi */}
          <Path d={OUTER} fill="url(#bg)" />

          {/* 2 — İç arka plan */}
          <G clipPath="url(#glassInner)">
            <Rect x="0" y="0" width={VW} height={VH} fill="url(#ig)" />
          </G>

          {/* 3 — Animasyonlu su */}
          <G clipPath="url(#glassInner)">
            <AnimatedRect x="0" y={fillY} width={VW} height={fillH} fill="url(#wg)" />
            {/* Yüzey parlaması */}
            <AnimatedRect x={waveX} y={fillY} width={VW} height="3.5" rx="1.5" fill="rgba(255,255,255,0.48)" />
          </G>

          {/* 4 — Sol yansıma: fotoğraftaki belirgin beyaz oval şerit */}
          <G clipPath="url(#glassInner)">
            {/* Ana yansıma gövdesi */}
            <Ellipse cx="18" cy="41" rx="6" ry="34" fill="rgba(255,255,255,0.50)" />
            {/* İç parlama (daha dar, daha parlak) */}
            <Ellipse cx="16" cy="40" rx="2.5" ry="27" fill="rgba(255,255,255,0.30)" />
          </G>

          {/* 5 — Sağ kenar derinlik gölgesi */}
          <G clipPath="url(#glassInner)">
            <Ellipse cx="47" cy="44" rx="4" ry="36" fill="rgba(0,0,0,0.22)" />
          </G>

          {/* 6 — Üst ağız içi parlama */}
          <Path d="M9,0 L53,0 L51,7 L11,7 Z" fill="rgba(255,255,255,0.08)" />

          {/* 7 — Dış kontur */}
          <Path d={OUTER} fill="none" stroke="rgba(255,255,255,0.20)" strokeWidth="1.2" />
        </Svg>

        {/* Yüzde metni — SVG üstüne native Text */}
        <View style={styles.pctOverlay} pointerEvents="none">
          <View style={styles.pctPill}>
            <Text style={styles.pctText}>
              {pct >= 100 ? '✓' : `${Math.round(pct)}%`}
            </Text>
          </View>
        </View>

        {/* Alt litre etiketi */}
        <View style={styles.label}>
          <Text style={styles.labelDrop}>💧</Text>
          <Text style={styles.labelText}>{litersText}</Text>
        </View>

      </TouchableOpacity>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  root: {
    position: 'absolute',
    right: 16,
    zIndex: 999,
    alignItems: 'center',
  },
  hit: {
    alignItems: 'center',
    padding: 2,
  },

  shadow: {
    position: 'absolute',
    width: VW - 10,
    height: VH,
    borderRadius: 16,
    backgroundColor: 'transparent',
    top: 0,
    shadowColor: '#4A8ED4',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.45,
    shadowRadius: 18,
    elevation: 14,
  },

  pctOverlay: {
    position: 'absolute',
    top: 32,
    left: 0,
    right: 0,
    alignItems: 'center',
  },
  pctPill: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 8,
  },
  pctText: {
    fontSize: 13,
    fontWeight: '900',
    color: '#FFFFFF',
    textShadowColor: 'rgba(0,0,0,0.7)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 3,
    letterSpacing: 0.2,
  },

  label: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
    marginTop: 7,
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 6,
    elevation: 3,
  },
  labelDrop: { fontSize: 11 },
  labelText: {
    fontSize: 11,
    fontWeight: '700',
    color: '#64748B',
    letterSpacing: 0.5,
  },
});
